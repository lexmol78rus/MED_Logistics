--
-- PostgreSQL database dump
--

\restrict 5NaLgnZuLOB5trKmbazLoc2QmpvxrMaeLaHmkHRNKkHFxf2XtEZvqfuOoSOwvbQ

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ContractDocType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ContractDocType" AS ENUM (
    'DOCX',
    'HTML',
    'PDF',
    'OTHER'
);


--
-- Name: CounterpartyType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CounterpartyType" AS ENUM (
    'CUSTOMER',
    'SUPPLIER',
    'LEGAL_ENTITY'
);


--
-- Name: ExpectedReceiptEventType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ExpectedReceiptEventType" AS ENUM (
    'CREATED',
    'RECEIVED',
    'UPDATED',
    'CANCELLED',
    'CLOSED'
);


--
-- Name: ExpectedReceiptStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ExpectedReceiptStatus" AS ENUM (
    'ORDERED',
    'PARTIALLY_RECEIVED',
    'RECEIVED',
    'CANCELLED'
);


--
-- Name: LotStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."LotStatus" AS ENUM (
    'OK',
    'WARNING',
    'QUARANTINE',
    'BLOCKED'
);


--
-- Name: MovementType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MovementType" AS ENUM (
    'RECEIPT',
    'ISSUE',
    'ADJUSTMENT',
    'QUARANTINE',
    'UNBLOCK',
    'RECALL',
    'BLOCK'
);


--
-- Name: NotificationPriority; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."NotificationPriority" AS ENUM (
    'LOW',
    'NORMAL',
    'HIGH',
    'CRITICAL'
);


--
-- Name: ShipmentPickingOutcome; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ShipmentPickingOutcome" AS ENUM (
    'SUCCESS',
    'PARTIAL',
    'ISSUE'
);


--
-- Name: ShipmentStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ShipmentStatus" AS ENUM (
    'NEW',
    'PICKING',
    'PICKED',
    'PICKING_ON_HOLD',
    'DISPATCHED',
    'DRAFT'
);


--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."UserRole" AS ENUM (
    'ADMIN',
    'OPERATOR',
    'ACCOUNTANT',
    'VIEWER',
    'MANAGER'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id text NOT NULL,
    actor_id text,
    action text NOT NULL,
    entity_type text NOT NULL,
    entity_id text,
    metadata jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: barcode_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.barcode_records (
    id text NOT NULL,
    barcode text NOT NULL,
    product_id text,
    lot_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: contracts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contracts (
    id text NOT NULL,
    counterparty_id text NOT NULL,
    number text NOT NULL,
    date timestamp(3) without time zone,
    title text,
    doc_type public."ContractDocType" DEFAULT 'OTHER'::public."ContractDocType" NOT NULL,
    original_name text NOT NULL,
    mime_type text NOT NULL,
    file_size integer NOT NULL,
    file_name text NOT NULL,
    storage_path text NOT NULL,
    uploaded_by text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    procurement_items jsonb,
    procurement_parsed_at timestamp with time zone,
    procurement_parse_error text
);


--
-- Name: counterparties; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.counterparties (
    id text NOT NULL,
    type public."CounterpartyType" NOT NULL,
    name text NOT NULL,
    inn text,
    kpp text,
    comment text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    full_name text
);


--
-- Name: expected_receipt_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expected_receipt_events (
    id text NOT NULL,
    expected_receipt_id text NOT NULL,
    type public."ExpectedReceiptEventType" NOT NULL,
    quantity numeric(18,4),
    message text,
    actor_email text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: expected_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expected_receipts (
    id text NOT NULL,
    product_id text NOT NULL,
    ordered_qty numeric(18,4) NOT NULL,
    received_qty numeric(18,4) DEFAULT 0 NOT NULL,
    status public."ExpectedReceiptStatus" DEFAULT 'ORDERED'::public."ExpectedReceiptStatus" NOT NULL,
    comment text,
    created_by text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: inventory_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_items (
    id text NOT NULL,
    product_id text NOT NULL,
    lot_id text NOT NULL,
    quantity numeric(18,4) NOT NULL,
    location text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    reserved_quantity numeric(18,4) DEFAULT 0 NOT NULL
);


--
-- Name: lots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lots (
    id text NOT NULL,
    product_id text NOT NULL,
    lot_number text NOT NULL,
    expiry_date timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    mfg_date timestamp(3) without time zone,
    status public."LotStatus" DEFAULT 'OK'::public."LotStatus" NOT NULL
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id text NOT NULL,
    user_id text,
    channel text DEFAULT 'in_app'::text NOT NULL,
    payload jsonb,
    read_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    type text NOT NULL,
    priority public."NotificationPriority" DEFAULT 'NORMAL'::public."NotificationPriority" NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    href text
);


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.password_reset_tokens (
    id text NOT NULL,
    user_id text NOT NULL,
    token_hash text NOT NULL,
    expires_at timestamp(3) without time zone NOT NULL,
    used_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: product_name_catalog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_name_catalog (
    id text NOT NULL,
    name text NOT NULL,
    name_normalized text NOT NULL,
    manufacturer text,
    use_count integer DEFAULT 1 NOT NULL,
    last_used_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: product_registration_certificates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_registration_certificates (
    id text NOT NULL,
    product_id text NOT NULL,
    file_name text NOT NULL,
    original_name text NOT NULL,
    mime_type text NOT NULL,
    file_size integer NOT NULL,
    storage_path text NOT NULL,
    uploaded_by text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id text NOT NULL,
    sku text NOT NULL,
    name text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    manufacturer text,
    min_stock numeric(18,4),
    reorder_point numeric(18,4),
    gtin character varying(14)
);


--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refresh_tokens (
    id text NOT NULL,
    user_id text NOT NULL,
    token_hash text NOT NULL,
    expires_at timestamp(3) without time zone NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: shipment_assembly_reservations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shipment_assembly_reservations (
    id text NOT NULL,
    shipment_id text NOT NULL,
    product_id text NOT NULL,
    quantity numeric(18,4) NOT NULL,
    reserved_by_email text NOT NULL,
    reserved_by_user_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: shipment_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shipment_items (
    id text NOT NULL,
    shipment_id text NOT NULL,
    name text NOT NULL,
    code text,
    unit text,
    vat_rate text,
    price_with_vat numeric(18,4),
    quantity numeric(18,4) NOT NULL,
    sum numeric(18,4),
    contract_line_no integer,
    manager_note text,
    manager_tag text,
    product_id text
);


--
-- Name: shipments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shipments (
    id text NOT NULL,
    status public."ShipmentStatus" DEFAULT 'NEW'::public."ShipmentStatus" NOT NULL,
    counterparty_id text,
    contract_id text,
    note text,
    created_by text,
    picking_sent_at timestamp(3) without time zone,
    picked_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    warehouse_message text,
    picking_paused_at timestamp(3) without time zone,
    picking_recalled_at timestamp(3) without time zone,
    picking_outcome public."ShipmentPickingOutcome",
    picking_complete_comment text,
    writeoff_completed_at timestamp(3) without time zone,
    legal_entity_id text
);


--
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_movements (
    id text NOT NULL,
    reference text NOT NULL,
    product_id text NOT NULL,
    lot_id text,
    type public."MovementType" NOT NULL,
    quantity numeric(18,4) NOT NULL,
    actor_email text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    write_off_destination text,
    write_off_comment text,
    write_off_destination_id text,
    operation_group_id text,
    corrected_movement_id text,
    correction_session_id text,
    edit_reason text,
    shipment_id text
);


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_settings (
    id text DEFAULT 'default'::text NOT NULL,
    payload jsonb NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    updated_by text
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    role public."UserRole" DEFAULT 'OPERATOR'::public."UserRole" NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    display_name text,
    last_login_at timestamp(3) without time zone,
    deleted_at timestamp(3) without time zone,
    permissions jsonb
);


--
-- Name: write_off_destinations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.write_off_destinations (
    id text NOT NULL,
    name text NOT NULL,
    type text,
    is_active boolean DEFAULT true NOT NULL,
    legacy_code text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
2e993d7d-d734-4948-9844-053e53f8dd1a	a27431a47d07b55184130771a286ccbb7f64692e2a19a80af5aa2d4988cffb9d	2026-05-20 11:06:42.495502+00	20250520090000_init	\N	\N	2026-05-20 11:06:42.447312+00	1
f54653bb-0887-42d9-a9ad-e2a5821b4cee	c75658f365ad6fec7b143d4f2db880ec77e999e3997abb413f37bfc1520357e5	2026-05-29 13:35:45.765662+00	20260529180000_product_name_catalog	\N	\N	2026-05-29 13:35:45.729386+00	1
36512e4d-15c0-45df-8aaf-ce07710e9a33	0e3e4b3842c097424281453ad67379e7b9516eb5d2e9255014942207a4ff16f0	2026-05-20 11:25:30.823134+00	20250520120000_refresh_tokens	\N	\N	2026-05-20 11:25:30.807831+00	1
b1182594-629d-4b15-9f15-2c2357d60c11	30da6b97e591f43afa2ff6c721922d30ec4fb2bbb65f0173404641921ff45587	2026-05-22 13:00:55.478353+00	20250522100000_movement_operation_group	\N	\N	2026-05-22 13:00:55.463236+00	1
878afbe2-8401-476b-9bb6-5c9dbb206566	c2f8ece0ad966b5a24abcf988112fdfe79cb096a317bd1777037e9b5771c83a0	2026-05-20 12:01:07.06873+00	20250520140000_inventory_workflows	\N	\N	2026-05-20 12:01:07.015688+00	1
b6a8b15f-4780-4641-a12e-10881d4246c4	ab17c04771de487687e8f193473d9be0c2f87376bb04f4781b7e323e16435e77	2026-05-20 14:15:14.284056+00	20250520160000_movement_types_recall_block	\N	\N	2026-05-20 14:15:14.244079+00	1
1dd17001-2625-4876-86bd-83964aeb9160	4fb55fcdf8205e3c9eca49b2e40ec1aa31c23fa13d73485453eddfc3d3b4e01a	2026-05-28 16:56:24.855225+00	20260528200000_shipment_item_product_link	\N	\N	2026-05-28 16:56:24.831197+00	1
e96b7658-045c-4b33-b163-19b56af87cc2	47a640fb090d294eea2b244de58350cf0fced9c56abbe29a48ca7998b6f373e6	2026-05-20 14:15:14.286429+00	20250520180000_add_manager_role	\N	\N	2026-05-20 14:15:14.28463+00	1
2061ff10-33d7-4f14-a615-1206eceb5041	0f7c360660799f09cbd2b2822e6bdd162ba4e0233d4e24c9a1c035101818844e	2026-05-22 15:28:25.886004+00	20250522120000_movement_corrections	\N	\N	2026-05-22 15:28:25.850607+00	1
eb5a7932-0371-428b-8700-b8d455165a1c	a24f9f3f9a530a9cfceaa3c858245ae9b7e9c7854d5180d4e0b940edda132565	2026-05-20 14:15:14.376496+00	20250520200000_inventory_ops_stage	\N	\N	2026-05-20 14:15:14.286889+00	1
9be12dcf-28f6-45ee-85dc-7dd99ac0e230	2a286a27e3a44f5d0d3aedf14ecd3e7ac86287a288c83225802f0f3b262358c9	2026-05-20 14:15:14.378916+00	20250520220000_user_display_name	\N	\N	2026-05-20 14:15:14.377082+00	1
8f5d2706-9556-40c9-babc-ed53af1d820a	0e5532a181ec78bb24eed9746ebb6195fd7e0747a8a432d03074029f5d2599de	2026-05-20 14:35:36.851858+00	20250520240000_user_delete_password_reset	\N	\N	2026-05-20 14:35:36.755486+00	1
8931d39c-669b-4528-857c-9df1394f439f	2d65c6680ef6eb40db1cb49011706a9b0acd7bf59891a51b575e8a9f81b84f82	2026-05-25 13:07:56.110097+00	20250525130000_product_registration_certificates	\N	\N	2026-05-25 13:07:56.085025+00	1
f1ad51eb-b618-4b6f-8e16-62fb6f408244	cc43f5cb239bebe3ca38b15dcdc044f45da59cc46790bdde635acc41039e6bc4	2026-05-20 14:41:20.364369+00	20250520260000_users_email_partial_unique	\N	\N	2026-05-20 14:41:20.353273+00	1
b762b823-b6fc-4cf8-b6f1-2d25caaa26d7	b0ca2c10d2c88f4bcb22f28bdb95d76b556957c995c5540d31bfb1c9b1266434	2026-05-20 15:21:28.161887+00	20250520150000_mail_settings_payload	\N	\N	2026-05-20 15:21:28.154114+00	1
3d82046e-7c0e-4f2b-8c3d-d65649ead2d0	3df4186acf5bf56aa574ea2a9cd22907e607a203a35fae90b2920238e9a38b97	2026-05-21 11:05:13.21493+00	20250521000000_writeoff_destination	\N	\N	2026-05-21 11:05:13.203129+00	1
5fe69e5a-9ed9-4b9f-82f0-30c58d74da97	954d7383df807735d6c1f5a68199b1337145babff14beeb40029153bda258fbd	2026-05-28 11:46:27.0124+00	20260528150000_shipments_counterparties	\N	\N	2026-05-28 11:46:26.976524+00	1
973f0f45-bf3b-406d-8d35-f4a69eb8ae86	1df5871e93eca7eb11d89b3ca4aadd761b927859c68ca0b22a95b42c9f79dad9	2026-05-21 12:32:22.970072+00	20250521120000_writeoff_destinations_ref	\N	\N	2026-05-21 12:32:22.935339+00	1
e0f394fb-bf21-4432-9957-17f91ef4fb8b	8effa9acefea0b9520b9c49af9309a88cf47d3302aa518cb3b827982dfd97cf9	2026-05-21 14:22:00.791635+00	20250521140000_expected_receipts	\N	\N	2026-05-21 14:22:00.751986+00	1
22f7c5a9-23fa-49bf-8529-249e5287813c	393cdab99284481b30c54e2081e13e623d8d30afdf6cd1630c887e8cf75e50d3	2026-05-28 17:10:21.881406+00	20260528210000_shipment_picking_complete_writeoff	\N	\N	2026-05-28 17:10:21.85203+00	1
9c2636ef-43ed-498a-9de7-fcf063d14f5f	5b583ba53bf22570db915229c848e07a627fef101abfc33c907fb99df202ed6a	2026-05-28 13:06:50.719792+00	20260528160300_counterparty_full_name	\N	\N	2026-05-28 13:06:50.712673+00	1
69dc7817-46e5-4739-8861-b4777835f839	5fb1679a8532bd7ffa779e48bc0c282bdb7140645570f188363b0803454c7b19	2026-05-28 14:05:32.025169+00	20260528170000_contract_procurement_cache	\N	\N	2026-05-28 14:05:32.018885+00	1
be5bf637-56b8-4dcc-a053-5670eb76e2d0	5deda924120c832c64163b0cc64ec94da167c9b80c5b531c957ad131512d4d14	2026-05-28 14:48:55.733429+00	20260528180000_shipments_manager_columns	\N	\N	2026-05-28 14:48:55.726679+00	1
32ab29c4-65ac-460e-a229-4cf4d3685106	30fb1b001a17262955a5615df11946795a95f2a4a8d43fad06e90d015c92e21b	2026-05-29 11:08:54.05401+00	20260529120000_shipment_assembly_reservations	\N	\N	2026-05-29 11:08:54.026355+00	1
7dccbcc0-0bd7-4837-b2e7-e786aa3b28f4	8f7f67f7ee010b685bb59745dacf170800e57e97d493fb5fbabc3516f972b86a	2026-05-28 15:30:28.395646+00	20260528190000_shipment_picking_hold	\N	\N	2026-05-28 15:30:28.38759+00	1
377a67a5-fbdf-4e90-8f66-2f4f0dc284c7	e9b893b9dc067bff404746ec418eeaf36f211b4dc67e43a77a252810aa293436	2026-05-30 09:00:05.997888+00	20260530120000_user_permissions	\N	\N	2026-05-30 09:00:05.992851+00	1
6768fa78-a6cb-4487-b7de-54e4ce130822	2d8c7687af55a765c45ce9686ba40e0a57d3b70181cee8be24e4e7f8c95752d3	2026-05-29 11:49:09.160005+00	20260529140000_shipment_status_draft	\N	\N	2026-05-29 11:49:09.154878+00	1
f2ba839d-27d5-434d-8b29-0be42dec6903	514f4936fbb0d681b761b29334a49ab0513c19bdb3b2dcd989dd17106dd945b1	2026-05-29 13:18:36.123165+00	20260529160000_product_gtin	\N	\N	2026-05-29 13:18:36.107477+00	1
ec496266-3ec2-4d26-bfa2-a0a1f6d34b95	ed248da1891d7fcffb4fc3bef1a4ad6c364d53e2eb7e6c6f4d026f6f785c6d94	2026-05-30 09:05:59.502912+00	20260530140000_user_role_accountant	\N	\N	2026-05-30 09:05:59.495406+00	1
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, actor_id, action, entity_type, entity_id, metadata, created_at) FROM stdin;
cmpl62ayy0004z4226eqwr3sw	\N	product.quick_create	product	cmpl62ayu0002z4228q1xaway	{"sku": "533350", "name": "Стент Advanix билиарный (10Fx5cm)", "barcode": "0108714729786726172711041037870723"}	2026-05-25 12:12:23.434
cmpl63mqo000ez422oru7hheu	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpl63mqc0007z4224idgwt61	{"quantity": 10, "lotNumber": "37870723", "productId": "cmpl62ayu0002z4228q1xaway", "expectedReceiptId": null}	2026-05-25 12:13:25.344
cmpl640sc000kz422br7pgphq	\N	product.update	product	cmpl62ayu0002z4228q1xaway	{"sku": "533350", "newSku": "M00533350", "changes": {"sku": "M00533350", "name": "Стент Advanix билиарный (10Fx5cm)", "barcode": "0108714729786726172711041037870723", "manufacturer": "Boston Scientific"}}	2026-05-25 12:13:43.548
cmpl654rg000uz422z4ypkkmi	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpl654r7000nz422did1kjda	{"quantity": 10, "lotNumber": "37479225", "productId": "cmpl62ayu0002z4228q1xaway", "expectedReceiptId": null}	2026-05-25 12:14:35.357
cmpl6a5hs000vz422r1kui74d	cmpf7cy2c000e9de7xtf3doa3	inventory.fefo.violation	product	cmpl62ayu0002z4228q1xaway	{"actualLotId": "cmpl63mqc0007z4224idgwt61", "expectedLotId": "cmpl654r7000nz422did1kjda"}	2026-05-25 12:18:29.585
cmpl6a5hz000wz422mkjnl14y	cmpf7cy2c000e9de7xtf3doa3	inventory.fefo.violation	product	cmpl62ayu0002z4228q1xaway	{"actualLotId": "cmpl63mqc0007z4224idgwt61", "expectedLotId": "cmpl654r7000nz422did1kjda"}	2026-05-25 12:18:29.591
cmpl6a5i4000xz4220q57zcfl	cmpf7cy2c000e9de7xtf3doa3	inventory.fefo.violation	product	cmpl62ayu0002z4228q1xaway	{"actualLotId": "cmpl63mqc0007z4224idgwt61", "expectedLotId": "cmpl654r7000nz422did1kjda"}	2026-05-25 12:18:29.597
cmpl6ath30013z422s9k31ghd	cmpf7cy2c000e9de7xtf3doa3	inventory.fefo.violation	product	cmpl62ayu0002z4228q1xaway	{"actualLotId": "cmpl63mqc0007z4224idgwt61", "expectedLotId": "cmpl654r7000nz422did1kjda"}	2026-05-25 12:19:00.664
cmpl6athj0019z422vm8p4dim	cmpf7cy2c000e9de7xtf3doa3	inventory.writeoff.batch	writeoff_batch	17f2fbd0-2a5e-4deb-9e46-6eac0ea59306	{"items": [{"lines": [{"lotId": "cmpl654r7000nz422did1kjda", "quantity": 10}, {"lotId": "cmpl63mqc0007z4224idgwt61", "quantity": 9}], "productId": "cmpl62ayu0002z4228q1xaway", "references": ["ПЕР-0004", "ПЕР-0005"], "writeOffComment": "eat", "operationGroupId": "17f2fbd0-2a5e-4deb-9e46-6eac0ea59306", "writeOffDestinationId": "wod_internal", "writeOffDestinationLabel": "Внутреннее потребление: eat"}], "itemCount": 1, "lineCount": 2, "references": ["ПЕР-0004", "ПЕР-0005"], "operationGroupId": "17f2fbd0-2a5e-4deb-9e46-6eac0ea59306"}	2026-05-25 12:19:00.68
cmpl6ghhp001cz422ndo526t6	cmpe6lgwq0009eityq7uocwm4	auth.login	auth	cmpe6lgwq0009eityq7uocwm4	{"email": "am@medicine-2000.ru"}	2026-05-25 12:23:25.069
cmpl73xqv0006u8sy6uiqgcq7	\N	product.quick_create	product	cmpl73xqm0004u8syozyyy62l	{"sku": "160849063210", "name": "тест", "barcode": "03355566888"}	2026-05-25 12:41:39.223
cmpl83c860002hl4pfgvg8f6w	cmpf7cy2c000e9de7xtf3doa3	auth.login	auth	cmpf7cy2c000e9de7xtf3doa3	{"email": "sklad@navitek.biz"}	2026-05-25 13:09:10.951
cmpl8cc2l0009upjnoxidwkxi	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpl63mqc0007z4224idgwt61	{"quantity": 15, "lotNumber": "37870723", "productId": "cmpl62ayu0002z4228q1xaway", "expectedReceiptId": null}	2026-05-25 13:16:10.653
cmpl8cc3c000jupjnz3s01wku	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpl654r7000nz422did1kjda	{"quantity": 20, "lotNumber": "37479225", "productId": "cmpl62ayu0002z4228q1xaway", "expectedReceiptId": null}	2026-05-25 13:16:10.681
cmpl9d2ld0006wr1jsuux3lrd	cmpf7cy2c000e9de7xtf3doa3	inventory.fefo.violation	product	cmpl62ayu0002z4228q1xaway	{"actualLotId": "cmpl63mqc0007z4224idgwt61", "expectedLotId": "cmpl654r7000nz422did1kjda"}	2026-05-25 13:44:44.641
cmpla0tif000iwr1jka9afqqt	cmpf7cy2c000e9de7xtf3doa3	inventory.fefo.violation	product	cmpl62ayu0002z4228q1xaway	{"actualLotId": "cmpl63mqc0007z4224idgwt61", "expectedLotId": "cmpl654r7000nz422did1kjda"}	2026-05-25 14:03:12.616
cmpla0tiu000owr1jqt93wf2d	cmpf7cy2c000e9de7xtf3doa3	inventory.writeoff.batch	writeoff_batch	213246fd-8500-4f8d-8484-927d637f3828	{"items": [{"lines": [{"lotId": "cmpl654r7000nz422did1kjda", "quantity": 20}, {"lotId": "cmpl63mqc0007z4224idgwt61", "quantity": 16}], "productId": "cmpl62ayu0002z4228q1xaway", "references": ["ПЕР-0008", "ПЕР-0009"], "writeOffComment": null, "operationGroupId": "213246fd-8500-4f8d-8484-927d637f3828", "writeOffDestinationId": "cmpfii3yx000lstrvkacz7ks2", "writeOffDestinationLabel": "ДГБ 2"}], "itemCount": 1, "lineCount": 2, "references": ["ПЕР-0008", "ПЕР-0009"], "operationGroupId": "213246fd-8500-4f8d-8484-927d637f3828"}	2026-05-25 14:03:12.63
cmpla3qlg000ywr1j839wfj3i	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpl654r7000nz422did1kjda	{"quantity": 10, "lotNumber": "37479225", "productId": "cmpl62ayu0002z4228q1xaway", "expectedReceiptId": null}	2026-05-25 14:05:28.805
cmpla3qm30018wr1j0wn2vjw5	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpl63mqc0007z4224idgwt61	{"quantity": 20, "lotNumber": "37870723", "productId": "cmpl62ayu0002z4228q1xaway", "expectedReceiptId": null}	2026-05-25 14:05:28.828
cmplabwa4001dwr1j1ydyg4or	cmpe6lgwq0009eityq7uocwm4	auth.login_failed	auth	cmpe6lgwq0009eityq7uocwm4	{"email": "am@medicine-2000.ru", "reason": "invalid_password"}	2026-05-25 14:11:49.42
cmplabzkj001gwr1jc3w4x7y6	cmpe6lgwq0009eityq7uocwm4	auth.login	auth	cmpe6lgwq0009eityq7uocwm4	{"email": "am@medicine-2000.ru"}	2026-05-25 14:11:53.683
cmplb91u80001n69fn1pwjmmv	\N	lot.location.update	lot	cmpl654r7000nz422did1kjda	{"location": "Тест-А-23", "lotNumber": "37479225", "productId": "cmpl62ayu0002z4228q1xaway"}	2026-05-25 14:37:36.273
cmplbfl1p0008n69f735nrvn1	cmpe6lgwq0009eityq7uocwm4	auth.login	auth	cmpe6lgwq0009eityq7uocwm4	{"email": "am@medicine-2000.ru"}	2026-05-25 14:42:41.101
cmplbor2f000en69fsbp92kej	cmpe6lgwq0009eityq7uocwm4	inventory.writeoff.correct	writeoff_correction	213246fd-8500-4f8d-8484-927d637f3828	{"additions": [], "editReason": "Менеджер ошибся", "operationGroupId": "213246fd-8500-4f8d-8484-927d637f3828", "updatedReferences": ["ПЕР-0009", "ПЕР-0008"], "correctionSessionId": "c0b3465f-ec91-4697-8047-394ce2e57730", "correctionReferences": ["ПЕР-0012", "ПЕР-0013"]}	2026-05-25 14:49:48.808
cmpmaqn2p001dn69f55l4a4as	cmpfl6gyd000zjzrra4c7q7u0	auth.login	auth	cmpfl6gyd000zjzrra4c7q7u0	{"email": "ekaterina.s@navitek.biz"}	2026-05-26 07:11:03.505
cmpmbrf3j0004bh60fyl3yq42	cmpf7cy2c000e9de7xtf3doa3	auth.login	auth	cmpf7cy2c000e9de7xtf3doa3	{"email": "sklad@navitek.biz"}	2026-05-26 07:39:39.44
cmpmbsj2h0006bh609gclhhtg	\N	lot.location.update	lot	cmpl654r7000nz422did1kjda	{"location": "F1", "lotNumber": "37479225", "productId": "cmpl62ayu0002z4228q1xaway"}	2026-05-26 07:40:31.242
cmpmbspee0008bh60846b3z3n	\N	lot.location.update	lot	cmpl63mqc0007z4224idgwt61	{"location": "F1", "lotNumber": "37870723", "productId": "cmpl62ayu0002z4228q1xaway"}	2026-05-26 07:40:39.446
cmpmc0uma000dbh60w3mwq5f0	cmpe6lgwq0009eityq7uocwm4	auth.login	auth	cmpe6lgwq0009eityq7uocwm4	{"email": "am@medicine-2000.ru"}	2026-05-26 07:46:59.459
cmpmc5er80001lm5kz7ed9trk	\N	product.purge_all	product	\N	{"before": {"lots": 2, "products": 2, "movements": 13, "barcodeRecords": 2, "inventoryItems": 2, "expectedReceipts": 0, "expectedReceiptEvents": 0, "registrationCertificates": 1}, "source": "scripts/purge-nomenclature.mjs", "deleted": {"products": 2, "barcodeRecords": 2}}	2026-05-26 07:50:32.18
cmpmcfeyb00041k2uhsgmu4uy	\N	product.quick_create	product	cmpmcfey600021k2uw7js511b	{"sku": "M00533010", "name": "Стент Advanix билиарный (10Fx9cm)", "barcode": "0108714729786924172711121037941736"}	2026-05-26 07:58:18.996
cmpmcin1i000e1k2upbld4qzq	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpmcin1100071k2usjl5qasd	{"quantity": 7, "lotNumber": "37941736", "productId": "cmpmcfey600021k2uw7js511b", "expectedReceiptId": null}	2026-05-26 08:00:49.447
cmpmcin27000m1k2u04fr1zsf	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpmcin1100071k2usjl5qasd	{"quantity": 30, "lotNumber": "37941736", "productId": "cmpmcfey600021k2uw7js511b", "expectedReceiptId": null}	2026-05-26 08:00:49.471
cmpmcin2u000w1k2uv8iqbgw4	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpmcin2m000p1k2u5ei1n17o	{"quantity": 10, "lotNumber": "37858279", "productId": "cmpmcfey600021k2uw7js511b", "expectedReceiptId": null}	2026-05-26 08:00:49.494
cmpmcljjh00111k2u0bibtz72	\N	product.quick_create	product	cmpmcljje000z1k2uewbthv27	{"sku": "M00533000", "name": "Стент Advanix билиарный (10Fx7cm)", "barcode": "0108714729786917172801211038404581"}	2026-05-26 08:03:04.878
cmpmcnzbz001b1k2uizpwxofl	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpmcnzbq00141k2uo7ty8scw	{"quantity": 15, "lotNumber": "38404581", "productId": "cmpmcljje000z1k2uewbthv27", "expectedReceiptId": null}	2026-05-26 08:04:58.655
cmpmcnzci001l1k2urqu4vywv	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpmcnzcc001e1k2um5miuq8n	{"quantity": 15, "lotNumber": "38420978", "productId": "cmpmcljje000z1k2uewbthv27", "expectedReceiptId": null}	2026-05-26 08:04:58.674
cmpmcqdgv001o1k2u2grnj8xt	\N	product.quick_create	product	cmpmcqdgs001m1k2uw2ath32f	{"sku": "M00533350", "name": "Стент Advanix билиарный (10Fx5cm)", "barcode": "0108714729786726172711041037870723"}	2026-05-26 08:06:50.288
cmpmcrsf0001y1k2u5jcq53c3	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpmcrseo001r1k2uoe2u4ha1	{"quantity": 20, "lotNumber": "37870723", "productId": "cmpmcqdgs001m1k2uw2ath32f", "expectedReceiptId": null}	2026-05-26 08:07:56.317
cmpmcrsfk00281k2u8xo0oeaq	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpmcrsfe00211k2uz83zryw1	{"quantity": 6, "lotNumber": "37479225", "productId": "cmpmcqdgs001m1k2uw2ath32f", "expectedReceiptId": null}	2026-05-26 08:07:56.336
cmpmcu0rx002b1k2u1rqfkdlm	\N	product.quick_create	product	cmpmcu0rt00291k2ushag980x	{"sku": "M00533040", "name": "Стент Advanix билиарный (10Fx18cm)", "barcode": "0108714729786955172803041038758114"}	2026-05-26 08:09:40.462
cmpmcw8do002g1k2ubz0hwtr1	\N	product.quick_create	product	cmpmcw8dk002e1k2ue32kczgy	{"sku": "M00533030", "name": "Стент Advanix билиарный (10Fx15cm)", "barcode": "0108714729786948172801051038263611"}	2026-05-26 08:11:23.629
cmpmd0lg3002l1k2u92diwlhe	\N	product.quick_create	product	cmpmd0lfz002j1k2ubzh2f0sz	{"sku": "M00533360", "name": "Стент Advanix билиарный (10Fx7cm)", "barcode": "0108714729786733172705311036650262"}	2026-05-26 08:14:47.188
cmpmd1n1v002o1k2uufvgxi4i	\N	product.quick_create	product	cmpmd1n1r002m1k2upgdg0ln4	{"sku": "M00532270", "name": "Стент Advanix билиарный (10Fx7cm)", "barcode": "0108714729787044172711071037904170"}	2026-05-26 08:15:35.923
cmpmd2sbt002r1k2ug9nx5e1h	\N	product.quick_create	product	cmpmd2sbq002p1k2u5ssy3lfs	{"sku": "M00532300", "name": "Стент Advanix билиарный (10Fx12cm)", "barcode": "0108714729787068172709221037517250"}	2026-05-26 08:16:29.417
cmpmd6ue100331k2uk16zt1t6	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpmd6udr002w1k2uyhba7t8q	{"quantity": 5, "lotNumber": "38758114", "productId": "cmpmcu0rt00291k2ushag980x", "expectedReceiptId": null}	2026-05-26 08:19:38.713
cmpmd6ueo003d1k2u0bkve9m2	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpmd6uei00361k2unt434b1k	{"quantity": 1, "lotNumber": "35615631", "productId": "cmpmcu0rt00291k2ushag980x", "expectedReceiptId": null}	2026-05-26 08:19:38.736
cmpmd6uf8003n1k2u75mwymcc	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpmd6uf1003g1k2ufzrdlgos	{"quantity": 1, "lotNumber": "38262611", "productId": "cmpmcw8dk002e1k2ue32kczgy", "expectedReceiptId": null}	2026-05-26 08:19:38.756
cmpmd6ufp003x1k2uvrph4esp	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpmd6ufj003q1k2udi0bji4e	{"quantity": 2, "lotNumber": "38168042", "productId": "cmpmcw8dk002e1k2ue32kczgy", "expectedReceiptId": null}	2026-05-26 08:19:38.773
cmpmd6ug600471k2u2b7kl43p	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpmd6ug000401k2utmpqvni1	{"quantity": 2, "lotNumber": "36845801", "productId": "cmpmcw8dk002e1k2ue32kczgy", "expectedReceiptId": null}	2026-05-26 08:19:38.79
cmpmd6ugn004h1k2ujl4fg1ko	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpmd6ugh004a1k2utqsil874	{"quantity": 4, "lotNumber": "36838804", "productId": "cmpmcqdgs001m1k2uw2ath32f", "expectedReceiptId": null}	2026-05-26 08:19:38.807
cmpmd6uh5004r1k2uvfq6u2sx	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpmd6ugz004k1k2udfqwxrax	{"quantity": 1, "lotNumber": "36650262", "productId": "cmpmd0lfz002j1k2ubzh2f0sz", "expectedReceiptId": null}	2026-05-26 08:19:38.825
cmpmd6uhl00511k2urcm8gt16	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpmd6uhf004u1k2uq9iqysm0	{"quantity": 1, "lotNumber": "37904170", "productId": "cmpmd1n1r002m1k2upgdg0ln4", "expectedReceiptId": null}	2026-05-26 08:19:38.842
cmpmd6ui5005b1k2u5ubibzik	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpmd6uhz00541k2ul0qq2j8b	{"quantity": 1, "lotNumber": "37517250", "productId": "cmpmd2sbq002p1k2u5ssy3lfs", "expectedReceiptId": null}	2026-05-26 08:19:38.861
cmpmd6uj1005l1k2ual353zxq	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpmd6uii005e1k2ur57rwhsw	{"quantity": 2, "lotNumber": "38123885", "productId": "cmpmd1n1r002m1k2upgdg0ln4", "expectedReceiptId": null}	2026-05-26 08:19:38.894
cmpmd6ujk005v1k2um9ele0vh	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpmd6uje005o1k2ujo3oo8mh	{"quantity": 2, "lotNumber": "38077059", "productId": "cmpmd1n1r002m1k2upgdg0ln4", "expectedReceiptId": null}	2026-05-26 08:19:38.912
cmpmd6uk400651k2usth7dhle	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpmd6ujz005y1k2uyv23qzas	{"quantity": 2, "lotNumber": "37813161", "productId": "cmpmd1n1r002m1k2upgdg0ln4", "expectedReceiptId": null}	2026-05-26 08:19:38.933
cmpmd6uko006f1k2u0izafcjn	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpmd6uki00681k2um94lvlnr	{"quantity": 3, "lotNumber": "37720189", "productId": "cmpmd1n1r002m1k2upgdg0ln4", "expectedReceiptId": null}	2026-05-26 08:19:38.952
cmpmd6ul7006n1k2us10ynbhi	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpmd6uii005e1k2ur57rwhsw	{"quantity": 1, "lotNumber": "38123885", "productId": "cmpmd1n1r002m1k2upgdg0ln4", "expectedReceiptId": null}	2026-05-26 08:19:38.972
cmpmdcby9006p1k2uhjsqqehi	\N	lot.location.update	lot	cmpmd6uhz00541k2ul0qq2j8b	{"location": "A7", "lotNumber": "37517250", "productId": "cmpmd2sbq002p1k2u5ssy3lfs"}	2026-05-26 08:23:54.753
cmpmdhj94007b1k2ushz29323	\N	lot.location.update	lot	cmpmd6uf1003g1k2ufzrdlgos	{"location": "A7", "lotNumber": "38262611", "productId": "cmpmcw8dk002e1k2ue32kczgy"}	2026-05-26 08:27:57.496
cmpmdhlju007d1k2ud6x7bjid	\N	lot.location.update	lot	cmpmd6ufj003q1k2udi0bji4e	{"location": "A7", "lotNumber": "38168042", "productId": "cmpmcw8dk002e1k2ue32kczgy"}	2026-05-26 08:28:00.475
cmpmdhn27007f1k2uj3y8jkfj	\N	lot.location.update	lot	cmpmd6ug000401k2utmpqvni1	{"location": "A7", "lotNumber": "36845801", "productId": "cmpmcw8dk002e1k2ue32kczgy"}	2026-05-26 08:28:02.432
cmpmdhwcn007h1k2uhut5zk6e	\N	lot.location.update	lot	cmpmd6uei00361k2unt434b1k	{"location": "A7", "lotNumber": "35615631", "productId": "cmpmcu0rt00291k2ushag980x"}	2026-05-26 08:28:14.471
cmpmdhxh9007j1k2uqohacl8n	\N	lot.location.update	lot	cmpmd6udr002w1k2uyhba7t8q	{"location": "A7", "lotNumber": "38758114", "productId": "cmpmcu0rt00291k2ushag980x"}	2026-05-26 08:28:15.934
cmpmdi62n007l1k2uwmoae8b0	\N	lot.location.update	lot	cmpmd6ugh004a1k2utqsil874	{"location": "A7", "lotNumber": "36838804", "productId": "cmpmcqdgs001m1k2uw2ath32f"}	2026-05-26 08:28:27.072
cmpmdi772007n1k2uxfuk6pe0	\N	lot.location.update	lot	cmpmcrsfe00211k2uz83zryw1	{"location": "A7", "lotNumber": "37479225", "productId": "cmpmcqdgs001m1k2uw2ath32f"}	2026-05-26 08:28:28.526
cmpmdi8cf007p1k2uvhnnwkyr	\N	lot.location.update	lot	cmpmcrseo001r1k2uoe2u4ha1	{"location": "A7", "lotNumber": "37870723", "productId": "cmpmcqdgs001m1k2uw2ath32f"}	2026-05-26 08:28:30.015
cmpmdiczh007r1k2uxpwmnpc3	\N	lot.location.update	lot	cmpmd6ugz004k1k2udfqwxrax	{"location": "A7", "lotNumber": "36650262", "productId": "cmpmd0lfz002j1k2ubzh2f0sz"}	2026-05-26 08:28:36.03
cmpmdiire007t1k2uvd6ildoi	\N	lot.location.update	lot	cmpmd6uki00681k2um94lvlnr	{"location": "A7", "lotNumber": "37720189", "productId": "cmpmd1n1r002m1k2upgdg0ln4"}	2026-05-26 08:28:43.514
cmpmdijrz007v1k2u9ouv788d	\N	lot.location.update	lot	cmpmd6ujz005y1k2uyv23qzas	{"location": "A7", "lotNumber": "37813161", "productId": "cmpmd1n1r002m1k2upgdg0ln4"}	2026-05-26 08:28:44.831
cmpmdikp2007x1k2u9k5f1c3q	\N	lot.location.update	lot	cmpmd6uhf004u1k2uq9iqysm0	{"location": "A7", "lotNumber": "37904170", "productId": "cmpmd1n1r002m1k2upgdg0ln4"}	2026-05-26 08:28:46.022
cmpmdilnq007z1k2ug97fairg	\N	lot.location.update	lot	cmpmd6uje005o1k2ujo3oo8mh	{"location": "A7", "lotNumber": "38077059", "productId": "cmpmd1n1r002m1k2upgdg0ln4"}	2026-05-26 08:28:47.27
cmpmdimsm00811k2ujdr4v787	\N	lot.location.update	lot	cmpmd6uii005e1k2ur57rwhsw	{"location": "A7", "lotNumber": "38123885", "productId": "cmpmd1n1r002m1k2upgdg0ln4"}	2026-05-26 08:28:48.743
cmpmdiuuv00831k2u1h4rb6qg	\N	lot.location.update	lot	cmpmcnzbq00141k2uo7ty8scw	{"location": "A7", "lotNumber": "38404581", "productId": "cmpmcljje000z1k2uewbthv27"}	2026-05-26 08:28:59.191
cmpmdivyf00851k2urwi7zn0s	\N	lot.location.update	lot	cmpmcnzcc001e1k2um5miuq8n	{"location": "A7", "lotNumber": "38420978", "productId": "cmpmcljje000z1k2uewbthv27"}	2026-05-26 08:29:00.616
cmpmdj50000871k2uxanr3j85	\N	lot.location.update	lot	cmpmcin2m000p1k2u5ei1n17o	{"location": "A7", "lotNumber": "37858279", "productId": "cmpmcfey600021k2uw7js511b"}	2026-05-26 08:29:12.336
cmpmdj64o00891k2u61w0tn3k	\N	lot.location.update	lot	cmpmcin1100071k2usjl5qasd	{"location": "A7", "lotNumber": "37941736", "productId": "cmpmcfey600021k2uw7js511b"}	2026-05-26 08:29:13.8
cmpmeiz7s008o1k2u6qvbbqbs	\N	product.quick_create	product	cmpmeiz7o008m1k2ul02hr44z	{"sku": "1111111111", "name": "test", "barcode": "11111111111"}	2026-05-26 08:57:04.456
cmpmes1cx008r1k2us2czpw8q	cmpe6lgwq0009eityq7uocwm4	auth.login	auth	cmpe6lgwq0009eityq7uocwm4	{"email": "am@medicine-2000.ru"}	2026-05-26 09:04:07.138
maint-del-test-1779786575	\N	product.delete	product	cmpmeiz7o008m1k2ul02hr44z	{"sku": "1111111111", "name": "test", "source": "maintenance_single_product_delete", "manufacturer": "test"}	2026-05-26 09:09:35.906
cmpmf58uq008y1k2u31a3ngjs	\N	product.quick_create	product	cmpmf58un008w1k2uwvdhf2ru	{"sku": "M00546550", "name": "Экстракционная корзина SpyGlass Retrieval Basket", "barcode": "0108714729965886172609251034925486"}	2026-05-26 09:14:23.379
cmpmf92la009a1k2uw7wyfvvd	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpmf92l200931k2uuj7qvz1g	{"quantity": 3, "lotNumber": "34925486", "productId": "cmpmf58un008w1k2uwvdhf2ru", "expectedReceiptId": null}	2026-05-26 09:17:21.886
cmpmfeep6009f1k2u2g2goemh	cmpf7cy2c000e9de7xtf3doa3	settings.update	system_settings	default	{"changes": {"fefoStrict": true, "fefoEnabled": true, "uiAnimations": true, "uiCompactMode": false, "warehouseCode": "WH-01", "warehouseName": "МЕД-ЛОГИСТИКА — Склад №1", "uiShowFefoHints": true, "scannerAutoFocus": true, "expiryWarningDays": 100, "scannerDebounceMs": 300, "expiryCriticalDays": 90, "notificationEnabled": true, "scannerSoundEnabled": true, "uiAutoRefreshDashboard": false}}	2026-05-26 09:21:30.859
cmpmfexp0009g1k2uvu5u5vx3	cmpf7cy2c000e9de7xtf3doa3	settings.update	system_settings	default	{"changes": {"fefoStrict": true, "fefoEnabled": true, "uiAnimations": true, "uiCompactMode": false, "warehouseCode": "WH-01", "warehouseName": "МЕД-ЛОГИСТИКА — Склад №1", "uiShowFefoHints": true, "scannerAutoFocus": true, "expiryWarningDays": 177, "scannerDebounceMs": 300, "expiryCriticalDays": 90, "notificationEnabled": true, "scannerSoundEnabled": true, "uiAutoRefreshDashboard": false}}	2026-05-26 09:21:55.476
cmpmhtwfy00a91k2uyv3wv4pu	cmpe6lgwq0009eityq7uocwm4	settings.update	system_settings	default	{"changes": {"fefoStrict": true, "fefoEnabled": true, "uiAnimations": true, "uiCompactMode": false, "warehouseCode": "WH-01", "warehouseName": "МЕД-ЛОГИСТИКА — Склад №1", "uiShowFefoHints": true, "scannerAutoFocus": true, "expiryWarningDays": 100, "scannerDebounceMs": 300, "expiryCriticalDays": 90, "notificationEnabled": true, "scannerSoundEnabled": true, "uiAutoRefreshDashboard": false}}	2026-05-26 10:29:32.927
cmpmhufvl00aa1k2ucty4nw3q	cmpe6lgwq0009eityq7uocwm4	settings.update	system_settings	default	{"changes": {"fefoStrict": true, "fefoEnabled": true, "uiAnimations": true, "uiCompactMode": false, "warehouseCode": "WH-01", "warehouseName": "МЕД-ЛОГИСТИКА — Склад №1", "uiShowFefoHints": true, "scannerAutoFocus": true, "expiryWarningDays": 500, "scannerDebounceMs": 300, "expiryCriticalDays": 200, "notificationEnabled": true, "scannerSoundEnabled": true, "uiAutoRefreshDashboard": false}}	2026-05-26 10:29:58.114
cmpmhzzxj00007i86tqhom84w	cmpdz6zq70000qua72g7ns5dg	auth.login_failed	auth	cmpdz6zq70000qua72g7ns5dg	{"email": "admin@med.local", "reason": "disabled"}	2026-05-26 10:34:17.384
cmpmi0mjp00017i86mzkw9vxt	cmpe6lgwq0009eityq7uocwm4	settings.update	system_settings	default	{"changes": {"fefoStrict": true, "fefoEnabled": true, "uiAnimations": true, "uiCompactMode": false, "warehouseCode": "WH-01", "warehouseName": "МЕД-ЛОГИСТИКА — Склад №1", "uiShowFefoHints": true, "scannerAutoFocus": true, "expiryWarningDays": 180, "scannerDebounceMs": 300, "expiryCriticalDays": 90, "notificationEnabled": true, "scannerSoundEnabled": true, "uiAutoRefreshDashboard": false}}	2026-05-26 10:34:46.694
cmpmi20ie00027i86h7hjm4vx	cmpe6lgwq0009eityq7uocwm4	auth.login_failed	auth	cmpe6lgwq0009eityq7uocwm4	{"email": "am@medicine-2000.ru", "reason": "invalid_password"}	2026-05-26 10:35:51.446
cmpmi220e00057i86yp7rts86	cmpe6lgwq0009eityq7uocwm4	auth.login	auth	cmpe6lgwq0009eityq7uocwm4	{"email": "am@medicine-2000.ru"}	2026-05-26 10:35:53.39
cmpmigs7f000a7i86me7ao9yy	cmpf7cy2c000e9de7xtf3doa3	settings.update	system_settings	default	{"changes": {"fefoStrict": true, "fefoEnabled": true, "uiAnimations": true, "uiCompactMode": false, "warehouseCode": "WH-01", "warehouseName": "МЕД-ЛОГИСТИКА — Склад №1", "uiShowFefoHints": true, "scannerAutoFocus": true, "expiryWarningDays": 500, "scannerDebounceMs": 300, "expiryCriticalDays": 200, "notificationEnabled": true, "scannerSoundEnabled": true, "uiAutoRefreshDashboard": false}}	2026-05-26 10:47:20.523
cmpmihvsf000e7i86k1cooafg	\N	lot.status.blocked	lot	cmpmf92l200931k2uuj7qvz1g	{"status": "BLOCKED"}	2026-05-26 10:48:11.823
cmpmihytn000i7i86abq0on10	\N	lot.status.quarantine	lot	cmpmd6uei00361k2unt434b1k	{"status": "QUARANTINE"}	2026-05-26 10:48:15.756
cmpmimd2b000l7i868neilkst	cmpf7cy2c000e9de7xtf3doa3	inventory.fefo.violation	product	cmpmcqdgs001m1k2uw2ath32f	{"actualLotId": "cmpmcrsfe00211k2uz83zryw1", "expectedLotId": "cmpmd6ugh004a1k2utqsil874"}	2026-05-26 10:51:40.835
cmpmimd2q000r7i86wzd9cqj1	cmpf7cy2c000e9de7xtf3doa3	inventory.writeoff.batch	writeoff_batch	5e5b2e8f-9c56-45a6-94bf-bfb4c9dfd3de	{"items": [{"lines": [{"lotId": "cmpmd6ugh004a1k2utqsil874", "quantity": 4}, {"lotId": "cmpmcrsfe00211k2uz83zryw1", "quantity": 6}], "productId": "cmpmcqdgs001m1k2uw2ath32f", "references": ["ПЕР-0025", "ПЕР-0026"], "writeOffComment": null, "operationGroupId": "5e5b2e8f-9c56-45a6-94bf-bfb4c9dfd3de", "writeOffDestinationId": "wod_other", "writeOffDestinationLabel": "Другое"}], "itemCount": 1, "lineCount": 2, "references": ["ПЕР-0025", "ПЕР-0026"], "operationGroupId": "5e5b2e8f-9c56-45a6-94bf-bfb4c9dfd3de"}	2026-05-26 10:51:40.85
cmpmip0wm00117i8667bj6p8t	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpmcrsfe00211k2uz83zryw1	{"quantity": 6, "lotNumber": "37479225", "productId": "cmpmcqdgs001m1k2uw2ath32f", "expectedReceiptId": null}	2026-05-26 10:53:45.047
cmpmip0xc001b7i86qx84yrax	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpmip0x600147i86762woq9c	{"quantity": 4, "lotNumber": "63838804", "productId": "cmpmcqdgs001m1k2uw2ath32f", "expectedReceiptId": null}	2026-05-26 10:53:45.073
cmpmiq60z001f7i86y9ajwmrv	\N	lot.status.blocked	lot	cmpmf92l200931k2uuj7qvz1g	{"status": "BLOCKED"}	2026-05-26 10:54:38.34
cmpmiq7qe001j7i862790g5yr	\N	lot.status.blocked	lot	cmpmf92l200931k2uuj7qvz1g	{"status": "BLOCKED"}	2026-05-26 10:54:40.551
cmpmiq9u4001n7i86pazrfozx	\N	lot.status.quarantine	lot	cmpmd6uei00361k2unt434b1k	{"status": "QUARANTINE"}	2026-05-26 10:54:43.276
cmpmiqk0x001r7i86idoe3n0x	\N	lot.status.ok	lot	cmpmf92l200931k2uuj7qvz1g	{"status": "OK"}	2026-05-26 10:54:56.482
cmpmiql1z001v7i86hn2duztg	\N	lot.status.ok	lot	cmpmd6uei00361k2unt434b1k	{"status": "OK"}	2026-05-26 10:54:57.816
cmpmirpd6001w7i86qlvzxt46	cmpf7cy2c000e9de7xtf3doa3	settings.update	system_settings	default	{"changes": {"fefoStrict": true, "fefoEnabled": true, "uiAnimations": true, "uiCompactMode": false, "warehouseCode": "WH-01", "warehouseName": "МЕД-ЛОГИСТИКА — Склад №1", "uiShowFefoHints": true, "scannerAutoFocus": true, "expiryWarningDays": 180, "scannerDebounceMs": 300, "expiryCriticalDays": 90, "notificationEnabled": true, "scannerSoundEnabled": true, "uiAutoRefreshDashboard": false}}	2026-05-26 10:55:50.059
cmpmis3rz001z7i8644erfdu8	cmpf7cy2c000e9de7xtf3doa3	auth.login	auth	cmpf7cy2c000e9de7xtf3doa3	{"email": "sklad@navitek.biz"}	2026-05-26 10:56:08.735
cmpmjryym002d7i868lb3x7zf	\N	lot.status.quarantine	lot	cmpmf92l200931k2uuj7qvz1g	{"status": "QUARANTINE"}	2026-05-26 11:24:02.111
cmpmjs0z5002h7i86wol0ysbz	\N	lot.status.ok	lot	cmpmf92l200931k2uuj7qvz1g	{"status": "OK"}	2026-05-26 11:24:04.721
cmpmjs1mp002l7i86ihvfih2p	\N	lot.status.blocked	lot	cmpmf92l200931k2uuj7qvz1g	{"status": "BLOCKED"}	2026-05-26 11:24:05.57
cmpmjs2zx002p7i86wz7ccvde	\N	lot.status.ok	lot	cmpmf92l200931k2uuj7qvz1g	{"status": "OK"}	2026-05-26 11:24:07.341
cmpmkqfir0000h19n1osh8goo	cmpe6lgwq0009eityq7uocwm4	export.shift_report	export	\N	{"to": "2026-05-26T11:50:00.000Z", "from": "2026-05-25T21:00:00.000Z", "targetUserId": "cmpe6lgwq0009eityq7uocwm4"}	2026-05-26 11:50:49.876
cmpmktvvk0003h19n9fm2fij2	cmpe6lgwq0009eityq7uocwm4	export.shift_report.admin	export	\N	{"to": "2026-05-26T11:53:00.000Z", "from": "2026-05-25T21:00:00.000Z", "targetUserId": "cmpf7cy2c000e9de7xtf3doa3"}	2026-05-26 11:53:31.04
cmpmkxja00000rjzyr9ztyi9h	cmpe6lgwq0009eityq7uocwm4	export.shift_report.admin	export	\N	{"to": "2026-05-26T11:56:00.000Z", "from": "2026-05-25T21:00:00.000Z", "targetUserId": "cmpf7cy2c000e9de7xtf3doa3"}	2026-05-26 11:56:21.336
cmpml7pdg00007eulaor3aoql	cmpe6lgwq0009eityq7uocwm4	export.shift_report.admin	export	\N	{"to": "2026-05-26T12:03:00.000Z", "from": "2026-05-25T21:00:00.000Z", "targetUserId": "cmpfl6gyd000zjzrra4c7q7u0"}	2026-05-26 12:04:15.796
cmpmlqjxm00077eulhy32yndc	cmpf7cy2c000e9de7xtf3doa3	export.shift_report	export	\N	{"to": "2026-05-26T12:18:00.000Z", "from": "2026-05-25T21:00:00.000Z", "targetUserId": "cmpf7cy2c000e9de7xtf3doa3"}	2026-05-26 12:18:55.21
cmpmlr52600087eulu4hqv87l	cmpf7cy2c000e9de7xtf3doa3	auth.login_failed	auth	cmpf7cy2c000e9de7xtf3doa3	{"email": "sklad@navitek.biz", "reason": "invalid_password"}	2026-05-26 12:19:22.59
cmpmlr6t600097eulxgjpx5io	cmpf7cy2c000e9de7xtf3doa3	auth.login_failed	auth	cmpf7cy2c000e9de7xtf3doa3	{"email": "sklad@navitek.biz", "reason": "invalid_password"}	2026-05-26 12:19:24.859
cmpmlrg2b000a7eulhsk56hjg	cmpf7cy2c000e9de7xtf3doa3	auth.login_failed	auth	cmpf7cy2c000e9de7xtf3doa3	{"email": "sklad@navitek.biz", "reason": "invalid_password"}	2026-05-26 12:19:36.852
cmpmlrw74000d7eulc8lsplg8	cmpf7cy2c000e9de7xtf3doa3	auth.login	auth	cmpf7cy2c000e9de7xtf3doa3	{"email": "sklad@navitek.biz"}	2026-05-26 12:19:57.761
cmpmm3r2l000n7eulpjxzdd0c	\N	lot.status.blocked	lot	cmpmip0x600147i86762woq9c	{"status": "BLOCKED"}	2026-05-26 12:29:10.99
cmpmm5jtf000r7eull4py6urz	\N	lot.status.ok	lot	cmpmip0x600147i86762woq9c	{"status": "OK"}	2026-05-26 12:30:34.899
cmpmnijj8000fmtazsn6k1m3p	\N	lot.void	lot	cmpmip0x600147i86762woq9c	{"comment": "мой косяк", "lotNumber": "63838804", "productId": "cmpmcqdgs001m1k2uw2ath32f", "productSku": "M00533350", "qtyBeforeVoid": 4, "transferToLotNumber": "36838804"}	2026-05-26 13:08:40.676
cmpmo8lq0000umtazzc61o5ng	\N	product.quick_create	product	cmpmo8lpv000smtaznrd18ujf	{"sku": "M7-027", "name": "Протез сердечного клапана Carbomedics Standard", "barcode": "1729011921Ы1645411-Ф"}	2026-05-26 13:28:56.568
cmpmob9c80011mtazvlvqx85j	\N	product.quick_create	product	cmpmob9c5000zmtaz5joihe1x	{"sku": "M7-025", "name": "Протез сердечного клапана Carbomedics Standard", "barcode": "1727103021S1576918-A"}	2026-05-26 13:31:00.489
cmpmocewk001dmtazfbcjxu31	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpmocewc0016mtazz4b9ugbx	{"quantity": 1, "lotNumber": "S1645411-A", "productId": "cmpmo8lpv000smtaznrd18ujf", "expectedReceiptId": null}	2026-05-26 13:31:54.357
cmpmocex1001nmtazinemposc	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpmocewx001gmtaztho4k5co	{"quantity": 1, "lotNumber": "S1576918-A", "productId": "cmpmob9c5000zmtaz5joihe1x", "expectedReceiptId": null}	2026-05-26 13:31:54.374
cmpmohhqy001tmtazhjbelp5u	\N	product.update	product	cmpmob9c5000zmtaz5joihe1x	{"sku": "M7-025", "changes": {"name": "Протез сердечного клапана Carbomedics Standard", "barcode": "1727103021S1576918-A", "manufacturer": "CORCYM"}}	2026-05-26 13:35:51.323
cmpmojhzl0021mtazvm7a5mqv	\N	product.update	product	cmpmo8lpv000smtaznrd18ujf	{"sku": "M7-027", "changes": {"name": "Протез сердечного клапана Carbomedics Standard", "barcode": "1729011921S1645411-A", "manufacturer": "CORCYM"}}	2026-05-26 13:37:24.945
cmpmokxnb0027mtazaavf7nmd	cmpf7cy2c000e9de7xtf3doa3	inventory.writeoff.batch	writeoff_batch	60257143-f47f-4c07-9f58-d040209b6299	{"items": [{"lines": [{"lotId": "cmpmocewc0016mtazz4b9ugbx", "quantity": 1}], "productId": "cmpmo8lpv000smtaznrd18ujf", "references": ["ПЕР-0047"], "writeOffComment": null, "operationGroupId": "60257143-f47f-4c07-9f58-d040209b6299", "writeOffDestinationId": "wod_internal", "writeOffDestinationLabel": "Внутреннее потребление"}, {"lines": [{"lotId": "cmpmocewx001gmtaztho4k5co", "quantity": 1}], "productId": "cmpmob9c5000zmtaz5joihe1x", "references": ["ПЕР-0048"], "writeOffComment": null, "operationGroupId": "60257143-f47f-4c07-9f58-d040209b6299", "writeOffDestinationId": "wod_internal", "writeOffDestinationLabel": "Внутреннее потребление"}], "itemCount": 2, "lineCount": 2, "references": ["ПЕР-0047", "ПЕР-0048"], "operationGroupId": "60257143-f47f-4c07-9f58-d040209b6299"}	2026-05-26 13:38:31.895
cmpmoml1t002hmtazg7sb5n5m	cmpf7cy2c000e9de7xtf3doa3	inventory.writeoff.correct	writeoff_correction	60257143-f47f-4c07-9f58-d040209b6299	{"additions": [], "editReason": "otkaz bolnitsy", "operationGroupId": "60257143-f47f-4c07-9f58-d040209b6299", "updatedReferences": ["ПЕР-0048", "ПЕР-0047"], "correctionSessionId": "4419edf2-7295-427d-b43a-b5c7da54bd7c", "correctionReferences": ["ПЕР-0049", "ПЕР-0050"]}	2026-05-26 13:39:48.881
cmpmonjgh002jmtaz2ht0y1w7	\N	lot.location.update	lot	cmpmocewc0016mtazz4b9ugbx	{"location": "B5", "lotNumber": "S1645411-A", "productId": "cmpmo8lpv000smtaznrd18ujf"}	2026-05-26 13:40:33.474
cmpmonsx5002nmtazgs0ltj72	\N	lot.location.update	lot	cmpmocewx001gmtaztho4k5co	{"location": "B5", "lotNumber": "S1576918-A", "productId": "cmpmob9c5000zmtaz5joihe1x"}	2026-05-26 13:40:45.737
cmpmopwat002qmtazquhja47z	cmpf7cy2c000e9de7xtf3doa3	export.shift_report	export	\N	{"to": "2026-05-26T13:42:00.000Z", "from": "2026-05-25T21:00:00.000Z", "targetUserId": "cmpf7cy2c000e9de7xtf3doa3"}	2026-05-26 13:42:23.429
cmpmosegs002rmtazzi3ao2yy	cmpf7cy2c000e9de7xtf3doa3	export.shift_report.admin	export	\N	{"to": "2026-05-26T13:44:00.000Z", "from": "2026-05-25T21:00:00.000Z", "targetUserId": "cmpfl6gyd000zjzrra4c7q7u0"}	2026-05-26 13:44:20.284
cmpmoti4g002smtazkojltwzx	cmpf7cy2c000e9de7xtf3doa3	settings.update	system_settings	default	{"changes": {"fefoStrict": true, "fefoEnabled": true, "uiAnimations": true, "uiCompactMode": false, "warehouseCode": "WH-01", "warehouseName": "МЕД-ЛОГИСТИКА — Склад №1", "uiShowFefoHints": true, "scannerAutoFocus": true, "expiryWarningDays": 500, "scannerDebounceMs": 300, "expiryCriticalDays": 300, "notificationEnabled": true, "scannerSoundEnabled": true, "uiAutoRefreshDashboard": false, "activityHistoryRetentionDays": 90}}	2026-05-26 13:45:11.68
cmpmou6c6002wmtazeycmz7sa	\N	lot.status.blocked	lot	cmpmf92l200931k2uuj7qvz1g	{"status": "BLOCKED"}	2026-05-26 13:45:43.062
cmpmoum560030mtaz8sogo271	\N	lot.status.ok	lot	cmpmf92l200931k2uuj7qvz1g	{"status": "OK"}	2026-05-26 13:46:03.546
cmpmovcif0031mtaz0devno7b	cmpf7cy2c000e9de7xtf3doa3	settings.update	system_settings	default	{"changes": {"fefoStrict": true, "fefoEnabled": true, "uiAnimations": true, "uiCompactMode": false, "warehouseCode": "WH-01", "warehouseName": "МЕД-ЛОГИСТИКА — Склад №1", "uiShowFefoHints": true, "scannerAutoFocus": true, "expiryWarningDays": 180, "scannerDebounceMs": 300, "expiryCriticalDays": 90, "notificationEnabled": true, "scannerSoundEnabled": true, "uiAutoRefreshDashboard": false, "activityHistoryRetentionDays": 90}}	2026-05-26 13:46:37.72
cmpmoxhaw0037mtazohsdw2uy	cmpf7cy2c000e9de7xtf3doa3	expected_receipt.create	expected_receipt	cmpmoxhap0035mtazbz9rb44b	{"productId": "cmpmob9c5000zmtaz5joihe1x", "orderedQty": 100000}	2026-05-26 13:48:17.241
cmpmozlwv003fmtaz9lncfkxi	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpmocewx001gmtaztho4k5co	{"quantity": 50000, "lotNumber": "S1576918-A", "productId": "cmpmob9c5000zmtaz5joihe1x", "expectedReceiptId": "cmpmoxhap0035mtazbz9rb44b"}	2026-05-26 13:49:56.528
cmpmp03s3003lmtazlrmic10z	cmpf7cy2c000e9de7xtf3doa3	expected_receipt.cancel	expected_receipt	cmpmoxhap0035mtazbz9rb44b	\N	2026-05-26 13:50:19.684
cmpmp6ced003rmtazwx8omngt	cmpe6lgwq0009eityq7uocwm4	expected_receipt.create	expected_receipt	cmpmp6ce6003pmtazo4stcw3v	{"productId": "cmpmob9c5000zmtaz5joihe1x", "orderedQty": 1}	2026-05-26 13:55:10.789
cmpmph3ha0041mtaz2pbd4hu6	cmpe6lgwq0009eityq7uocwm4	expected_receipt.update	expected_receipt	cmpmp6ce6003pmtazo4stcw3v	{"changes": {"comment": "test", "orderedQty": 1}}	2026-05-26 14:03:32.446
cmpmph91j0045mtazlalfv7jw	cmpe6lgwq0009eityq7uocwm4	expected_receipt.cancel	expected_receipt	cmpmp6ce6003pmtazo4stcw3v	\N	2026-05-26 14:03:39.655
cmpmpkxhk0003p9o5y1txgv4g	cmpe6lgwq0009eityq7uocwm4	expected_receipt.create	expected_receipt	cmpmpkxha0001p9o5jjbfgj9i	{"productId": "cmpmob9c5000zmtaz5joihe1x", "orderedQty": 5}	2026-05-26 14:06:31.304
cmpmpmnhe0007p9o57onxl91m	cmpf7cy2c000e9de7xtf3doa3	expected_receipt.close	expected_receipt	cmpmpkxha0001p9o5jjbfgj9i	{"comment": "приехало и уехало"}	2026-05-26 14:07:51.651
cmpmpn8cb000dp9o5givm6z4u	cmpf7cy2c000e9de7xtf3doa3	expected_receipt.create	expected_receipt	cmpmpn8c7000bp9o5tnw1ief6	{"productId": "cmpmob9c5000zmtaz5joihe1x", "orderedQty": 50}	2026-05-26 14:08:18.683
cmpmpngpx000hp9o5fid4x1t3	cmpf7cy2c000e9de7xtf3doa3	expected_receipt.cancel	expected_receipt	cmpmpn8c7000bp9o5tnw1ief6	{"comment": "отказ гвв"}	2026-05-26 14:08:29.541
cmpmqaa3t000sp9o5bn4jtapg	cmpe6lgwq0009eityq7uocwm4	export.shift_report.admin	export	\N	{"to": "2026-05-26T14:26:00.000Z", "from": "2026-05-25T21:00:00.000Z", "targetUserId": "cmpf7cy2c000e9de7xtf3doa3"}	2026-05-26 14:26:14.058
cmpmqeyfn000083b7d4jt49mt	cmpdz6zq70000qua72g7ns5dg	auth.login_failed	auth	cmpdz6zq70000qua72g7ns5dg	{"email": "admin@med.local", "reason": "disabled"}	2026-05-26 14:29:52.211
cmpmqf209000183b71egjjk76	cmpdz6zq70000qua72g7ns5dg	auth.login_failed	auth	cmpdz6zq70000qua72g7ns5dg	{"email": "admin@med.local", "reason": "disabled"}	2026-05-26 14:29:56.842
cmpmqjxd90002wibsfo1fx449	cmpe6lgwq0009eityq7uocwm4	export.shift_report.admin	export	\N	{"to": "2026-05-26T14:33:00.000Z", "from": "2026-05-25T21:00:00.000Z", "targetUserId": "cmpf7cy2c000e9de7xtf3doa3"}	2026-05-26 14:33:44.109
cmpnpz759006twibsshkyhx5i	cmpe8c28f000ft7005ljr56w2	auth.login	auth	cmpe8c28f000ft7005ljr56w2	{"email": "ds@medicine-2000.ru"}	2026-05-27 07:05:23.181
cmpnqfxq2006ywibsyulfj7pa	cmpf7cy2c000e9de7xtf3doa3	auth.login	auth	cmpf7cy2c000e9de7xtf3doa3	{"email": "sklad@navitek.biz"}	2026-05-27 07:18:24.122
cmpnr3d9600061o3jf9qj6rax	\N	product.quick_create	product	cmpnr3d9000041o3jlaqq5dmb	{"sku": "BC-0108022057012715240M7025", "name": "1727103021Ы1576918-Ф", "barcode": "0108022057012715240M7-025"}	2026-05-27 07:36:37.338
cmpnr98l2000e1o3jkji5kivd	\N	product.update	product	cmpnr3d9000041o3jlaqq5dmb	{"sku": "BC-0108022057012715240M7025", "changes": {"name": "1727103021Ы1576918-Ф", "barcode": "0108022057012715240M7-025"}}	2026-05-27 07:41:11.222
cmpnrsmeo000111hhq1lut84k	\N	product.delete_by_sku	product	\N	{"skus": ["BC-0108022057012715240M7025", "M7-025", "M7-027"], "before": {"lots": 2, "products": 3, "movements": 10, "movementIds": 10, "barcodeRecords": 3, "inventoryItems": 2, "expectedReceipts": 4, "expectedReceiptEvents": 10, "registrationCertificates": 2}, "source": "scripts/delete-products-by-sku.cjs", "deleted": {"products": 3, "barcodeRecords": 3}, "productIds": ["cmpnr3d9000041o3jlaqq5dmb", "cmpmob9c5000zmtaz5joihe1x", "cmpmo8lpv000smtaznrd18ujf"]}	2026-05-27 07:56:15.601
cmpnsrku1000cux95mxyvghui	cmpe6lgwq0009eityq7uocwm4	user.role_change	user	cmpdz6zqd0001qua7wn0v1ths	{"to": "MANAGER", "from": "OPERATOR", "email": "manager@med.local"}	2026-05-27 08:23:26.522
cmpnsrmd8000dux95zmge3l6d	cmpe6lgwq0009eityq7uocwm4	user.enable	user	cmpdz6zqd0001qua7wn0v1ths	{"email": "manager@med.local"}	2026-05-27 08:23:28.508
cmpnsrv7r000eux955a628oak	cmpe6lgwq0009eityq7uocwm4	user.password_reset	user	cmpdz6zqd0001qua7wn0v1ths	{"email": "manager@med.local"}	2026-05-27 08:23:39.975
cmpnssgrt000hux95r0af6i6r	cmpdz6zqd0001qua7wn0v1ths	auth.login	auth	cmpdz6zqd0001qua7wn0v1ths	{"email": "manager@med.local"}	2026-05-27 08:24:07.914
cmpnsx38k000mux95kgm5vgk9	cmpf7cy2c000e9de7xtf3doa3	auth.login	auth	cmpf7cy2c000e9de7xtf3doa3	{"email": "sklad@navitek.biz"}	2026-05-27 08:27:43.653
cmpnt57qi0002n76iobweds06	cmpdz6zqd0001qua7wn0v1ths	auth.logout	auth	cmpdz6zqd0001qua7wn0v1ths	\N	2026-05-27 08:34:02.73
cmpnt5e7f0003n76i2m6d1c13	cmpe6lgwq0009eityq7uocwm4	user.disable	user	cmpdz6zqd0001qua7wn0v1ths	{"email": "manager@med.local"}	2026-05-27 08:34:11.116
cmpntcke60008n76ihsu7egy6	\N	product.quick_create	product	cmpntcke20006n76i7wjc2ff3	{"sku": "M7-027", "name": "Протез сердечного клапана Carbomedics Standard", "barcode": "1729011921S1645411-A"}	2026-05-27 08:39:45.727
cmpntdyg7000dn76ibq8vlt0z	\N	product.quick_create	product	cmpntdyg3000bn76iim7di7no	{"sku": "M7-025", "name": "Протез сердечного клапана Carbomedics Standard", "barcode": "1727103021S1576918-A"}	2026-05-27 08:40:50.6
cmpntfjc5000kn76ihr3h4bjh	\N	product.quick_create	product	cmpntfjc0000in76ifj85ourl	{"sku": "BC-01054147340273661728040121180834129916001747593001", "name": "E100-23A", "barcode": "01054147340273661728040121180834129916001747593001"}	2026-05-27 08:42:04.326
cmpntht9q000wn76iosn2ejsy	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpntht99000pn76ip54lj79l	{"quantity": 1, "lotNumber": "S1645411-A", "productId": "cmpntcke20006n76i7wjc2ff3", "expectedReceiptId": null}	2026-05-27 08:43:50.51
cmpnthtad0016n76iddrxkb62	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpnthta5000zn76in32ckzay	{"quantity": 1, "lotNumber": "S1576918", "productId": "cmpntdyg3000bn76iim7di7no", "expectedReceiptId": null}	2026-05-27 08:43:50.533
cmpntnape0019n76it5uwdtrz	\N	product.quick_create	product	cmpntnapa0017n76inxtnsq8h	{"sku": "111111", "name": "тест", "barcode": "1111"}	2026-05-27 08:48:06.387
cmpntyeb3001gn76ii5yi4i5z	cmpe6lgwq0009eityq7uocwm4	auth.login	auth	cmpe6lgwq0009eityq7uocwm4	{"email": "am@medicine-2000.ru"}	2026-05-27 08:56:44.272
cmpntyv47001jn76i1zqx8s1o	\N	product.quick_create	product	cmpntyv42001hn76id66oeoz4	{"sku": "2222222", "name": "test2", "barcode": "22222"}	2026-05-27 08:57:06.055
cmpnufbcz00017rv12c2fcpux	\N	product.delete	product	cmpntfjc0000in76ifj85ourl	{"qty": {"total": 0, "reserved": 0}, "sku": "BC-01054147340273661728040121180834129916001747593001", "name": "E100-23A", "counts": {"lots": 0, "movements": 0, "inventoryRows": 0, "barcodeRecords": 1, "expectedReceipts": 0, "registrationCertificates": 0}, "forced": true, "actorEmail": "am@medicine-2000.ru"}	2026-05-27 09:09:53.603
cmpnufhgf00027rv1g7a8itz2	cmpe6lgwq0009eityq7uocwm4	user.role_change	user	cmpf7cy2c000e9de7xtf3doa3	{"to": "MANAGER", "from": "ADMIN", "email": "sklad@navitek.biz"}	2026-05-27 09:10:01.504
cmpnufws200047rv13w1p11bf	\N	product.delete	product	cmpntnapa0017n76inxtnsq8h	{"qty": {"total": 0, "reserved": 0}, "sku": "111111", "name": "тест", "counts": {"lots": 0, "movements": 0, "inventoryRows": 0, "barcodeRecords": 1, "expectedReceipts": 0, "registrationCertificates": 0}, "forced": true, "actorEmail": "am@medicine-2000.ru"}	2026-05-27 09:10:21.363
cmpnug0lh00067rv13igly4zq	\N	product.delete	product	cmpntyv42001hn76id66oeoz4	{"qty": {"total": 0, "reserved": 0}, "sku": "2222222", "name": "test2", "counts": {"lots": 0, "movements": 0, "inventoryRows": 0, "barcodeRecords": 1, "expectedReceipts": 0, "registrationCertificates": 0}, "forced": true, "actorEmail": "am@medicine-2000.ru"}	2026-05-27 09:10:26.31
cmpnuo2nd000d7rv10dwvxzv4	\N	product.quick_create	product	cmpnuo2n8000b7rv1zte3r9ps	{"sku": "11111", "name": "11111", "barcode": "111111"}	2026-05-27 09:16:42.217
cmpnuppsb000f7rv1qii17pcz	\N	product.delete	product	cmpnuo2n8000b7rv1zte3r9ps	{"qty": {"total": 0, "reserved": 0}, "sku": "11111", "name": "11111", "counts": {"lots": 0, "movements": 0, "inventoryRows": 0, "barcodeRecords": 1, "expectedReceipts": 0, "registrationCertificates": 0}, "forced": true, "actorEmail": "am@medicine-2000.ru"}	2026-05-27 09:17:58.859
cmpnurinc000k7rv1ooin3r35	\N	product.quick_create	product	cmpnurin8000i7rv12rzyl3yg	{"sku": "11111", "name": "1111", "barcode": "11111"}	2026-05-27 09:19:22.92
cmpnuvwyl0001l1t8cm6r6ebx	\N	product.delete	product	cmpnurin8000i7rv12rzyl3yg	{"qty": {"total": 0, "reserved": 0}, "sku": "11111", "name": "1111", "counts": {"lots": 0, "movements": 0, "inventoryRows": 0, "barcodeRecords": 1, "expectedReceipts": 0, "registrationCertificates": 0}, "forced": true, "actorEmail": "am@medicine-2000.ru"}	2026-05-27 09:22:48.094
cmpnv8e6w000438k8vjuuy0cv	\N	product.quick_create	product	cmpnv8e6s000238k8h4sgq8fu	{"sku": "BC-01054147340273661728040121180834129916001747593001", "name": "E100-23A", "barcode": "01054147340273661728040121180834129916001747593001"}	2026-05-27 09:32:30.297
cmpo3qrsv0003lwhz9hcvsyig	\N	product.delete	product	cmpo29o9g001gkjhf0803nfpf	{"qty": {"total": 0, "reserved": 0}, "sku": "111111", "name": "11111", "counts": {"lots": 0, "movements": 0, "inventoryRows": 0, "barcodeRecords": 1, "expectedReceipts": 0, "registrationCertificates": 0}, "forced": true, "actorEmail": "am@medicine-2000.ru"}	2026-05-27 13:30:44.672
cmpnvk6v1000938k8ap2ec5bq	cmpe6lgwq0009eityq7uocwm4	settings.update	system_settings	default	{"changes": {"fefoStrict": true, "fefoEnabled": true, "uiAnimations": true, "uiCompactMode": false, "warehouseCode": "WH-01", "warehouseName": "МЕД-ЛОГИСТИКА — Склад №1", "uiShowFefoHints": true, "scannerAutoFocus": true, "expiryWarningDays": 500, "scannerDebounceMs": 300, "expiryCriticalDays": 300, "notificationEnabled": true, "scannerSoundEnabled": true, "uiAutoRefreshDashboard": false, "activityHistoryRetentionDays": 90}}	2026-05-27 09:41:40.669
cmpnvl1ut000d38k8zdfs2d2z	cmpe6lgwq0009eityq7uocwm4	expected_receipt.create	expected_receipt	cmpnvl1ul000b38k8lmp38hjh	{"productId": "cmpnv8e6s000238k8h4sgq8fu", "orderedQty": 10}	2026-05-27 09:42:20.838
cmpnvs8cj000j38k8crz08i1t	cmpe6lgwq0009eityq7uocwm4	expected_receipt.close	expected_receipt	cmpnvl1ul000b38k8lmp38hjh	{"comment": "ВСё ок"}	2026-05-27 09:47:55.844
cmpnvwk4z000n38k8fqfu6b74	cmpe6lgwq0009eityq7uocwm4	user.create	user	cmpnvwk4x000m38k8kup32oc3	{"role": "MANAGER", "email": "juliko1402@yandex.ru"}	2026-05-27 09:51:17.748
cmpo0p3lh002k38k8uk43k0x4	cmpe6lgwq0009eityq7uocwm4	user.password_reset	user	cmpnvwk4x000m38k8kup32oc3	{"email": "juliko1402@yandex.ru"}	2026-05-27 12:05:27.798
cmpo0qmj7002l38k8xopdg7v2	cmpe6lgwq0009eityq7uocwm4	user.role_change	user	cmpdz6zqf0002qua7og3fmd74	{"to": "VIEWER", "from": "OPERATOR", "email": "operator@med.local"}	2026-05-27 12:06:38.995
cmpo0qo1p002m38k8tvutc3k4	cmpe6lgwq0009eityq7uocwm4	user.enable	user	cmpdz6zqf0002qua7og3fmd74	{"email": "operator@med.local"}	2026-05-27 12:06:40.957
cmpo0qsfa002n38k8kqafi1et	cmpe6lgwq0009eityq7uocwm4	user.password_reset	user	cmpdz6zqf0002qua7og3fmd74	{"email": "operator@med.local"}	2026-05-27 12:06:46.63
cmpo0r5q1002q38k89tdum4uf	cmpdz6zqf0002qua7og3fmd74	auth.login	auth	cmpdz6zqf0002qua7og3fmd74	{"email": "operator@med.local"}	2026-05-27 12:07:03.866
cmpo0ry8i002t38k8xpvoonww	cmpe6lgwq0009eityq7uocwm4	settings.update	system_settings	default	{"changes": {"fefoStrict": true, "fefoEnabled": true, "uiAnimations": true, "uiCompactMode": false, "warehouseCode": "WH-01", "warehouseName": "МЕД-ЛОГИСТИКА — Склад №1", "uiShowFefoHints": true, "scannerAutoFocus": true, "expiryWarningDays": 180, "scannerDebounceMs": 300, "expiryCriticalDays": 90, "notificationEnabled": true, "scannerSoundEnabled": true, "uiAutoRefreshDashboard": false, "activityHistoryRetentionDays": 90}}	2026-05-27 12:07:40.818
cmpo111m5002x38k89ne0gzki	\N	product.delete	product	cmpnv8e6s000238k8h4sgq8fu	{"qty": {"total": 0, "reserved": 0}, "sku": "BC-01054147340273661728040121180834129916001747593001", "name": "E100-23A", "counts": {"lots": 0, "movements": 0, "inventoryRows": 0, "barcodeRecords": 1, "expectedReceipts": 1, "registrationCertificates": 0}, "forced": true, "actorEmail": "am@medicine-2000.ru"}	2026-05-27 12:14:45.101
cmpo1pwo10002kjhfhlpgdtfb	\N	product.quick_create	product	cmpo1pwnt0000kjhfqt16rmd7	{"sku": "E100-23A", "name": "Протез клапана Epic Valve", "barcode": "01054147340273661728040121180834129916001747593001"}	2026-05-27 12:34:05.09
cmpo1pwou000ckjhfrp83eho2	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpo1pwoj0005kjhfxw8259b8	{"quantity": 1, "lotNumber": "180834129", "productId": "cmpo1pwnt0000kjhfqt16rmd7", "expectedReceiptId": null}	2026-05-27 12:34:05.118
cmpo1sc0o000fkjhf2by2hjpp	cmpf7cy2c000e9de7xtf3doa3	auth.login	auth	cmpf7cy2c000e9de7xtf3doa3	{"email": "sklad@navitek.biz"}	2026-05-27 12:35:58.296
cmpo1t4te000jkjhfw8g5m9dp	cmpf7cy2c000e9de7xtf3doa3	expected_receipt.create	expected_receipt	cmpo1t4t7000hkjhfwj40eqfb	{"productId": "cmpo1pwnt0000kjhfqt16rmd7", "orderedQty": 10}	2026-05-27 12:36:35.619
cmpo1yikn000okjhfeigizyl5	cmpnvwk4x000m38k8kup32oc3	auth.login	auth	cmpnvwk4x000m38k8kup32oc3	{"email": "juliko1402@yandex.ru"}	2026-05-27 12:40:46.727
cmpo21ku9000rkjhfd625ahjp	cmpe6lgwq0009eityq7uocwm4	user.role_change	user	cmpnvwk4x000m38k8kup32oc3	{"to": "ADMIN", "from": "MANAGER", "email": "juliko1402@yandex.ru"}	2026-05-27 12:43:09.634
cmpo21rw5000skjhfxprk88z6	cmpe6lgwq0009eityq7uocwm4	user.role_change	user	cmpnvwk4x000m38k8kup32oc3	{"to": "MANAGER", "from": "ADMIN", "email": "juliko1402@yandex.ru"}	2026-05-27 12:43:18.774
cmpo23lsn000ykjhfjttlycc3	cmpnvwk4x000m38k8kup32oc3	inventory.writeoff.batch	writeoff_batch	45e016ef-a872-485c-a3b0-fd448208a3ab	{"items": [{"lines": [{"lotId": "cmpmd6ug000401k2utmpqvni1", "quantity": 1}], "productId": "cmpmcw8dk002e1k2ue32kczgy", "references": ["ПЕР-0048"], "writeOffComment": null, "operationGroupId": "45e016ef-a872-485c-a3b0-fd448208a3ab", "writeOffDestinationId": "cmpfii3yx000lstrvkacz7ks2", "writeOffDestinationLabel": "ДГБ 2"}, {"lines": [{"lotId": "cmpntht99000pn76ip54lj79l", "quantity": 1}], "productId": "cmpntcke20006n76i7wjc2ff3", "references": ["ПЕР-0049"], "writeOffComment": null, "operationGroupId": "45e016ef-a872-485c-a3b0-fd448208a3ab", "writeOffDestinationId": "cmpfikajy000xstrvk9e0lrz6", "writeOffDestinationLabel": "ЛОКБ"}], "itemCount": 2, "lineCount": 2, "references": ["ПЕР-0048", "ПЕР-0049"], "operationGroupId": "45e016ef-a872-485c-a3b0-fd448208a3ab"}	2026-05-27 12:44:44.183
cmpo269zo0016kjhfyseytjhq	cmpnvwk4x000m38k8kup32oc3	inventory.writeoff.correct	writeoff_correction	45e016ef-a872-485c-a3b0-fd448208a3ab	{"additions": [], "editReason": "Клиент отказался от части товара", "operationGroupId": "45e016ef-a872-485c-a3b0-fd448208a3ab", "updatedReferences": ["ПЕР-0049"], "correctionSessionId": "7ccef2f3-0a3d-42dd-9ea7-a19104a9905c", "correctionReferences": ["ПЕР-0050"]}	2026-05-27 12:46:48.853
cmpo29o9j001ikjhfxr32h8wl	\N	product.quick_create	product	cmpo29o9g001gkjhf0803nfpf	{"sku": "111111", "name": "11111", "barcode": "11111"}	2026-05-27 12:49:27.32
cmpo29x5b0021kjhfff9k2xva	cmpe6lgwq0009eityq7uocwm4	user.role_change	user	cmpnvwk4x000m38k8kup32oc3	{"to": "ADMIN", "from": "MANAGER", "email": "juliko1402@yandex.ru"}	2026-05-27 12:49:38.832
cmpo2bjrn002kkjhfp64cfmpw	cmpe6lgwq0009eityq7uocwm4	user.role_change	user	cmpnvwk4x000m38k8kup32oc3	{"to": "MANAGER", "from": "ADMIN", "email": "juliko1402@yandex.ru"}	2026-05-27 12:50:54.804
cmpo2dgku002rkjhff7als40i	\N	product.quick_create	product	cmpo2dgkq002pkjhfeh3cfr2e	{"sku": "555", "name": "555", "barcode": "555"}	2026-05-27 12:52:23.983
cmpo2hj0u0009oyv8nxggjjfj	cmpe6lgwq0009eityq7uocwm4	inventory.receive	lot	cmpo2hj0k0002oyv86qpdxjnz	{"quantity": 10, "lotNumber": "555", "productId": "cmpo2dgkq002pkjhfeh3cfr2e", "expectedReceiptId": null}	2026-05-27 12:55:33.775
cmpo2ia6a000loyv8n04c87tx	cmpe6lgwq0009eityq7uocwm4	inventory.receive	lot	cmpo2hj0k0002oyv86qpdxjnz	{"quantity": 10, "lotNumber": "555", "productId": "cmpo2dgkq002pkjhfeh3cfr2e", "expectedReceiptId": null}	2026-05-27 12:56:08.962
cmpo3qp0g0001lwhz56zqrq1q	\N	product.delete	product	cmpo2dgkq002pkjhfeh3cfr2e	{"qty": {"total": 20, "reserved": 0}, "sku": "555", "name": "555", "counts": {"lots": 1, "movements": 2, "inventoryRows": 2, "barcodeRecords": 1, "expectedReceipts": 0, "registrationCertificates": 0}, "forced": true, "actorEmail": "am@medicine-2000.ru"}	2026-05-27 13:30:41.057
cmpo3rnsb0007lwhzqzlp4mos	\N	product.quick_create	product	cmpo3rns50004lwhzyxsgv65y	{"sku": "3333", "name": "333", "barcode": "333"}	2026-05-27 13:31:26.124
cmpo3rnt5000hlwhz2u8699hj	cmpe6lgwq0009eityq7uocwm4	inventory.receive	lot	cmpo3rnsu000alwhzzmy886gg	{"quantity": 10, "lotNumber": "3333", "productId": "cmpo3rns50004lwhzyxsgv65y", "expectedReceiptId": null}	2026-05-27 13:31:26.154
cmpo3rs11000jlwhzf3z10v0e	\N	product.delete	product	cmpo3rns50004lwhzyxsgv65y	{"qty": {"total": 10, "reserved": 0}, "sku": "3333", "name": "333", "counts": {"lots": 1, "movements": 1, "inventoryRows": 1, "barcodeRecords": 1, "expectedReceipts": 0, "registrationCertificates": 0}, "forced": true, "actorEmail": "am@medicine-2000.ru"}	2026-05-27 13:31:31.622
cmpo555kr0019lwhzb0em6qmd	cmpe6lgwq0009eityq7uocwm4	inventory.writeoff.batch	writeoff_batch	ПЕР-MPO555KN-A116B9C7	{"items": [{"lines": [{"lotId": "cmpnthta5000zn76in32ckzay", "quantity": 1}], "productId": "cmpntdyg3000bn76iim7di7no", "references": ["ПЕР-MPO555KN-A116B9C7"], "writeOffComment": "test", "operationGroupId": null, "writeOffDestinationId": "cmpfii3yx000lstrvkacz7ks2", "writeOffDestinationLabel": "ДГБ 2: test"}], "itemCount": 1, "lineCount": 1, "references": ["ПЕР-MPO555KN-A116B9C7"], "operationGroupId": null}	2026-05-27 14:09:55.323
cmpo5dd6e001clwhzc5l74fb1	cmpe6lgwq0009eityq7uocwm4	export.shift_report.admin	export	\N	{"to": "2026-05-27T14:16:00.000Z", "from": "2026-05-26T21:00:00.000Z", "targetUserId": "cmpf7cy2c000e9de7xtf3doa3"}	2026-05-27 14:16:18.423
cmpo6jj600020lwhzwnjsblev	\N	product.quick_create	product	cmpo6jj5u001xlwhz1ivbpqqh	{"sku": "ЫВАПЫВПЫВПА", "name": "ыувкпывпыв", "barcode": "23452346345652435327564745674"}	2026-05-27 14:49:05.736
cmpo6jj6r002alwhzr2i9prrh	cmpe6lgwq0009eityq7uocwm4	inventory.receive	lot	cmpo6jj6i0023lwhzyyvswtwg	{"quantity": 10, "lotNumber": "45364356346534", "productId": "cmpo6jj5u001xlwhz1ivbpqqh", "expectedReceiptId": null}	2026-05-27 14:49:05.763
cmpo6txhz002klwhzau626q1v	\N	product.delete	product	cmpo6jj5u001xlwhz1ivbpqqh	{"qty": {"total": 10, "reserved": 0}, "sku": "ЫВАПЫВПЫВПА", "name": "ыувкпывпыв", "counts": {"lots": 1, "movements": 1, "inventoryRows": 1, "barcodeRecords": 1, "expectedReceipts": 0, "registrationCertificates": 0}, "forced": true, "actorEmail": "am@medicine-2000.ru"}	2026-05-27 14:57:10.872
cmpp6g49f00dwlwhz3z218cpw	cmpe6lgwq0009eityq7uocwm4	inventory.writeoff.correct	writeoff_correction	45e016ef-a872-485c-a3b0-fd448208a3ab	{"additions": [], "editReason": "Менеджер ошибся", "operationGroupId": "45e016ef-a872-485c-a3b0-fd448208a3ab", "updatedReferences": ["ПЕР-0048"], "correctionSessionId": "14a7cc0f-749d-4d18-b621-5034e95f4d13", "correctionReferences": ["ПЕР-MPP6G49C-B2D957BF"]}	2026-05-28 07:34:12.627
cmpp6hn1y00e4lwhzy7t679z2	cmpe6lgwq0009eityq7uocwm4	inventory.writeoff.correct	writeoff_correction	45e016ef-a872-485c-a3b0-fd448208a3ab	{"additions": [], "editReason": "Коррекция после проверки", "operationGroupId": "45e016ef-a872-485c-a3b0-fd448208a3ab", "updatedReferences": ["ПЕР-0048"], "correctionSessionId": "4af62a13-12d2-4644-81f1-fcd4dab782a1", "correctionReferences": ["ПЕР-MPP6HN1W-E5F66AF7"]}	2026-05-28 07:35:23.639
cmpp6jqlp00e5lwhztkowrntu	cmpe6lgwq0009eityq7uocwm4	settings.update	system_settings	default	{"changes": {"fefoStrict": true, "fefoEnabled": true, "uiAnimations": true, "uiCompactMode": false, "warehouseCode": "WH-01", "warehouseName": "МЕД-ЛОГИСТИКА — Склад №1", "uiShowFefoHints": true, "scannerAutoFocus": true, "expiryWarningDays": 500, "scannerDebounceMs": 300, "expiryCriticalDays": 300, "notificationEnabled": true, "scannerSoundEnabled": true, "uiAutoRefreshDashboard": false, "activityHistoryRetentionDays": 90}}	2026-05-28 07:37:01.549
cmpp6l9qm00e8lwhz27qw7mtc	cmpe6lgwq0009eityq7uocwm4	settings.update	system_settings	default	{"changes": {"fefoStrict": true, "fefoEnabled": true, "uiAnimations": true, "uiCompactMode": false, "warehouseCode": "WH-01", "warehouseName": "МЕД-ЛОГИСТИКА — Склад №1", "uiShowFefoHints": true, "scannerAutoFocus": true, "expiryWarningDays": 180, "scannerDebounceMs": 300, "expiryCriticalDays": 90, "notificationEnabled": true, "scannerSoundEnabled": true, "uiAutoRefreshDashboard": false, "activityHistoryRetentionDays": 90}}	2026-05-28 07:38:13.006
cmpp6qr2l00eblwhzem1nc38w	cmpe6lgwq0009eityq7uocwm4	user.disable	user	cmpdz6zqf0002qua7og3fmd74	{"email": "operator@med.local"}	2026-05-28 07:42:28.75
cmpp6r86h00eclwhz74qjttva	cmpe6lgwq0009eityq7uocwm4	export.shift_report.admin	export	\N	{"to": "2026-05-27T20:59:00.000Z", "from": "2026-05-26T21:00:00.000Z", "targetUserId": "cmpf7cy2c000e9de7xtf3doa3"}	2026-05-28 07:42:50.922
cmpp6wini00eglwhz0sigih38	cmpe6lgwq0009eityq7uocwm4	expected_receipt.create	expected_receipt	cmpp6winf00eelwhzcig1gxvo	{"productId": "cmpmd2sbq002p1k2u5ssy3lfs", "orderedQty": 100}	2026-05-28 07:46:57.775
cmpp8ju9f00f1lwhzcvoyqp7j	cmpf7cy2c000e9de7xtf3doa3	auth.login	auth	cmpf7cy2c000e9de7xtf3doa3	{"email": "sklad@navitek.biz"}	2026-05-28 08:33:05.523
cmpp90k9100fblwhzsh1jy2u3	\N	product.quick_create	product	cmpp90k8x00f8lwhzc131jr4n	{"sku": "M00542250", "name": "SpeedBand Super 7", "barcode": "0108714729201953172611281038145722"}	2026-05-28 08:46:05.702
cmpp90k9n00fllwhz0eb3c9sp	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpp90k9g00felwhzcknrtgyp	{"quantity": 1, "lotNumber": "38145722", "productId": "cmpp90k8x00f8lwhzc131jr4n", "expectedReceiptId": null}	2026-05-28 08:46:05.723
cmppk1mfc0008vpadivmnqs16	cmpe6lgwq0009eityq7uocwm4	auth.login	auth	cmpe6lgwq0009eityq7uocwm4	{"email": "am@medicine-2000.ru"}	2026-05-28 13:54:50.952
cmppluiqk0006yszbptjf22rm	cmpe8c28f000ft7005ljr56w2	auth.login	auth	cmpe8c28f000ft7005ljr56w2	{"email": "ds@medicine-2000.ru"}	2026-05-28 14:45:18.812
cmppm7cph0002rpb8opahl1d1	cmpe6lgwq0009eityq7uocwm4	auth.login	auth	cmpe6lgwq0009eityq7uocwm4	{"email": "am@medicine-2000.ru"}	2026-05-28 14:55:17.525
cmppni66d0000h1svbc9fqgz1	cmpe6lgwq0009eityq7uocwm4	user.role_change	user	cmpdz6zqf0002qua7og3fmd74	{"to": "OPERATOR", "from": "VIEWER", "email": "operator@med.local"}	2026-05-28 15:31:41.893
cmppni7qi0001h1svyvuwtkr6	cmpe6lgwq0009eityq7uocwm4	user.enable	user	cmpdz6zqf0002qua7og3fmd74	{"email": "operator@med.local"}	2026-05-28 15:31:43.914
cmppnidzg0002h1svxly11stl	cmpe6lgwq0009eityq7uocwm4	user.password_reset	user	cmpdz6zqf0002qua7og3fmd74	{"email": "operator@med.local"}	2026-05-28 15:31:52.012
cmppnj0lf0005h1sveyc785ww	cmpdz6zqf0002qua7og3fmd74	auth.login	auth	cmpdz6zqf0002qua7og3fmd74	{"email": "operator@med.local"}	2026-05-28 15:32:21.315
cmppod8vs000214cgmhk07tlf	cmpe6lgwq0009eityq7uocwm4	auth.login	auth	cmpe6lgwq0009eityq7uocwm4	{"email": "am@medicine-2000.ru"}	2026-05-28 15:55:51.737
cmppr2mas0007jmgsw9e3befq	cmpe6lgwq0009eityq7uocwm4	writeoff_destination.create	writeoff_destination	cmppr2maq0006jmgswvucq5ie	{"name": "Елизаветинская"}	2026-05-28 17:11:34.756
cmprbf24n004qct53qqxxhohv	cmpe6lgwq0009eityq7uocwm4	product_name_catalog.delete	product_name_catalog	cmpqzal6y000rct53ywlbkk8u	{"name": "т"}	2026-05-29 19:28:53.64
cmppr371b000djmgs1rsl5noa	cmpe6lgwq0009eityq7uocwm4	inventory.writeoff.batch	writeoff_batch	b087203d-99b9-4c8b-beb1-603167bf99de	{"items": [{"lines": [{"lotId": "cmpp90k9g00felwhzcknrtgyp", "quantity": 1}], "productId": "cmpp90k8x00f8lwhzc131jr4n", "references": ["ПЕР-MPPR3711-E3D3A6B4"], "shipmentId": "cmppn09b20005zs2f23n8cyb9", "writeOffComment": "поз. 1", "operationGroupId": "b087203d-99b9-4c8b-beb1-603167bf99de", "writeOffDestinationId": "cmppr2maq0006jmgswvucq5ie", "writeOffDestinationLabel": "Елизаветинская: поз. 1"}, {"lines": [{"lotId": "cmpmcin2m000p1k2u5ei1n17o", "quantity": 1}], "productId": "cmpmcfey600021k2uw7js511b", "references": ["ПЕР-MPPR371A-5B5527A4"], "shipmentId": "cmppn09b20005zs2f23n8cyb9", "writeOffComment": "поз. 2", "operationGroupId": "b087203d-99b9-4c8b-beb1-603167bf99de", "writeOffDestinationId": "cmppr2maq0006jmgswvucq5ie", "writeOffDestinationLabel": "Елизаветинская: поз. 2"}], "itemCount": 2, "lineCount": 2, "references": ["ПЕР-MPPR3711-E3D3A6B4", "ПЕР-MPPR371A-5B5527A4"], "shipmentId": "cmppn09b20005zs2f23n8cyb9", "operationGroupId": "b087203d-99b9-4c8b-beb1-603167bf99de"}	2026-05-28 17:12:01.632
cmppro1xq000sjmgsu6vhhayi	cmpe6lgwq0009eityq7uocwm4	auth.login	auth	cmpe6lgwq0009eityq7uocwm4	{"email": "am@medicine-2000.ru"}	2026-05-28 17:28:14.798
cmppyt9n7003bjmgs9fc36gtd	cmpe6lgwq0009eityq7uocwm4	export.shift_report	export	\N	{"to": "2026-05-28T20:48:00.000Z", "from": "2026-05-27T21:00:00.000Z", "targetUserId": "cmpe6lgwq0009eityq7uocwm4"}	2026-05-28 20:48:15.379
cmpqkol3z00a6jmgsaxxt5w7r	cmpfl6gyd000zjzrra4c7q7u0	auth.login	auth	cmpfl6gyd000zjzrra4c7q7u0	{"email": "ekaterina.s@navitek.biz"}	2026-05-29 07:00:28.511
cmpqkow8n00a7jmgs445g5qqy	cmpfl6gyd000zjzrra4c7q7u0	auth.logout	auth	cmpfl6gyd000zjzrra4c7q7u0	\N	2026-05-29 07:00:42.936
cmpqkp8xz00aajmgsw9uxyuru	cmpe6lgwq0009eityq7uocwm4	auth.login	auth	cmpe6lgwq0009eityq7uocwm4	{"email": "am@medicine-2000.ru"}	2026-05-29 07:00:59.399
cmpqkpdz000abjmgstteie2ki	cmpe6lgwq0009eityq7uocwm4	user.role_change	user	cmpfl6gyd000zjzrra4c7q7u0	{"to": "MANAGER", "from": "VIEWER", "email": "ekaterina.s@navitek.biz"}	2026-05-29 07:01:05.917
cmpqkpfpk00aejmgsnlsyqzep	cmpe6lgwq0009eityq7uocwm4	auth.logout	auth	cmpe6lgwq0009eityq7uocwm4	\N	2026-05-29 07:01:08.168
cmpqkphx400ahjmgsmxyw4hd5	cmpfl6gyd000zjzrra4c7q7u0	auth.login	auth	cmpfl6gyd000zjzrra4c7q7u0	{"email": "ekaterina.s@navitek.biz"}	2026-05-29 07:01:11.032
cmpqkzx5t00awjmgs8lwyk87t	cmpdz6zqf0002qua7og3fmd74	auth.login	auth	cmpdz6zqf0002qua7og3fmd74	{"email": "operator@med.local"}	2026-05-29 07:09:17.346
cmpql4x7q00b8jmgswji4t8vj	cmpfl6gyd000zjzrra4c7q7u0	writeoff_destination.create	writeoff_destination	cmpql4x7p00b7jmgsqnauerpa	{"name": "ГКОД"}	2026-05-29 07:13:10.695
cmpql616600bgjmgsg0oj4e1g	cmpdz6zqf0002qua7og3fmd74	inventory.writeoff.batch	writeoff_batch	4730c0c1-2966-4d0f-90e3-42a62839166e	{"items": [{"lines": [{"lotId": "cmpmcnzbq00141k2uo7ty8scw", "quantity": 10}], "productId": "cmpmcljje000z1k2uewbthv27", "references": ["ПЕР-MPQL615Z-4D4AB730"], "shipmentId": "cmpqkwdmv00amjmgsbbhwlo90", "writeOffComment": "поз. 1", "operationGroupId": "4730c0c1-2966-4d0f-90e3-42a62839166e", "writeOffDestinationId": "cmpql4x7p00b7jmgsqnauerpa", "writeOffDestinationLabel": "ГКОД: поз. 1"}, {"lines": [{"lotId": "cmpo1pwoj0005kjhfxw8259b8", "quantity": 1}], "productId": "cmpo1pwnt0000kjhfqt16rmd7", "references": ["ПЕР-MPQL6164-57EB4BB0"], "shipmentId": "cmpqkwdmv00amjmgsbbhwlo90", "writeOffComment": "поз. 2", "operationGroupId": "4730c0c1-2966-4d0f-90e3-42a62839166e", "writeOffDestinationId": "cmpql4x7p00b7jmgsqnauerpa", "writeOffDestinationLabel": "ГКОД: поз. 2"}], "itemCount": 2, "lineCount": 2, "references": ["ПЕР-MPQL615Z-4D4AB730", "ПЕР-MPQL6164-57EB4BB0"], "shipmentId": "cmpqkwdmv00amjmgsbbhwlo90", "operationGroupId": "4730c0c1-2966-4d0f-90e3-42a62839166e"}	2026-05-29 07:14:02.478
cmpql6wjg00bmjmgsk5rwopm7	cmpdz6zqf0002qua7og3fmd74	auth.logout	auth	cmpdz6zqf0002qua7og3fmd74	\N	2026-05-29 07:14:43.133
cmpqlc94900brjmgsfsfgaows	cmpe6lgwq0009eityq7uocwm4	auth.login	auth	cmpe6lgwq0009eityq7uocwm4	{"email": "am@medicine-2000.ru"}	2026-05-29 07:18:52.713
cmpqlms4100c2jmgsoe0ohvwq	cmpe8c28f000ft7005ljr56w2	auth.login	auth	cmpe8c28f000ft7005ljr56w2	{"email": "ds@medicine-2000.ru"}	2026-05-29 07:27:03.889
cmpqm5wde00cpjmgs2mh17cin	cmpe8c28f000ft7005ljr56w2	auth.login	auth	cmpe8c28f000ft7005ljr56w2	{"email": "ds@medicine-2000.ru"}	2026-05-29 07:41:55.875
cmpqq3fzo000213pkyaakpbpu	cmpe8c28f000ft7005ljr56w2	auth.login	auth	cmpe8c28f000ft7005ljr56w2	{"email": "ds@medicine-2000.ru"}	2026-05-29 09:31:59.796
cmpqrbsri000h13pk3euga96e	cmpfl6gyd000zjzrra4c7q7u0	auth.login	auth	cmpfl6gyd000zjzrra4c7q7u0	{"email": "ekaterina.s@navitek.biz"}	2026-05-29 10:06:29.214
cmpqtmzu00002t2okezjty5sk	cmpdz6zq70000qua72g7ns5dg	auth.login_failed	auth	cmpdz6zq70000qua72g7ns5dg	{"email": "admin@med.local", "reason": "disabled"}	2026-05-29 11:11:10.824
cmpqtn33f0003t2ok76xn48aj	cmpdz6zq70000qua72g7ns5dg	auth.login_failed	auth	cmpdz6zq70000qua72g7ns5dg	{"email": "admin@med.local", "reason": "disabled"}	2026-05-29 11:11:15.051
cmpqx06qu0002d0fl2ynl87cp	cmpdz6zq70000qua72g7ns5dg	auth.login_failed	auth	cmpdz6zq70000qua72g7ns5dg	{"email": "admin@med.local", "reason": "disabled"}	2026-05-29 12:45:25.158
cmpqx0ep70003d0fly4rz02jz	cmpdz6zq70000qua72g7ns5dg	auth.login_failed	auth	cmpdz6zq70000qua72g7ns5dg	{"email": "admin@med.local", "reason": "disabled"}	2026-05-29 12:45:35.468
cmpqx20640006d0fl7wdwg0qc	cmpf7cy2c000e9de7xtf3doa3	auth.login	auth	cmpf7cy2c000e9de7xtf3doa3	{"email": "sklad@navitek.biz"}	2026-05-29 12:46:49.948
cmpqxv8c300049gxnr44uhwvb	cmpe6lgwq0009eityq7uocwm4	auth.login	auth	cmpe6lgwq0009eityq7uocwm4	{"email": "am@medicine-2000.ru"}	2026-05-29 13:09:33.555
cmpqz7h9k0009ct538gm9hsmb	\N	product.quick_create	product	cmpqz7h920006ct53ns5ughlq	{"sku": "12341234", "name": "тест", "barcode": "135423523452345"}	2026-05-29 13:47:04.616
cmpqz7hb8000kct53yuns9kwk	cmpe6lgwq0009eityq7uocwm4	inventory.receive	lot	cmpqz7hag000dct53orf8wb6n	{"quantity": 5, "lotNumber": "214123412", "productId": "cmpqz7h920006ct53ns5ughlq", "expectedReceiptId": null}	2026-05-29 13:47:04.677
cmpqzal6w000qct53pcghmovr	\N	product.quick_create	product	cmpqzal6r000nct536dw7ekwc	{"sku": "Т", "name": "т", "barcode": "0108714729296386172701081038296268"}	2026-05-29 13:49:29.672
cmpqzal7p0011ct53ej7hv0cq	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpqzal7g000uct53h62s8sui	{"quantity": 1, "lotNumber": "38296268", "productId": "cmpqzal6r000nct536dw7ekwc", "expectedReceiptId": null}	2026-05-29 13:49:29.701
cmpqzoe41001uct53utjiimea	cmpe8c28f000ft7005ljr56w2	expected_receipt.create	expected_receipt	cmpqzoe3r001sct53ti5k83r8	{"productId": "cmpmd2sbq002p1k2u5ssy3lfs", "orderedQty": 10}	2026-05-29 14:00:13.681
cmpqzr6x10026ct53z5p0zd88	cmpf7cy2c000e9de7xtf3doa3	inventory.receive	lot	cmpqzr6ws001zct531qe1ktgx	{"quantity": 1, "lotNumber": "34224556", "productId": "cmpqzal6r000nct536dw7ekwc", "expectedReceiptId": null}	2026-05-29 14:02:24.325
cmprbdp6t004nct53ckjlwdw9	cmpe6lgwq0009eityq7uocwm4	auth.login	auth	cmpe6lgwq0009eityq7uocwm4	{"email": "am@medicine-2000.ru"}	2026-05-29 19:27:50.213
cmps385b400c1ct53lrvaanw0	cmpe6lgwq0009eityq7uocwm4	auth.login	auth	cmpe6lgwq0009eityq7uocwm4	{"email": "am@medicine-2000.ru"}	2026-05-30 08:27:20.417
cmps3xalm00ccct536rtdjzs4	cmpe6lgwq0009eityq7uocwm4	auth.login	auth	cmpe6lgwq0009eityq7uocwm4	{"email": "am@medicine-2000.ru"}	2026-05-30 08:46:53.675
cmps4pq4700025wf81emel9cy	cmpe6lgwq0009eityq7uocwm4	user.role_change	user	cmpnvwk4x000m38k8kup32oc3	{"to": "ACCOUNTANT", "from": "MANAGER", "email": "juliko1402@yandex.ru"}	2026-05-30 09:09:00.151
cmps4pq4800035wf84q9z6bia	cmpe6lgwq0009eityq7uocwm4	user.permissions_change	user	cmpnvwk4x000m38k8kup32oc3	{"email": "juliko1402@yandex.ru"}	2026-05-30 09:09:00.153
cmps57ir500049vf24e7damev	cmpe6lgwq0009eityq7uocwm4	user.permissions_change	user	cmpnvwk4x000m38k8kup32oc3	{"email": "juliko1402@yandex.ru"}	2026-05-30 09:22:50.418
cmps57n3f00059vf2rav7aom0	cmpe6lgwq0009eityq7uocwm4	user.permissions_change	user	cmpnvwk4x000m38k8kup32oc3	{"email": "juliko1402@yandex.ru"}	2026-05-30 09:22:56.043
cmps5bap900069vf2egye9j6o	cmpe6lgwq0009eityq7uocwm4	role_permissions.update	role_permissions	MANAGER	{"keys": 1, "role": "MANAGER"}	2026-05-30 09:25:46.605
cmps5bo5u00079vf2k3x39alv	cmpe6lgwq0009eityq7uocwm4	role_permissions.update	role_permissions	MANAGER	{"keys": 0, "role": "MANAGER"}	2026-05-30 09:26:04.05
cmps5kfff000a9vf2oqpjuhln	cmpe6lgwq0009eityq7uocwm4	role_permissions.update	role_permissions	ACCOUNTANT	{"keys": 2, "role": "ACCOUNTANT"}	2026-05-30 09:32:52.636
cmps5knu0000b9vf267ouo90x	cmpe6lgwq0009eityq7uocwm4	role_permissions.update	role_permissions	ACCOUNTANT	{"keys": 0, "role": "ACCOUNTANT"}	2026-05-30 09:33:03.529
cmps5t9q2000e9vf2xeltlse0	cmpe6lgwq0009eityq7uocwm4	role_permissions.update	role_permissions	ACCOUNTANT	{"keys": 2, "role": "ACCOUNTANT"}	2026-05-30 09:39:45.146
cmps5titb000f9vf2jdnpm9zp	cmpe6lgwq0009eityq7uocwm4	role_permissions.update	role_permissions	ACCOUNTANT	{"keys": 0, "role": "ACCOUNTANT"}	2026-05-30 09:39:56.928
cmps6nzph000o9vf2jfbkewyp	cmpe6lgwq0009eityq7uocwm4	user.permissions_change	user	cmpnvwk4x000m38k8kup32oc3	{"email": "juliko1402@yandex.ru"}	2026-05-30 10:03:38.501
cmps6o4es000p9vf2c7o5zm9l	cmpe6lgwq0009eityq7uocwm4	user.permissions_change	user	cmpnvwk4x000m38k8kup32oc3	{"email": "juliko1402@yandex.ru"}	2026-05-30 10:03:44.596
cmps6obxq000q9vf21do067uw	cmpe6lgwq0009eityq7uocwm4	user.permissions_change	user	cmpnvwk4x000m38k8kup32oc3	{"email": "juliko1402@yandex.ru"}	2026-05-30 10:03:54.35
cmps6p19h000t9vf2knc9zjrp	cmpe6lgwq0009eityq7uocwm4	user.permissions_change	user	cmpnvwk4x000m38k8kup32oc3	{"email": "juliko1402@yandex.ru"}	2026-05-30 10:04:27.173
cmps6va60000u9vf237n1sbtp	cmpe6lgwq0009eityq7uocwm4	user.permissions_change	user	cmpnvwk4x000m38k8kup32oc3	{"email": "juliko1402@yandex.ru"}	2026-05-30 10:09:18.649
cmps6vemp000v9vf2uhetacpl	cmpe6lgwq0009eityq7uocwm4	user.permissions_change	user	cmpnvwk4x000m38k8kup32oc3	{"email": "juliko1402@yandex.ru"}	2026-05-30 10:09:24.433
cmps6vjum000w9vf24suve7pf	cmpe6lgwq0009eityq7uocwm4	user.permissions_change	user	cmpnvwk4x000m38k8kup32oc3	{"email": "juliko1402@yandex.ru"}	2026-05-30 10:09:31.199
cmps6vopx000x9vf273q6o6xv	cmpe6lgwq0009eityq7uocwm4	user.permissions_change	user	cmpnvwk4x000m38k8kup32oc3	{"email": "juliko1402@yandex.ru"}	2026-05-30 10:09:37.51
cmps6vsi5000y9vf2ey61ol96	cmpe6lgwq0009eityq7uocwm4	user.permissions_change	user	cmpnvwk4x000m38k8kup32oc3	{"email": "juliko1402@yandex.ru"}	2026-05-30 10:09:42.414
cmps6vvhu000z9vf2gs380ui9	cmpe6lgwq0009eityq7uocwm4	user.permissions_change	user	cmpnvwk4x000m38k8kup32oc3	{"email": "juliko1402@yandex.ru"}	2026-05-30 10:09:46.291
cmps7l55y00169vf2iphylxyx	cmpe6lgwq0009eityq7uocwm4	user.permissions_change	user	cmpnvwk4x000m38k8kup32oc3	{"email": "juliko1402@yandex.ru"}	2026-05-30 10:29:25.221
cmps7lh5800179vf2cns6a23c	cmpe6lgwq0009eityq7uocwm4	user.permissions_change	user	cmpnvwk4x000m38k8kup32oc3	{"email": "juliko1402@yandex.ru"}	2026-05-30 10:29:40.749
cmps7vq80001a9vf2otq2l9zm	cmpe6lgwq0009eityq7uocwm4	user.permissions_change	user	cmpnvwk4x000m38k8kup32oc3	{"email": "juliko1402@yandex.ru"}	2026-05-30 10:37:39.073
cmps7vyd9001b9vf2mqn3cnsp	cmpe6lgwq0009eityq7uocwm4	user.permissions_change	user	cmpnvwk4x000m38k8kup32oc3	{"email": "juliko1402@yandex.ru"}	2026-05-30 10:37:49.629
cmps7ypr9001c9vf2qcmij3yt	cmpe6lgwq0009eityq7uocwm4	user.permissions_change	user	cmpnvwk4x000m38k8kup32oc3	{"email": "juliko1402@yandex.ru"}	2026-05-30 10:39:58.437
cmps82t73001f9vf2ttu7bwnt	cmpe6lgwq0009eityq7uocwm4	user.permissions_change	user	cmpnvwk4x000m38k8kup32oc3	{"email": "juliko1402@yandex.ru"}	2026-05-30 10:43:09.518
cmps82w7b001g9vf2vefjefgx	cmpe6lgwq0009eityq7uocwm4	user.permissions_change	user	cmpnvwk4x000m38k8kup32oc3	{"email": "juliko1402@yandex.ru"}	2026-05-30 10:43:13.415
cmps83aet001h9vf29s6ylqd0	cmpe6lgwq0009eityq7uocwm4	user.permissions_change	user	cmpnvwk4x000m38k8kup32oc3	{"email": "juliko1402@yandex.ru"}	2026-05-30 10:43:31.829
cmps8aw4z00021v108uemouzn	cmpe6lgwq0009eityq7uocwm4	user.permissions_change	user	cmpnvwk4x000m38k8kup32oc3	{"email": "juliko1402@yandex.ru"}	2026-05-30 10:49:26.579
cmps8b9hq00031v10egvbx3ru	cmpe6lgwq0009eityq7uocwm4	user.role_change	user	cmpf7cy2c000e9de7xtf3doa3	{"to": "OPERATOR", "from": "MANAGER", "email": "sklad@navitek.biz"}	2026-05-30 10:49:43.886
cmps8b9hr00041v10xx3v56nl	cmpe6lgwq0009eityq7uocwm4	user.permissions_change	user	cmpf7cy2c000e9de7xtf3doa3	{"email": "sklad@navitek.biz"}	2026-05-30 10:49:43.888
cmps8bvnm00051v10sh5d260x	cmpe6lgwq0009eityq7uocwm4	user.permissions_change	user	cmpf7cy2c000e9de7xtf3doa3	{"email": "sklad@navitek.biz"}	2026-05-30 10:50:12.611
cmps8eecu00081v104fl3l2q3	cmpe6lgwq0009eityq7uocwm4	user.permissions_change	user	cmpf7cy2c000e9de7xtf3doa3	{"email": "sklad@navitek.biz"}	2026-05-30 10:52:10.159
cmps8grc0000b1v10w8asg1ep	cmpe6lgwq0009eityq7uocwm4	auth.logout	auth	cmpe6lgwq0009eityq7uocwm4	\N	2026-05-30 10:54:00.289
cmps8gv2w000c1v10ilr4xzjp	cmpdz6zqf0002qua7og3fmd74	auth.login_failed	auth	cmpdz6zqf0002qua7og3fmd74	{"email": "operator@med.local", "reason": "invalid_password"}	2026-05-30 10:54:05.144
cmps8gwnz000f1v109miiurnq	cmpdz6zqf0002qua7og3fmd74	auth.login	auth	cmpdz6zqf0002qua7og3fmd74	{"email": "operator@med.local"}	2026-05-30 10:54:07.199
cmps8j3hc000k1v108c4zmuqv	cmpe6lgwq0009eityq7uocwm4	user.disable	user	cmpdz6zqf0002qua7og3fmd74	{"email": "operator@med.local"}	2026-05-30 10:55:49.344
cmps8k78d000l1v10ybslmelx	cmpe6lgwq0009eityq7uocwm4	role_permissions.update	role_permissions	OPERATOR	{"keys": 1, "role": "OPERATOR"}	2026-05-30 10:56:40.861
cmps8kiil000m1v10xx2f4xvc	cmpe6lgwq0009eityq7uocwm4	user.enable	user	cmpdz6zqf0002qua7og3fmd74	{"email": "operator@med.local"}	2026-05-30 10:56:55.486
cmps8km67000p1v10a3cqbi26	cmpdz6zqf0002qua7og3fmd74	auth.login	auth	cmpdz6zqf0002qua7og3fmd74	{"email": "operator@med.local"}	2026-05-30 10:57:00.223
cmps8t4zq00025ivgpvv4oet8	cmpdz6zqf0002qua7og3fmd74	auth.login_failed	auth	cmpdz6zqf0002qua7og3fmd74	{"email": "operator@med.local", "reason": "invalid_password"}	2026-05-30 11:03:37.862
cmps8t7u200035ivg67a4zc18	cmpdz6zqf0002qua7og3fmd74	auth.login_failed	auth	cmpdz6zqf0002qua7og3fmd74	{"email": "operator@med.local", "reason": "invalid_password"}	2026-05-30 11:03:41.546
cmps8t7uh00045ivgez4zcabh	cmpdz6zq70000qua72g7ns5dg	auth.login_failed	auth	cmpdz6zq70000qua72g7ns5dg	{"email": "admin@med.local", "reason": "disabled"}	2026-05-30 11:03:41.561
cmps8y6wl00046sxnps0qedbd	cmpe6lgwq0009eityq7uocwm4	auth.login	auth	cmpe6lgwq0009eityq7uocwm4	{"email": "am@medicine-2000.ru"}	2026-05-30 11:07:33.622
\.


--
-- Data for Name: barcode_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.barcode_records (id, barcode, product_id, lot_id, created_at, updated_at) FROM stdin;
cmpo1pwnt0001kjhf5ttnb10s	01054147340273661728040121180834129916001747593001	cmpo1pwnt0000kjhfqt16rmd7	cmpo1pwoj0005kjhfxw8259b8	2026-05-27 12:34:05.081	2026-05-27 12:34:05.112
cmpmcfey600031k2u8d8k8ij2	0108714729786924172711121037941736	cmpmcfey600021k2uw7js511b	cmpmcin2m000p1k2u5ei1n17o	2026-05-26 07:58:18.99	2026-05-26 08:00:49.491
cmpmcljje00101k2unfu9jcw4	0108714729786917172801211038404581	cmpmcljje000z1k2uewbthv27	cmpmcnzcc001e1k2um5miuq8n	2026-05-26 08:03:04.874	2026-05-26 08:04:58.672
cmpp90k9000falwhzh0ocn0bc	0108714729201953172611281038145722	cmpp90k8x00f8lwhzc131jr4n	cmpp90k9g00felwhzcknrtgyp	2026-05-28 08:46:05.7	2026-05-28 08:46:05.72
cmpqz7h9f0008ct53c1k97zok	135423523452345	cmpqz7h920006ct53ns5ughlq	cmpqz7hag000dct53orf8wb6n	2026-05-29 13:47:04.611	2026-05-29 13:47:04.664
cmpqzal6u000pct5357tugk3h	0108714729296386172701081038296268	cmpqzal6r000nct536dw7ekwc	cmpqzal7g000uct53h62s8sui	2026-05-29 13:49:29.67	2026-05-29 13:49:29.697
cmpqzr6w7001wct53ztrozut9	0108714729296393172506121034224556	cmpqzal6r000nct536dw7ekwc	cmpqzr6ws001zct531qe1ktgx	2026-05-29 14:02:24.296	2026-05-29 14:02:24.321
cmpmcu0rt002a1k2uykmbemnc	0108714729786955172803041038758114	cmpmcu0rt00291k2ushag980x	cmpmd6uei00361k2unt434b1k	2026-05-26 08:09:40.457	2026-05-26 08:19:38.733
cmpmcw8dk002f1k2udgdq49p1	0108714729786948172801051038263611	cmpmcw8dk002e1k2ue32kczgy	cmpmd6ug000401k2utmpqvni1	2026-05-26 08:11:23.625	2026-05-26 08:19:38.788
cmpmd0lfz002k1k2u8b8zyvx4	0108714729786733172705311036650262	cmpmd0lfz002j1k2ubzh2f0sz	cmpmd6ugz004k1k2udfqwxrax	2026-05-26 08:14:47.183	2026-05-26 08:19:38.823
cmpmd2sbq002q1k2u807d069r	0108714729787068172709221037517250	cmpmd2sbq002p1k2u5ssy3lfs	cmpmd6uhz00541k2ul0qq2j8b	2026-05-26 08:16:29.415	2026-05-26 08:19:38.859
cmpmd1n1r002n1k2urr4ry0vr	0108714729787044172711071037904170	cmpmd1n1r002m1k2upgdg0ln4	cmpmd6uii005e1k2ur57rwhsw	2026-05-26 08:15:35.92	2026-05-26 08:19:38.969
cmpmf58un008x1k2u9ogrffhk	0108714729965886172609251034925486	cmpmf58un008w1k2uwvdhf2ru	cmpmf92l200931k2uuj7qvz1g	2026-05-26 09:14:23.375	2026-05-26 09:17:21.881
cmpmcqdgs001n1k2uv58ztbte	0108714729786726172711041037870723	cmpmcqdgs001m1k2uw2ath32f	cmpmd6ugh004a1k2utqsil874	2026-05-26 08:06:50.285	2026-05-26 13:08:40.672
cmpntcke20007n76icx9rt62f	1729011921S1645411-A	cmpntcke20006n76i7wjc2ff3	cmpntht99000pn76ip54lj79l	2026-05-27 08:39:45.722	2026-05-27 08:43:50.502
cmpntdyg3000cn76it3m351mx	1727103021S1576918-A	cmpntdyg3000bn76iim7di7no	cmpnthta5000zn76in32ckzay	2026-05-27 08:40:50.595	2026-05-27 08:43:50.529
\.


--
-- Data for Name: contracts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contracts (id, counterparty_id, number, date, title, doc_type, original_name, mime_type, file_size, file_name, storage_path, uploaded_by, created_at, procurement_items, procurement_parsed_at, procurement_parse_error) FROM stdin;
cmpphl9iw0001xsssm3qrizzy	cmppfzvro000113rvhvslou02	1234	2026-05-14 00:00:00	тест	HTML	Контракт Пирогова (1657) ЭА-44-К_1317-25 от 30.01.2026.html	text/html	88497	cmpphl9iw0001xsssm3qrizzy.html	/app/uploads/contracts/cmppfzvro000113rvhvslou02/cmpphl9iw0001xsssm3qrizzy.html	am@medicine-2000.ru	2026-05-28 12:46:08.505	[{"sum": "9", "code": "4", "name": "2", "country": "8", "vatRate": "7", "quantity": "5", "priceWithVat": "6", "contractLineNo": 1}, {"code": "Держатель/наконечник ультразвуковой хирургической системы для мягких тканей, одноразового использования (32.50.50.190-00000667)Изделия медицинские, в том числе хирургические, прочие, не включенные в другие группировки (32.50.50.190)", "name": "Держатель/наконечник ультразвуковой хирургической системы для мягких тканей, одноразового использования(объект закупки является медицинским изделием, код НКМИ: 334020: Держатель/наконечник ультразвуковой хирургической системы для мягких тканей, одноразового использования, наименование в соответствии с РУ: Инструменты ультразвуковые для генератора электрохирургического ультразвукового GEN11 с принадлежностями, вариант исполнения: 5. Ножницы Harmonic ACE+ с технологией адаптации к тканям для открытых и эндоскопических операций, длина ствола 36 см (HAR36) РЗН 2017/5771 от 27.06.2022) Товарный знак: Инструменты ультразвуковые для генератора электрохирургического ультразвукового GEN11 с принадлежностями, вариант исполнения: 5. Ножницы Harmonic ACE+ с технологией адаптации к тканям для открытых и эндоскопических операций, длина ствола 36 см (HAR36) РЗН 2017/5771 от 27.06.2022", "unit": "Штука (ШТ)", "country": "Мексиканские Соединенные Штаты (484), Соединенные Штаты Америки (840)", "vatRate": "Без НДС", "quantity": "1", "priceWithVat": "64 350.00", "contractLineNo": 1}, {"code": "Держатель/наконечник ультразвуковой хирургической системы для мягких тканей, одноразового использования (32.50.50.190-00000667)Изделия медицинские, в том числе хирургические, прочие, не включенные в другие группировки (32.50.50.190)", "name": "Держатель/наконечник ультразвуковой хирургической системы для мягких тканей, одноразового использования(объект закупки является медицинским изделием, код НКМИ: 334020: Держатель/наконечник ультразвуковой хирургической системы для мягких тканей, одноразового использования, наименование в соответствии с РУ: Инструменты ультразвуковые для генератора электрохирургического ультразвукового GEN11 с принадлежностями, вариант исполнения: 6. Ножницы Harmonic Focus + c технологией адаптации к тканям для открытых операций (HAR9F) РЗН 2017/5771 от 27.06.2022) Товарный знак: Инструменты ультразвуковые для генератора электрохирургического ультразвукового GEN11 с принадлежностями, вариант исполнения: 6. Ножницы Harmonic Focus + c технологией адаптации к тканям для открытых операций (HAR9F) РЗН 2017/5771 от 27.06.2022", "unit": "Штука (ШТ)", "country": "Мексиканские Соединенные Штаты (484), Соединенные Штаты Америки (840)", "vatRate": "Без НДС", "quantity": "1", "priceWithVat": "64 350.00", "contractLineNo": 2}, {"code": "Рукоятка ультразвуковой хирургической системы для мягких тканей с ручным управлением, многоразового использования (32.50.50.190-00001079)Изделия медицинские, в том числе хирургические, прочие, не включенные в другие группировки (32.50.50.190)", "name": "Рукоятка ультразвуковой хирургической системы для мягких тканей с ручным управлением, многоразового использования(объект закупки является медицинским изделием, код НКМИ: 162170: Рукоятка ультразвуковой хирургической системы для мягких тканей с ручным управлением, многоразового использования, наименование в соответствии с РУ: Рукоятки лапаросонические к ультразвуковому скальпелю \\"Гармоник\\" 2. Рукоятка лапаросоническая для ручной активации (HP054) ФСЗ 2011/11397 от 05.05.2021) Товарный знак: Рукоятки лапаросонические к ультразвуковому скальпелю \\"Гармоник\\" 2. Рукоятка лапаросоническая для ручной активации (HP054) ФСЗ 2011/11397 от 05.05.2021", "unit": "Штука (ШТ)", "country": "Мексиканские Соединенные Штаты (484), Соединенные Штаты Америки (840)", "vatRate": "Без НДС", "quantity": "1", "priceWithVat": "239 400.00", "contractLineNo": 3}, {"code": "Рукоятка ультразвуковой хирургической системы для мягких тканей с ручным управлением, многоразового использования (32.50.50.190-00001079)Изделия медицинские, в том числе хирургические, прочие, не включенные в другие группировки (32.50.50.190)", "name": "Рукоятка ультразвуковой хирургической системы для мягких тканей с ручным управлением, многоразового использования(объект закупки является медицинским изделием, код НКМИ: 162170: Рукоятка ультразвуковой хирургической системы для мягких тканей с ручным управлением, многоразового использования, наименование в соответствии с РУ: Рукоятки лапаросонические к ультразвуковому скальпелю «Гармоник» вариант исполнения: 1. Рукоятка лапаросоническая облегченная (HPBLUE) ФСЗ 2011/11397 от 05.05.2021) Товарный знак: Рукоятки лапаросонические к ультразвуковому скальпелю «Гармоник» вариант исполнения: 1. Рукоятка лапаросоническая облегченная (HPBLUE) ФСЗ 2011/11397 от 05.05.2021", "unit": "Штука (ШТ)", "country": "Мексиканские Соединенные Штаты (484), Соединенные Штаты Америки (840)", "vatRate": "Без НДС", "quantity": "1", "priceWithVat": "239 400.00", "contractLineNo": 4}, {"code": "Система ретракционная хирургическая, одноразового использования (32.50.50.190-00000552)Изделия медицинские, в том числе хирургические, прочие, не включенные в другие группировки (32.50.50.190)", "name": "Система ретракционная хирургическая, одноразового использования (объект закупки является медицинским изделием, код НКМИ: 248290: Система ретракционная хирургическая, одноразового использования, наименование в соответствии с РУ: Устройство эндоскопическое ретракционное T’LIFT (AW16280); РЗН 2013/133 от 19.07.2022) Товарный знак: Устройство эндоскопическое ретракционное T’LIFT (AW16280); РЗН 2013/133 от 19.07.2022", "unit": "Штука (ШТ)", "country": "Французская Республика (250)", "vatRate": "Без НДС", "quantity": "1", "priceWithVat": "7 200.00", "contractLineNo": 5}, {"code": "Набор для дренирования закрытой раны (32.50.50.190-00000232)Изделия медицинские, в том числе хирургические, прочие, не включенные в другие группировки (32.50.50.190)", "name": "Набор для дренирования закрытой раны(объект закупки является медицинским изделием, код НКМИ: 152630: Набор для дренирования закрытой раны, наименование в соответствии с РУ: Наборы медицинские для дренирования ран MEDEREN, в вариантах исполнения: I. Набор для дренирования ран медицинский одноразовый с катетером типа Редон, варианты исполнения: 4. Набор для дренирования ран медицинский, одноразовый REF-0615-M404-14; РЗН 2018/7894 от 09.08.2023) Товарный знак: Наборы медицинские для дренирования ран MEDEREN, в вариантах исполнения: I. Набор для дренирования ран медицинский одноразовый с катетером типа Редон, варианты исполнения: 4. Набор для дренирования ран медицинский, одноразовый REF-0615-M404-14; РЗН 2018/7894 от 09.08.2023", "unit": "Штука (ШТ)", "country": "Китайская Народная Республика (156)", "vatRate": "Без НДС", "quantity": "1", "priceWithVat": "1 080.00", "contractLineNo": 6}, {"code": "Щипцы электрохирургические для гибкой эндоскопии, одноразового использования (32.50.50.190-00001082)Изделия медицинские, в том числе хирургические, прочие, не включенные в другие группировки (32.50.50.190)", "name": "Щипцы электрохирургические для гибкой эндоскопии, одноразового использования (объект закупки является медицинским изделием, код НКМИ: 179520: Щипцы электрохирургические для гибкой эндоскопии, одноразового использования, наименование в соответствии с РУ: Инструменты эндохирургические многоповерхностного действия (зажимные) 1. Щипцы биопсийные FD-411UR ФСЗ 2009/04994 от 25.02.2022) Товарный знак: Инструменты эндохирургические многоповерхностного действия (зажимные) 1. Щипцы биопсийные FD-411UR ФСЗ 2009/04994 от 25.02.2022", "unit": "Штука (ШТ)", "country": "ЯПОНИЯ (392), Федеративная Республика Германия (276)", "vatRate": "Без НДС", "quantity": "1", "priceWithVat": "40 500.00", "contractLineNo": 7}, {"code": "Держатель/электрод эндоскопический электрохирургический, монополярный, одноразового использования (32.50.50.190-00001173)Изделия медицинские, в том числе хирургические, прочие, не включенные в другие группировки (32.50.50.190)", "name": "Держатель/электрод эндоскопический электрохирургический, монополярный, одноразового использования(объект закупки является медицинским изделием, код НКМИ: 268480: Держатель/электрод эндоскопический электрохирургический, монополярный, одноразового использования, наименование в соответствии с РУ: Электроды электрохирургические монополярные лапароскопические одноразовые стерильные \\"Трилокс\\" с принадлежностями в варианте исполнения: IV. Электроды электрохирургические монополярные лапароскопические одноразовые стерильные \\"Трилокс\\" в комплекте с держателем с ручным управлением: 1. Вариант исполнения: 1.1. Электрод формы L-Wire с неприлипающим тефлоновым покрытием длиной 330мм, PL01-LWR330G РЗН 2020/9909 от 09.04.2020) Товарный знак: Электроды электрохирургические монополярные лапароскопические одноразовые стерильные \\"Трилокс\\" с принадлежностями в варианте исполнения: IV. Электроды электрохирургические монополярные лапароскопические одноразовые стерильные \\"Трилокс\\" в комплекте с держателем с ручным управлением: 1. Вариант исполнения: 1.1. Электрод формы L-Wire с неприлипающим тефлоновым покрытием длиной 330мм, PL01-LWR330G РЗН 2020/9909 от 09.04.2020", "unit": "Штука (ШТ)", "country": "Китайская Народная Республика (156)", "vatRate": "Без НДС", "quantity": "1", "priceWithVat": "5 583.60", "contractLineNo": 8}, {"code": "Электрод электрохирургический для открытых операций, монополярный, одноразового использования (32.50.50.190-00000803)Изделия медицинские, в том числе хирургические, прочие, не включенные в другие группировки (32.50.50.190)", "name": "Электрод электрохирургический для открытых операций, монополярный, одноразового использования (объект закупки является медицинским изделием, код НКМИ: 332350: Электрод электрохирургический для открытых операций, монополярный, одноразового использования, наименование в соответствии с РУ: Электроды электрохирургические монополярные одноразовые стерильные \\"Трилокс\\" с принадлежностями в варианте исполнения: IV. Электрод-шарик, в составе: 1. Электрод-шарик, вариант исполнения: - формованный с неприлипающим тефлоновым покрытием, длина 130 мм, диаметр 5 мм, EBM02-05130GY РЗН 2019/9150 от 31.10.2019) Товарный знак: Электроды электрохирургические монополярные одноразовые стерильные \\"Трилокс\\" с принадлежностями в варианте исполнения: IV. Электрод-шарик, в составе: 1. Электрод-шарик, вариант исполнения: - формованный с неприлипающим тефлоновым покрытием, длина 130 мм, диаметр 5 мм, EBM02-05130GY РЗН 2019/9150 от 31.10.2019", "unit": "Штука (ШТ)", "country": "Китайская Народная Республика (156)", "vatRate": "Без НДС", "quantity": "1", "priceWithVat": "777.60", "contractLineNo": 9}]	2026-05-28 14:06:06.71+00	\N
cmppmzdli0001zs2f5mq9zjuf	cmppmp9zf000053gxj9wlafhg	0372200277526000172	2026-05-28 00:00:00	\N	HTML	Контракт Елизаветинская №0372200277526000172 от 31.03.2026.html	text/html	70039	cmppmzdli0001zs2f5mq9zjuf.html	/app/uploads/contracts/cmppmp9zf000053gxj9wlafhg/cmppmzdli0001zs2f5mq9zjuf.html	am@medicine-2000.ru	2026-05-28 15:17:05.046	[{"sum": "3 487 500.00", "code": "Холедохоскоп оптоволоконный гибкий (32.50.13.190-00007527)Инструменты и приспособления, применяемые в медицинских целях, прочие, не включенные в другие группировки (32.50.13.190)", "name": "Холедохоскоп оптоволоконный гибкий (объект закупки является медицинским изделием, код НКМИ: 180090: Холедохоскоп оптоволоконный гибкий, наименование в соответствии с РУ: Катетер SpyScope DS II для доступа и доставки, рабочая длина 214 см, максимальная ширина рабочей части 3,6 мм; РЗН 2022/16581 20.08.2025) Товарный знак: Boston Scientific", "unit": "Штука (ШТ)", "country": "ИРЛАНДИЯ (372)", "vatRate": "Без НДС", "quantity": "9", "priceWithVat": "387 500.00", "contractLineNo": 1}, {"sum": "1 500 000.00", "code": "Инструменты и приспособления, применяемые в медицинских целях, прочие, не включенные в другие группировки (32.50.13.190)", "name": "Зонд для электрогидравлической литотрипсии (объект закупки является медицинским изделием, наименование в соответствии с РУ: Зонд биполярного электрогидравлического литотриптера AUTOLITH® TOUCH 1.9 F., 375 см.; РЗН 2021/14134 23.04.2021) Товарный знак: AUTOLITH", "unit": "Штука (ШТ)", "country": "Соединенные Штаты Америки (840)", "vatRate": "Без НДС", "quantity": "10", "priceWithVat": "150 000.00", "contractLineNo": 2}]	2026-05-28 15:17:22.562+00	\N
cmpqksn3200akjmgsa4bkfqur	cmpqkr07l00aijmgsgsfcob3c	0372100037126000302	2026-05-27 00:00:00	\N	HTML	ГК Гор Онко 302 от 27.05.2026 (1).html	text/html	73428	cmpqksn3200akjmgsa4bkfqur.html	/app/uploads/contracts/cmpqkr07l00aijmgsgsfcob3c/cmpqksn3200akjmgsa4bkfqur.html	ekaterina.s@navitek.biz	2026-05-29 07:03:37.694	[{"sum": "282 680.00", "code": "Набор для урологических общехирургических процедур, не содержащий лекарственные средства, одноразового использования (32.50.50.190-00002918)Изделия медицинские, в том числе хирургические, прочие, не включенные в другие группировки (32.50.50.190)", "name": "Набор для урологических общехирургических процедур, не содержащий лекарственные средства, одноразового использования (объект закупки является медицинским изделием, код НКМИ: 321990: Набор для урологических общехирургических процедур, не содержащий лекарственные средства, одноразового использования, наименование в соответствии с РУ: Устройство для дренирования верхних мочевых путей BIOTEQ: Ureteral Stent Set c принадлежностями; РЗН 2016/4477 08.05.2026)", "unit": "Штука (ШТ)", "country": "ТАЙВАНЬ (КИТАЙ) (158)", "vatRate": "Без НДС", "quantity": "40", "priceWithVat": "7 067.00", "contractLineNo": 1}, {"sum": "254 412.00", "code": "Набор для урологических общехирургических процедур, не содержащий лекарственные средства, одноразового использования (32.50.50.190-00002918)Изделия медицинские, в том числе хирургические, прочие, не включенные в другие группировки (32.50.50.190)", "name": "Набор для урологических общехирургических процедур, не содержащий лекарственные средства, одноразового использования (объект закупки является медицинским изделием, код НКМИ: 321990: Набор для урологических общехирургических процедур, не содержащий лекарственные средства, одноразового использования, наименование в соответствии с РУ: Устройство для дренирования верхних мочевых путей BIOTEQ: Ureteral Stent Set c принадлежностями; РЗН 2016/4477 08.05.2026)", "unit": "Штука (ШТ)", "country": "ТАЙВАНЬ (КИТАЙ) (158)", "vatRate": "Без НДС", "quantity": "36", "priceWithVat": "7 067.00", "contractLineNo": 2}]	2026-05-29 07:04:07.949+00	\N
cmpqlj3sf00bujmgsn29kezxc	cmpqlhzr000bsjmgsv0fuo7p1	0372200004726000088	2026-04-10 00:00:00	\N	HTML	Контракт ГБ 9 088 № 0372200004726000088 от 01.04.2026 (1).html	text/html	65419	cmpqlj3sf00bujmgsn29kezxc.html	/app/uploads/contracts/cmpqlhzr000bsjmgsv0fuo7p1/cmpqlj3sf00bujmgsn29kezxc.html	ds@medicine-2000.ru	2026-05-29 07:24:12.399	[{"sum": "609 422.80", "code": "Держатель/электрод эндоскопический электрохирургический/набор игл для подслизистого лифтинга (32.50.13.190-00007720)Инструменты и приспособления, применяемые в медицинских целях, прочие, не включенные в другие группировки (32.50.13.190)", "name": "Держатель/электрод эндоскопический электрохирургический/набор игл для подслизистого лифтинга (объект закупки является медицинским изделием, код НКМИ: 253670: Держатель/электрод эндоскопический электрохирургический/набор игл для подслизистого лифтинга, наименование в соответствии с РУ: Нож эндоскопический электрохирургический ClearCut, вариант исполнения: FM-EK0003; РЗН 2014/1951 31.12.2020) Товарный знак: EndoStars", "unit": "Штука (ШТ)", "country": "Республика Корея (410)", "vatRate": "Без НДС", "quantity": "10", "priceWithVat": "60 942.28", "contractLineNo": 1}]	2026-05-29 07:24:37.53+00	\N
\.


--
-- Data for Name: counterparties; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.counterparties (id, type, name, inn, kpp, comment, is_active, created_at, updated_at, full_name) FROM stdin;
cmppfzf2r000013rvcx5sej7h	SUPPLIER	тест	\N	\N	\N	t	2026-05-28 12:01:09.651	2026-05-28 12:01:09.651	тест
cmppfzvro000113rvhvslou02	CUSTOMER	ТЕСТ	\N	\N	\N	t	2026-05-28 12:01:31.285	2026-05-28 12:01:31.285	ТЕСТ
cmppmp9zf000053gxj9wlafhg	CUSTOMER	Елизавет	7804041070	\N	\N	t	2026-05-28 15:09:13.803	2026-05-28 15:09:13.803	СПБ ГБУЗ "ЕЛИЗАВЕТИНСКАЯ БОЛЬНИЦА"
cmpqkr07l00aijmgsgsfcob3c	CUSTOMER	ГКОД	7813085250	\N	\N	t	2026-05-29 07:02:21.393	2026-05-29 07:02:47.774	"ГОРОДСКОЙ КЛИНИЧЕСКИЙ ОНКОЛОГИЧЕСКИЙ ДИСПАНСЕР"
cmpqlhzr000bsjmgsv0fuo7p1	CUSTOMER	ГБ 9	7813047022	\N	\N	t	2026-05-29 07:23:20.508	2026-05-29 07:23:20.508	САНКТ-ПЕТЕРБУРГСКОЕ ГОСУДАРСТВЕННОЕ БЮДЖЕТНОЕ УЧРЕЖДЕНИЕ ЗДРАВООХРАНЕНИЯ "ГОРОДСКАЯ БОЛЬНИЦА № 9"
cmpqsuomd0000l9ex089r45lo	LEGAL_ENTITY	НАВИТЭК	123412341234	\N	\N	t	2026-05-29 10:49:09.925	2026-05-29 10:49:35.897	ООО "НАВИТЭК"
cmps8zcw300056sxn4nquslis	LEGAL_ENTITY	12312312	213213211231	\N	\N	t	2026-05-30 11:08:28.035	2026-05-30 11:08:28.035	123213
\.


--
-- Data for Name: expected_receipt_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expected_receipt_events (id, expected_receipt_id, type, quantity, message, actor_email, created_at) FROM stdin;
cmpo1t4t8000ikjhfbpagvf34	cmpo1t4t7000hkjhfwj40eqfb	CREATED	10.0000	GVV	sklad@navitek.biz	2026-05-27 12:36:35.612
cmpp6winf00eflwhzwg1swz7h	cmpp6winf00eelwhzcig1gxvo	CREATED	100.0000	ГВВ	am@medicine-2000.ru	2026-05-28 07:46:57.771
cmpqzoe3r001tct531yoj2w5q	cmpqzoe3r001sct53ti5k83r8	CREATED	10.0000	гб9	ds@medicine-2000.ru	2026-05-29 14:00:13.672
\.


--
-- Data for Name: expected_receipts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expected_receipts (id, product_id, ordered_qty, received_qty, status, comment, created_by, created_at, updated_at) FROM stdin;
cmpo1t4t7000hkjhfwj40eqfb	cmpo1pwnt0000kjhfqt16rmd7	10.0000	0.0000	ORDERED	GVV	sklad@navitek.biz	2026-05-27 12:36:35.612	2026-05-27 12:36:35.612
cmpp6winf00eelwhzcig1gxvo	cmpmd2sbq002p1k2u5ssy3lfs	100.0000	0.0000	ORDERED	ГВВ	am@medicine-2000.ru	2026-05-28 07:46:57.771	2026-05-28 07:46:57.771
cmpqzoe3r001sct53ti5k83r8	cmpmd2sbq002p1k2u5ssy3lfs	10.0000	0.0000	ORDERED	гб9	ds@medicine-2000.ru	2026-05-29 14:00:13.672	2026-05-29 14:00:13.672
\.


--
-- Data for Name: inventory_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_items (id, product_id, lot_id, quantity, location, created_at, updated_at, reserved_quantity) FROM stdin;
cmpmf92l400951k2uzzic0xn8	cmpmf58un008w1k2uwvdhf2ru	cmpmf92l200931k2uuj7qvz1g	3.0000	C10	2026-05-26 09:17:21.88	2026-05-26 09:17:21.88	0.0000
cmpmip0wg000w7i86aca2czpk	cmpmcqdgs001m1k2uw2ath32f	cmpmcrsfe00211k2uz83zryw1	6.0000	A7	2026-05-26 10:53:45.041	2026-05-26 10:53:45.041	0.0000
cmpmnijj1000cmtaz2z0bwamc	cmpmcqdgs001m1k2uw2ath32f	cmpmd6ugh004a1k2utqsil874	4.0000	A7	2026-05-26 13:08:40.669	2026-05-26 13:08:40.669	0.0000
cmpqzal7j000wct5335n686zf	cmpqzal6r000nct536dw7ekwc	cmpqzal7g000uct53h62s8sui	1.0000	3	2026-05-29 13:49:29.695	2026-05-29 13:49:29.695	0.0000
cmpqzr6wv0021ct53ucpfwd4z	cmpqzal6r000nct536dw7ekwc	cmpqzr6ws001zct531qe1ktgx	1.0000	в	2026-05-29 14:02:24.319	2026-05-29 14:02:24.319	0.0000
cmpo269zk0013kjhfhzstzpa6	cmpntcke20006n76i7wjc2ff3	cmpntht99000pn76ip54lj79l	1.0000	\N	2026-05-27 12:46:48.848	2026-05-27 12:46:48.848	0.0000
cmpmd6ui100561k2u9bovu2xq	cmpmd2sbq002p1k2u5ssy3lfs	cmpmd6uhz00541k2ul0qq2j8b	1.0000	A7	2026-05-26 08:19:38.857	2026-05-26 08:23:54.752	0.0000
cmpmd6uf3003i1k2ukjthv7fp	cmpmcw8dk002e1k2ue32kczgy	cmpmd6uf1003g1k2ufzrdlgos	1.0000	A7	2026-05-26 08:19:38.752	2026-05-26 08:27:57.495	0.0000
cmpp6hn1w00e1lwhz19o0y3ux	cmpmcw8dk002e1k2ue32kczgy	cmpmd6ug000401k2utmpqvni1	1.0000	\N	2026-05-28 07:35:23.636	2026-05-28 07:35:23.636	0.0000
cmpmcin2p000r1k2u5bv2sy2l	cmpmcfey600021k2uw7js511b	cmpmcin2m000p1k2u5ei1n17o	9.0000	A7	2026-05-26 08:00:49.489	2026-05-28 17:12:01.63	0.0000
cmpmd6ufl003s1k2uw8creiop	cmpmcw8dk002e1k2ue32kczgy	cmpmd6ufj003q1k2udi0bji4e	2.0000	A7	2026-05-26 08:19:38.77	2026-05-26 08:28:00.474	0.0000
cmpmd6uek00381k2ux5bquzhh	cmpmcu0rt00291k2ushag980x	cmpmd6uei00361k2unt434b1k	1.0000	A7	2026-05-26 08:19:38.732	2026-05-26 08:28:14.47	0.0000
cmpmd6udu002y1k2ujcwswp91	cmpmcu0rt00291k2ushag980x	cmpmd6udr002w1k2uyhba7t8q	5.0000	A7	2026-05-26 08:19:38.706	2026-05-26 08:28:15.933	0.0000
cmpmcrses001t1k2u49nvo5ll	cmpmcqdgs001m1k2uw2ath32f	cmpmcrseo001r1k2uoe2u4ha1	20.0000	A7	2026-05-26 08:07:56.308	2026-05-26 08:28:30.015	0.0000
cmpmd6uh1004m1k2urjy4bmth	cmpmd0lfz002j1k2ubzh2f0sz	cmpmd6ugz004k1k2udfqwxrax	1.0000	A7	2026-05-26 08:19:38.821	2026-05-26 08:28:36.029	0.0000
cmpmd6ukk006a1k2ujovnik8o	cmpmd1n1r002m1k2upgdg0ln4	cmpmd6uki00681k2um94lvlnr	3.0000	A7	2026-05-26 08:19:38.949	2026-05-26 08:28:43.513	0.0000
cmpmd6uk000601k2u4m5au2ag	cmpmd1n1r002m1k2upgdg0ln4	cmpmd6ujz005y1k2uyv23qzas	2.0000	A7	2026-05-26 08:19:38.929	2026-05-26 08:28:44.83	0.0000
cmpmd6uhh004w1k2u86qlwisy	cmpmd1n1r002m1k2upgdg0ln4	cmpmd6uhf004u1k2uq9iqysm0	1.0000	A7	2026-05-26 08:19:38.837	2026-05-26 08:28:46.022	0.0000
cmpmd6ujg005q1k2u5k48dp2b	cmpmd1n1r002m1k2upgdg0ln4	cmpmd6uje005o1k2ujo3oo8mh	2.0000	A7	2026-05-26 08:19:38.908	2026-05-26 08:28:47.269	0.0000
cmpmd6uiu005g1k2utpzrc587	cmpmd1n1r002m1k2upgdg0ln4	cmpmd6uii005e1k2ur57rwhsw	3.0000	A7	2026-05-26 08:19:38.886	2026-05-26 08:28:48.742	0.0000
cmpmcnzbt00161k2u3vxq0nk4	cmpmcljje000z1k2uewbthv27	cmpmcnzbq00141k2uo7ty8scw	5.0000	A7	2026-05-26 08:04:58.649	2026-05-29 07:14:02.471	0.0000
cmpqz7hap000fct5339d41m4z	cmpqz7h920006ct53ns5ughlq	cmpqz7hag000dct53orf8wb6n	5.0000	44	2026-05-29 13:47:04.658	2026-05-29 13:47:04.658	0.0000
cmpmcnzce001g1k2umqmdsfdp	cmpmcljje000z1k2uewbthv27	cmpmcnzcc001e1k2um5miuq8n	15.0000	A7	2026-05-26 08:04:58.67	2026-05-26 08:29:00.615	0.0000
cmpmcin1800091k2ulapif0ou	cmpmcfey600021k2uw7js511b	cmpmcin1100071k2usjl5qasd	37.0000	A7	2026-05-26 08:00:49.436	2026-05-26 08:29:13.8	0.0000
\.


--
-- Data for Name: lots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lots (id, product_id, lot_number, expiry_date, created_at, updated_at, mfg_date, status) FROM stdin;
cmpp90k9g00felwhzcknrtgyp	cmpp90k8x00f8lwhzc131jr4n	38145722	2026-11-28 00:00:00	2026-05-28 08:46:05.716	2026-05-28 08:46:05.716	\N	OK
cmpqz7hag000dct53orf8wb6n	cmpqz7h920006ct53ns5ughlq	214123412	2029-07-10 00:00:00	2026-05-29 13:47:04.649	2026-05-29 13:47:04.649	\N	OK
cmpqzal7g000uct53h62s8sui	cmpqzal6r000nct536dw7ekwc	38296268	2027-01-08 00:00:00	2026-05-29 13:49:29.692	2026-05-29 13:49:29.692	\N	OK
cmpqzr6ws001zct531qe1ktgx	cmpqzal6r000nct536dw7ekwc	34224556	2030-12-20 00:00:00	2026-05-29 14:02:24.317	2026-05-29 14:02:24.317	\N	OK
cmpmd6ug000401k2utmpqvni1	cmpmcw8dk002e1k2ue32kczgy	36845801	2027-06-26 00:00:00	2026-05-26 08:19:38.785	2026-05-26 08:19:38.785	\N	OK
cmpmd6ugh004a1k2utqsil874	cmpmcqdgs001m1k2uw2ath32f	36838804	2027-06-25 00:00:00	2026-05-26 08:19:38.801	2026-05-26 08:19:38.801	\N	OK
cmpmd6ugz004k1k2udfqwxrax	cmpmd0lfz002j1k2ubzh2f0sz	36650262	2027-05-31 00:00:00	2026-05-26 08:19:38.82	2026-05-26 08:19:38.82	\N	OK
cmpmd6uhf004u1k2uq9iqysm0	cmpmd1n1r002m1k2upgdg0ln4	37904170	2027-11-07 00:00:00	2026-05-26 08:19:38.836	2026-05-26 08:19:38.836	\N	OK
cmpmd6uhz00541k2ul0qq2j8b	cmpmd2sbq002p1k2u5ssy3lfs	37517250	2027-09-22 00:00:00	2026-05-26 08:19:38.855	2026-05-26 08:19:38.855	\N	OK
cmpmd6uje005o1k2ujo3oo8mh	cmpmd1n1r002m1k2upgdg0ln4	38077059	2027-12-01 00:00:00	2026-05-26 08:19:38.906	2026-05-26 08:19:38.906	\N	OK
cmpmd6ujz005y1k2uyv23qzas	cmpmd1n1r002m1k2upgdg0ln4	37813161	2027-10-29 00:00:00	2026-05-26 08:19:38.927	2026-05-26 08:19:38.927	\N	OK
cmpmd6uki00681k2um94lvlnr	cmpmd1n1r002m1k2upgdg0ln4	37720189	2027-10-16 00:00:00	2026-05-26 08:19:38.947	2026-05-26 08:19:38.947	\N	OK
cmpmd6uii005e1k2ur57rwhsw	cmpmd1n1r002m1k2upgdg0ln4	38123885	2027-12-05 00:00:00	2026-05-26 08:19:38.874	2026-05-26 08:19:38.966	\N	OK
cmpmcrsfe00211k2uz83zryw1	cmpmcqdgs001m1k2uw2ath32f	37479225	2027-09-17 00:00:00	2026-05-26 08:07:56.33	2026-05-26 10:53:45.037	\N	OK
cmpmcin1100071k2usjl5qasd	cmpmcfey600021k2uw7js511b	37941736	2027-11-12 00:00:00	2026-05-26 08:00:49.43	2026-05-26 08:00:49.463	\N	OK
cmpmcin2m000p1k2u5ei1n17o	cmpmcfey600021k2uw7js511b	37858279	2027-11-03 00:00:00	2026-05-26 08:00:49.487	2026-05-26 08:00:49.487	\N	OK
cmpmcnzbq00141k2uo7ty8scw	cmpmcljje000z1k2uewbthv27	38404581	2028-01-21 00:00:00	2026-05-26 08:04:58.646	2026-05-26 08:04:58.646	\N	OK
cmpmcnzcc001e1k2um5miuq8n	cmpmcljje000z1k2uewbthv27	38420978	2028-01-23 00:00:00	2026-05-26 08:04:58.668	2026-05-26 08:04:58.668	\N	OK
cmpmcrseo001r1k2uoe2u4ha1	cmpmcqdgs001m1k2uw2ath32f	37870723	2027-11-04 00:00:00	2026-05-26 08:07:56.305	2026-05-26 08:07:56.305	\N	OK
cmpmd6udr002w1k2uyhba7t8q	cmpmcu0rt00291k2ushag980x	38758114	2028-03-04 00:00:00	2026-05-26 08:19:38.704	2026-05-26 08:19:38.704	\N	OK
cmpmd6uf1003g1k2ufzrdlgos	cmpmcw8dk002e1k2ue32kczgy	38262611	2028-01-05 00:00:00	2026-05-26 08:19:38.749	2026-05-26 08:19:38.749	\N	OK
cmpmd6ufj003q1k2udi0bji4e	cmpmcw8dk002e1k2ue32kczgy	38168042	2027-12-11 00:00:00	2026-05-26 08:19:38.768	2026-05-26 08:19:38.768	\N	OK
cmpmd6uei00361k2unt434b1k	cmpmcu0rt00291k2ushag980x	35615631	2027-01-13 00:00:00	2026-05-26 08:19:38.73	2026-05-26 10:54:57.813	\N	OK
cmpmf92l200931k2uuj7qvz1g	cmpmf58un008w1k2uwvdhf2ru	34925486	2026-09-25 00:00:00	2026-05-26 09:17:21.878	2026-05-26 13:46:03.54	\N	OK
cmpntht99000pn76ip54lj79l	cmpntcke20006n76i7wjc2ff3	S1645411-A	2029-01-19 00:00:00	2026-05-27 08:43:50.493	2026-05-27 08:43:50.493	\N	OK
cmpnthta5000zn76in32ckzay	cmpntdyg3000bn76iim7di7no	S1576918	2027-10-30 00:00:00	2026-05-27 08:43:50.525	2026-05-27 08:43:50.525	\N	OK
cmpo1pwoj0005kjhfxw8259b8	cmpo1pwnt0000kjhfqt16rmd7	180834129	2028-04-01 00:00:00	2026-05-27 12:34:05.107	2026-05-27 12:34:05.107	\N	OK
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, user_id, channel, payload, read_at, created_at, type, priority, title, message, href) FROM stdin;
login-fail-cmpmlr52600087eulu4hqv87l	cmpf7cy2c000e9de7xtf3doa3	in_app	{"key": "login-fail-cmpmlr52600087eulu4hqv87l"}	\N	2026-05-26 12:19:39.375	failed_login	HIGH	Неудачный вход	sklad@navitek.biz	/users
login-fail-cmpmqf209000183b71egjjk76	cmpf7cy2c000e9de7xtf3doa3	in_app	{"key": "login-fail-cmpmqf209000183b71egjjk76"}	\N	2026-05-26 14:29:57.322	failed_login	HIGH	Неудачный вход	admin@med.local	/users
cmpquh2nz000dajeb39sksrg4	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "am@medicine-2000.ru", "shipmentId": "cmpqm5d2s00cjjmgsl3pw2qgh"}	\N	2026-05-29 11:34:34.175	shipment_picking_recalled	HIGH	Сборка отменена	ГБ 9 — заказ отозван с склада: 123	/shipments
cmpqzh2p9001cct53hdpmgbfj	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "ekaterina.s@navitek.biz", "shipmentId": "cmpqzfwwy0015ct53czw1epcf"}	\N	2026-05-29 13:54:32.301	shipment_picking_recalled	HIGH	Сборка отменена	ГБ 9 — заказ отозван с склада: олрпоа	/shipments
login-fail-cmplabwa4001dwr1j1ydyg4or	cmpe6lgwq0009eityq7uocwm4	in_app	{"key": "login-fail-cmplabwa4001dwr1j1ydyg4or"}	2026-05-25 19:59:05.276	2026-05-25 14:11:53.77	failed_login	HIGH	Неудачный вход	am@medicine-2000.ru	/users
login-fail-cmpmlrg2b000a7eulhsk56hjg	cmpf7cy2c000e9de7xtf3doa3	in_app	{"key": "login-fail-cmpmlrg2b000a7eulhsk56hjg"}	\N	2026-05-26 12:19:39.365	failed_login	HIGH	Неудачный вход	sklad@navitek.biz	/users
login-fail-cmps8t7uh00045ivgez4zcabh	cmpe6lgwq0009eityq7uocwm4	in_app	{"key": "login-fail-cmps8t7uh00045ivgez4zcabh"}	\N	2026-05-30 11:04:19.106	failed_login	HIGH	Неудачный вход	admin@med.local	/users
login-fail-cmpqx0ep70003d0fly4rz02jz	cmpe6lgwq0009eityq7uocwm4	in_app	{"key": "login-fail-cmpqx0ep70003d0fly4rz02jz"}	2026-05-29 12:46:03.97	2026-05-29 12:45:52.156	failed_login	HIGH	Неудачный вход	admin@med.local	/users
fefo-cmpmimd2b000l7i868neilkst	\N	in_app	{"key": "fefo-cmpmimd2b000l7i868neilkst"}	2026-05-27 08:23:07.169	2026-05-26 10:51:55.988	fefo_violation	CRITICAL	Нарушение FEFO	Продукт cmpmcqdgs001m1k2uw2ath32f	/write-off
login-fail-cmpmlr6t600097eulxgjpx5io	cmpf7cy2c000e9de7xtf3doa3	in_app	{"key": "login-fail-cmpmlr6t600097eulxgjpx5io"}	\N	2026-05-26 12:19:39.371	failed_login	HIGH	Неудачный вход	sklad@navitek.biz	/users
fefo-cmpl6a5hs000vz422r1kui74d	\N	in_app	{"key": "fefo-cmpl6a5hs000vz422r1kui74d"}	2026-05-25 13:11:20.671	2026-05-25 12:18:41.726	fefo_violation	CRITICAL	Нарушение FEFO	Продукт cmpl62ayu0002z4228q1xaway	/write-off
fefo-cmpla0tif000iwr1jka9afqqt	\N	in_app	{"key": "fefo-cmpla0tif000iwr1jka9afqqt"}	2026-05-25 19:59:05.276	2026-05-25 14:03:39.707	fefo_violation	CRITICAL	Нарушение FEFO	Продукт cmpl62ayu0002z4228q1xaway	/write-off
cmpqtl20e0000t2ok317tedrt	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "am@medicine-2000.ru", "shipmentId": "cmpqm5d2s00cjjmgsl3pw2qgh"}	\N	2026-05-29 11:09:40.335	shipment_picking	HIGH	Заказ на сборку	Новая заявка на сборку: ГБ 9	/shipments
login-fail-cmpmqeyfn000083b7d4jt49mt	cmpf7cy2c000e9de7xtf3doa3	in_app	{"key": "login-fail-cmpmqeyfn000083b7d4jt49mt"}	\N	2026-05-26 14:29:53.791	failed_login	HIGH	Неудачный вход	admin@med.local	/users
fefo-cmpl6a5hz000wz422mkjnl14y	\N	in_app	{"key": "fefo-cmpl6a5hz000wz422mkjnl14y"}	2026-05-25 13:11:20.671	2026-05-25 12:18:41.725	fefo_violation	CRITICAL	Нарушение FEFO	Продукт cmpl62ayu0002z4228q1xaway	/write-off
fefo-cmpl9d2ld0006wr1jsuux3lrd	\N	in_app	{"key": "fefo-cmpl9d2ld0006wr1jsuux3lrd"}	2026-05-25 19:59:05.276	2026-05-25 13:44:45.493	fefo_violation	CRITICAL	Нарушение FEFO	Продукт cmpl62ayu0002z4228q1xaway	/write-off
fefo-cmpl6ath30013z422s9k31ghd	\N	in_app	{"key": "fefo-cmpl6ath30013z422s9k31ghd"}	2026-05-25 13:11:06.513	2026-05-25 12:19:41.723	fefo_violation	CRITICAL	Нарушение FEFO	Продукт cmpl62ayu0002z4228q1xaway	/write-off
fefo-cmpl6a5i4000xz4220q57zcfl	\N	in_app	{"key": "fefo-cmpl6a5i4000xz4220q57zcfl"}	2026-05-25 13:11:20.671	2026-05-25 12:18:41.722	fefo_violation	CRITICAL	Нарушение FEFO	Продукт cmpl62ayu0002z4228q1xaway	/write-off
exp-cmpmf92l200931k2uuj7qvz1g	\N	in_app	{"key": "exp-cmpmf92l200931k2uuj7qvz1g"}	2026-05-27 08:23:07.169	2026-05-26 10:30:09.11	expiring	HIGH	Истекает срок годности	Экстракционная корзина SpyGlass Retrieval Basket (34925486) — 120 дн.	/expiry-control
exp-cmpmd6uei00361k2unt434b1k	\N	in_app	{"key": "exp-cmpmd6uei00361k2unt434b1k"}	2026-05-27 08:23:07.169	2026-05-26 13:45:27.331	expiring	HIGH	Истекает срок годности	Стент Advanix билиарный (10Fx18cm) (35615631) — 230 дн.	/expiry-control
blocked-cmpmf92l200931k2uuj7qvz1g	\N	in_app	{"key": "blocked-cmpmf92l200931k2uuj7qvz1g"}	2026-05-27 08:23:07.169	2026-05-26 10:48:23.835	blocked	HIGH	Партия заблокирована	Экстракционная корзина SpyGlass Retrieval Basket — 34925486	/recall
login-fail-cmpmi20ie00027i86h7hjm4vx	cmpe6lgwq0009eityq7uocwm4	in_app	{"key": "login-fail-cmpmi20ie00027i86h7hjm4vx"}	2026-05-27 08:23:07.169	2026-05-26 10:35:53.455	failed_login	HIGH	Неудачный вход	am@medicine-2000.ru	/users
quarantine-cmpmd6uei00361k2unt434b1k	\N	in_app	{"key": "quarantine-cmpmd6uei00361k2unt434b1k"}	2026-05-27 08:23:07.169	2026-05-26 10:48:23.838	quarantine	HIGH	Карантин партии	Стент Advanix билиарный (10Fx18cm) — 35615631	/lots?search=35615631
blocked-cmpmip0x600147i86762woq9c	\N	in_app	{"key": "blocked-cmpmip0x600147i86762woq9c"}	2026-05-27 08:23:07.169	2026-05-26 12:29:44.632	blocked	HIGH	Партия заблокирована	Стент Advanix билиарный (10Fx5cm) — 63838804	/recall
login-fail-cmpmhzzxj00007i86tqhom84w	cmpe6lgwq0009eityq7uocwm4	in_app	{"key": "login-fail-cmpmhzzxj00007i86tqhom84w"}	2026-05-27 08:23:07.169	2026-05-26 10:34:33.26	failed_login	HIGH	Неудачный вход	admin@med.local	/users
cmpqtld610001t2okhjmiqit2	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "am@medicine-2000.ru", "shipmentId": "cmpqm5d2s00cjjmgsl3pw2qgh"}	\N	2026-05-29 11:09:54.794	shipment_picking_recalled	HIGH	Сборка отменена	ГБ 9 — заказ отозван с склада: 123	/shipments
cmpquph32000gseaw3lwfh7dc	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "am@medicine-2000.ru", "shipmentId": "cmpqm5d2s00cjjmgsl3pw2qgh"}	\N	2026-05-29 11:41:06.11	shipment_picking	HIGH	Заказ на сборку	Новая заявка на сборку: ГБ 9	/shipments
cmppnjdxo0006h1svsujhfayu	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "am@medicine-2000.ru", "shipmentId": "cmppn09b20005zs2f23n8cyb9"}	2026-05-28 16:04:49.253	2026-05-28 15:32:38.604	shipment_picking	HIGH	Заказ на сборку	Новая заявка на сборку: Елизавет	/shipments
cmppodf53000314cg8t0itak9	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "am@medicine-2000.ru", "shipmentId": "cmppn09b20005zs2f23n8cyb9"}	2026-05-28 16:04:49.253	2026-05-28 15:55:59.847	shipment_picking_paused	HIGH	Сборка приостановлена	Елизавет: 123	/shipments
cmppooviv00008biju7hqrke8	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "am@medicine-2000.ru", "shipmentId": "cmppn09b20005zs2f23n8cyb9"}	2026-05-28 16:05:12.527	2026-05-28 16:04:54.295	shipment_picking_resumed	HIGH	Сборка возобновлена	Елизавет: Сборка возобновлена — продолжайте по листу.	/shipments
cmpqzixwn001mct53oex2dwcf	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "ekaterina.s@navitek.biz", "shipmentId": "cmpqzfwwy0015ct53czw1epcf"}	\N	2026-05-29 13:55:59.399	shipment_picking_recalled	HIGH	Сборка отменена	ГБ 9 — заказ отозван с склада: длордло	/shipments
cmppopdhb00038bijzvpf03nz	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "am@medicine-2000.ru", "shipmentId": "cmppn09b20005zs2f23n8cyb9"}	2026-05-28 16:11:48.758	2026-05-28 16:05:17.567	shipment_picking_paused	HIGH	Сборка приостановлена	Елизавет: 123	/shipments
cmppoxusl0004jp7njw5llnxr	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "am@medicine-2000.ru", "shipmentId": "cmppn09b20005zs2f23n8cyb9"}	2026-05-28 16:14:35.188	2026-05-28 16:11:53.254	shipment_picking_resumed	HIGH	Сборка возобновлена	Елизавет: Сборка возобновлена — продолжайте по листу.	/shipments
login-fail-cmpqtmzu00002t2okezjty5sk	cmpe6lgwq0009eityq7uocwm4	in_app	{"key": "login-fail-cmpqtmzu00002t2okezjty5sk"}	2026-05-29 12:46:03.97	2026-05-29 11:11:12.883	failed_login	HIGH	Неудачный вход	admin@med.local	/users
cmppp1fld0000vc9yn5rcivl6	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "am@medicine-2000.ru", "shipmentId": "cmppn09b20005zs2f23n8cyb9"}	2026-05-28 16:17:02.531	2026-05-28 16:14:40.177	shipment_picking_paused	HIGH	Сборка приостановлена	Елизавет: 123	/shipments
cmppp4oa40000v9ma45itkxob	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "am@medicine-2000.ru", "shipmentId": "cmppn09b20005zs2f23n8cyb9"}	2026-05-28 16:17:52.261	2026-05-28 16:17:11.404	shipment_picking_resumed	HIGH	Сборка возобновлена	Елизавет: Сборка возобновлена — продолжайте по листу.	/shipments
cmppp588o0001v9ma47x6firs	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "am@medicine-2000.ru", "shipmentId": "cmppn09b20005zs2f23n8cyb9"}	2026-05-28 16:17:52.261	2026-05-28 16:17:37.272	shipment_picking_paused	HIGH	Сборка приостановлена	Елизавет: 123	/shipments
login-fail-cmps8t4zq00025ivgpvv4oet8	cmpe6lgwq0009eityq7uocwm4	in_app	{"key": "login-fail-cmps8t4zq00025ivgpvv4oet8"}	\N	2026-05-30 11:04:19.112	failed_login	HIGH	Неудачный вход	operator@med.local	/users
cmppq1aj1000bxyrdanph0y85	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "am@medicine-2000.ru", "shipmentId": "cmppn09b20005zs2f23n8cyb9"}	2026-05-28 16:42:45.442	2026-05-28 16:42:33.23	shipment_picking_paused	HIGH	Сборка приостановлена	Елизавет: йцу	/shipments
cmppp5sah0002v9mahn0giu5m	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "am@medicine-2000.ru", "shipmentId": "cmppn09b20005zs2f23n8cyb9"}	2026-05-28 16:42:47.117	2026-05-28 16:18:03.257	shipment_picking_recalled	HIGH	Сборка отменена	Елизавет — заказ отозван с склада: 123	/shipments
cmppq173e000axyrdgwpd77vl	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "am@medicine-2000.ru", "shipmentId": "cmppn09b20005zs2f23n8cyb9"}	2026-05-28 16:42:47.117	2026-05-28 16:42:28.779	shipment_picking	HIGH	Заказ на сборку	Новая заявка на сборку: Елизавет	/shipments
cmppqpbbn000dv0luwhifzcub	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "am@medicine-2000.ru", "shipmentId": "cmppn09b20005zs2f23n8cyb9"}	2026-05-28 17:12:45.41	2026-05-28 17:01:14.003	shipment_picking	HIGH	Заказ на сборку	Новая заявка на сборку: Елизавет	/shipments
cmppr1zb60000jmgsfc4lh1gl	cmpe6lgwq0009eityq7uocwm4	in_app	{"outcome": "SUCCESS", "actorEmail": "am@medicine-2000.ru", "shipmentId": "cmppn09b20005zs2f23n8cyb9"}	2026-05-28 17:24:13.588	2026-05-28 17:11:04.962	shipment_picking_complete	NORMAL	Сборка завершена успешно	Елизавет: отгружен полностью	/shipments/cmppn09b20005zs2f23n8cyb9/print
cmppq1ybr000exyrdzsvj414z	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "am@medicine-2000.ru", "shipmentId": "cmppn09b20005zs2f23n8cyb9"}	2026-05-29 07:09:28.954	2026-05-28 16:43:04.072	shipment_picking_recalled	HIGH	Сборка отменена	Елизавет — заказ отозван с склада: 123	/shipments
cmppq2cux000fxyrdwy0znmxs	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "am@medicine-2000.ru", "shipmentId": "cmppn09b20005zs2f23n8cyb9"}	2026-05-29 07:09:28.954	2026-05-28 16:43:22.905	shipment_picking	HIGH	Заказ на сборку	Новая заявка на сборку: Елизавет	/shipments
cmppr1zb60001jmgstkw4scvz	cmpe8c28f000ft7005ljr56w2	in_app	{"outcome": "SUCCESS", "actorEmail": "am@medicine-2000.ru", "shipmentId": "cmppn09b20005zs2f23n8cyb9"}	2026-05-29 07:38:33.042	2026-05-28 17:11:04.962	shipment_picking_complete	NORMAL	Сборка завершена успешно	Елизавет: отгружен полностью	/shipments/cmppn09b20005zs2f23n8cyb9/print
cmppr1zb60002jmgsvayoa1ao	cmpf7cy2c000e9de7xtf3doa3	in_app	{"outcome": "SUCCESS", "actorEmail": "am@medicine-2000.ru", "shipmentId": "cmppn09b20005zs2f23n8cyb9"}	\N	2026-05-28 17:11:04.962	shipment_picking_complete	NORMAL	Сборка завершена успешно	Елизавет: отгружен полностью	/shipments/cmppn09b20005zs2f23n8cyb9/print
cmppr1zb60003jmgsfy8g4umm	cmpnvwk4x000m38k8kup32oc3	in_app	{"outcome": "SUCCESS", "actorEmail": "am@medicine-2000.ru", "shipmentId": "cmppn09b20005zs2f23n8cyb9"}	\N	2026-05-28 17:11:04.962	shipment_picking_complete	NORMAL	Сборка завершена успешно	Елизавет: отгружен полностью	/shipments/cmppn09b20005zs2f23n8cyb9/print
cmpql4k1m00b2jmgs7n6ze6u8	cmpe6lgwq0009eityq7uocwm4	in_app	{"outcome": "SUCCESS", "actorEmail": "operator@med.local", "shipmentId": "cmpqkwdmv00amjmgsbbhwlo90"}	2026-05-29 10:51:41.698	2026-05-29 07:12:53.627	shipment_picking_complete	NORMAL	Сборка завершена успешно	ГКОД: Все ок!	/shipments/cmpqkwdmv00amjmgsbbhwlo90/print
cmpql616b00bhjmgsswtpfs78	cmpe6lgwq0009eityq7uocwm4	in_app	{"actorEmail": "operator@med.local", "shipmentId": "cmpqkwdmv00amjmgsbbhwlo90"}	2026-05-29 10:51:41.698	2026-05-29 07:14:02.484	shipment_dispatched	NORMAL	Отгрузка списана со склада	ГКОД — товар списан, отгрузка закрыта	/shipments
cmppr371h000gjmgsb195v75i	cmpf7cy2c000e9de7xtf3doa3	in_app	{"actorEmail": "am@medicine-2000.ru", "shipmentId": "cmppn09b20005zs2f23n8cyb9"}	\N	2026-05-28 17:12:01.637	shipment_dispatched	NORMAL	Отгрузка списана со склада	Елизавет — товар списан, отгрузка закрыта	/shipments
cmppr371h000hjmgs1vgplnr2	cmpnvwk4x000m38k8kup32oc3	in_app	{"actorEmail": "am@medicine-2000.ru", "shipmentId": "cmppn09b20005zs2f23n8cyb9"}	\N	2026-05-28 17:12:01.637	shipment_dispatched	NORMAL	Отгрузка списана со склада	Елизавет — товар списан, отгрузка закрыта	/shipments
cmppr371h000ejmgsujezy2l5	cmpe6lgwq0009eityq7uocwm4	in_app	{"actorEmail": "am@medicine-2000.ru", "shipmentId": "cmppn09b20005zs2f23n8cyb9"}	2026-05-28 17:24:13.588	2026-05-28 17:12:01.637	shipment_dispatched	NORMAL	Отгрузка списана со склада	Елизавет — товар списан, отгрузка закрыта	/shipments
cmppqmq5c0004v0ludzz1m3so	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "am@medicine-2000.ru", "shipmentId": "cmppn09b20005zs2f23n8cyb9"}	2026-05-29 07:09:28.954	2026-05-28 16:59:13.248	shipment_picking_recalled	HIGH	Сборка отменена	Елизавет — заказ отозван с склада: 123	/shipments
cmppqooaa000bv0lury5awjtl	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "am@medicine-2000.ru", "shipmentId": "cmpplvrdz0008yszbyr6nvf51"}	2026-05-29 07:09:28.954	2026-05-28 17:00:44.147	shipment_picking	HIGH	Заказ на сборку	Новая заявка на сборку: ТЕСТ	/shipments
cmppqp9oc000cv0luffr34bmc	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "am@medicine-2000.ru", "shipmentId": "cmpplvrdz0008yszbyr6nvf51"}	2026-05-29 07:09:28.954	2026-05-28 17:01:11.869	shipment_picking_recalled	HIGH	Сборка отменена	ТЕСТ — заказ отозван с склада: 123	/shipments
cmpql0j9g00axjmgsb872pov1	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "ekaterina.s@navitek.biz", "shipmentId": "cmpqkwdmv00amjmgsbbhwlo90"}	2026-05-29 07:10:43.723	2026-05-29 07:09:45.989	shipment_picking	HIGH	Заказ на сборку	Новая заявка на сборку: ГКОД	/shipments
cmpql345e00ayjmgs5b22shf2	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "ekaterina.s@navitek.biz", "shipmentId": "cmpqkwdmv00amjmgsbbhwlo90"}	2026-05-29 07:11:54.22	2026-05-29 07:11:46.37	shipment_picking_paused	HIGH	Сборка приостановлена	ГКОД: Стой, уточняем	/shipments
cmpqzg2rx001act53xuxj0m7v	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "ekaterina.s@navitek.biz", "shipmentId": "cmpqzfwwy0015ct53czw1epcf"}	\N	2026-05-29 13:53:45.742	shipment_picking	HIGH	Заказ на сборку	Новая заявка на сборку: ГБ 9	/shipments
cmpql4k1m00b4jmgswo2zwvb1	cmpf7cy2c000e9de7xtf3doa3	in_app	{"outcome": "SUCCESS", "actorEmail": "operator@med.local", "shipmentId": "cmpqkwdmv00amjmgsbbhwlo90"}	\N	2026-05-29 07:12:53.627	shipment_picking_complete	NORMAL	Сборка завершена успешно	ГКОД: Все ок!	/shipments/cmpqkwdmv00amjmgsbbhwlo90/print
cmpql4k1m00b5jmgsmi0o254l	cmpfl6gyd000zjzrra4c7q7u0	in_app	{"outcome": "SUCCESS", "actorEmail": "operator@med.local", "shipmentId": "cmpqkwdmv00amjmgsbbhwlo90"}	\N	2026-05-29 07:12:53.627	shipment_picking_complete	NORMAL	Сборка завершена успешно	ГКОД: Все ок!	/shipments/cmpqkwdmv00amjmgsbbhwlo90/print
cmpql4k1m00b6jmgsr9knvuds	cmpnvwk4x000m38k8kup32oc3	in_app	{"outcome": "SUCCESS", "actorEmail": "operator@med.local", "shipmentId": "cmpqkwdmv00amjmgsbbhwlo90"}	\N	2026-05-29 07:12:53.627	shipment_picking_complete	NORMAL	Сборка завершена успешно	ГКОД: Все ок!	/shipments/cmpqkwdmv00amjmgsbbhwlo90/print
cmpqupskc000hseaw3a72v2zf	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "am@medicine-2000.ru", "shipmentId": "cmpqm5d2s00cjjmgsl3pw2qgh"}	\N	2026-05-29 11:41:20.989	shipment_picking_recalled	HIGH	Сборка отменена	ГБ 9 — заказ отозван с склада: 1234	/shipments
cmpql616b00bjjmgs28qg25av	cmpf7cy2c000e9de7xtf3doa3	in_app	{"actorEmail": "operator@med.local", "shipmentId": "cmpqkwdmv00amjmgsbbhwlo90"}	\N	2026-05-29 07:14:02.484	shipment_dispatched	NORMAL	Отгрузка списана со склада	ГКОД — товар списан, отгрузка закрыта	/shipments
cmpql3orc00b1jmgssv1kf80x	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "ekaterina.s@navitek.biz", "shipmentId": "cmpqkwdmv00amjmgsbbhwlo90"}	2026-05-29 07:14:31.85	2026-05-29 07:12:13.08	shipment_picking_resumed	HIGH	Сборка возобновлена	ГКОД: Сборка возобновлена — продолжайте по листу.	/shipments
cmppr371h000fjmgspu29i34k	cmpe8c28f000ft7005ljr56w2	in_app	{"actorEmail": "am@medicine-2000.ru", "shipmentId": "cmppn09b20005zs2f23n8cyb9"}	2026-05-29 07:38:33.042	2026-05-28 17:12:01.637	shipment_dispatched	NORMAL	Отгрузка списана со склада	Елизавет — товар списан, отгрузка закрыта	/shipments
cmpql4k1m00b3jmgskbd9tn9n	cmpe8c28f000ft7005ljr56w2	in_app	{"outcome": "SUCCESS", "actorEmail": "operator@med.local", "shipmentId": "cmpqkwdmv00amjmgsbbhwlo90"}	2026-05-29 07:38:33.042	2026-05-29 07:12:53.627	shipment_picking_complete	NORMAL	Сборка завершена успешно	ГКОД: Все ок!	/shipments/cmpqkwdmv00amjmgsbbhwlo90/print
cmpql616b00bijmgs6gkgfvqi	cmpe8c28f000ft7005ljr56w2	in_app	{"actorEmail": "operator@med.local", "shipmentId": "cmpqkwdmv00amjmgsbbhwlo90"}	2026-05-29 07:38:33.042	2026-05-29 07:14:02.484	shipment_dispatched	NORMAL	Отгрузка списана со склада	ГКОД — товар списан, отгрузка закрыта	/shipments
cmpql616b00bljmgs506z9s06	cmpnvwk4x000m38k8kup32oc3	in_app	{"actorEmail": "operator@med.local", "shipmentId": "cmpqkwdmv00amjmgsbbhwlo90"}	\N	2026-05-29 07:14:02.484	shipment_dispatched	NORMAL	Отгрузка списана со склада	ГКОД — товар списан, отгрузка закрыта	/shipments
cmpqlmjcq00bzjmgsjcf7dwwz	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "ds@medicine-2000.ru", "shipmentId": "cmpqll5ai00bwjmgseelxwwwv"}	\N	2026-05-29 07:26:52.538	shipment_picking	HIGH	Заказ на сборку	Новая заявка на сборку: ГБ 9	/shipments
cmpqlo9n200c3jmgswhoiixjs	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "ds@medicine-2000.ru", "shipmentId": "cmpqll5ai00bwjmgseelxwwwv"}	\N	2026-05-29 07:28:13.263	shipment_picking_paused	HIGH	Сборка приостановлена	ГБ 9: тихо тихо	/shipments
cmpqlp2an00c6jmgsljcvdf4l	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "ds@medicine-2000.ru", "shipmentId": "cmpqll5ai00bwjmgseelxwwwv"}	\N	2026-05-29 07:28:50.4	shipment_picking_resumed	HIGH	Сборка возобновлена	ГБ 9: Сборка возобновлена — продолжайте по листу.	/shipments
cmpqlpkm100c7jmgs8y2a6hqs	cmpe6lgwq0009eityq7uocwm4	in_app	{"outcome": "SUCCESS", "actorEmail": "ds@medicine-2000.ru", "shipmentId": "cmpqll5ai00bwjmgseelxwwwv"}	2026-05-29 10:51:41.698	2026-05-29 07:29:14.137	shipment_picking_complete	NORMAL	Сборка завершена успешно	ГБ 9: Саксесефул	/shipments/cmpqll5ai00bwjmgseelxwwwv/print
cmpqlpkm100c9jmgsd6vrou6n	cmpf7cy2c000e9de7xtf3doa3	in_app	{"outcome": "SUCCESS", "actorEmail": "ds@medicine-2000.ru", "shipmentId": "cmpqll5ai00bwjmgseelxwwwv"}	\N	2026-05-29 07:29:14.137	shipment_picking_complete	NORMAL	Сборка завершена успешно	ГБ 9: Саксесефул	/shipments/cmpqll5ai00bwjmgseelxwwwv/print
cmpqugj40000cajebxpp2koge	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "am@medicine-2000.ru", "shipmentId": "cmpqm5d2s00cjjmgsl3pw2qgh"}	\N	2026-05-29 11:34:08.832	shipment_picking	HIGH	Заказ на сборку	Новая заявка на сборку: ГБ 9	/shipments
cmpqlpkm100cbjmgs9iln4csc	cmpnvwk4x000m38k8kup32oc3	in_app	{"outcome": "SUCCESS", "actorEmail": "ds@medicine-2000.ru", "shipmentId": "cmpqll5ai00bwjmgseelxwwwv"}	\N	2026-05-29 07:29:14.137	shipment_picking_complete	NORMAL	Сборка завершена успешно	ГБ 9: Саксесефул	/shipments/cmpqll5ai00bwjmgseelxwwwv/print
cmpqlpkm100c8jmgs487wf1oh	cmpe8c28f000ft7005ljr56w2	in_app	{"outcome": "SUCCESS", "actorEmail": "ds@medicine-2000.ru", "shipmentId": "cmpqll5ai00bwjmgseelxwwwv"}	2026-05-29 07:38:33.042	2026-05-29 07:29:14.137	shipment_picking_complete	NORMAL	Сборка завершена успешно	ГБ 9: Саксесефул	/shipments/cmpqll5ai00bwjmgseelxwwwv/print
cmpqm5q8b00cmjmgsi978f61t	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "ds@medicine-2000.ru", "shipmentId": "cmpqm5d2s00cjjmgsl3pw2qgh"}	\N	2026-05-29 07:41:47.915	shipment_picking	HIGH	Заказ на сборку	Новая заявка на сборку: ГБ 9	/shipments
cmpqlpkm100cajmgsrtkv8il7	cmpfl6gyd000zjzrra4c7q7u0	in_app	{"outcome": "SUCCESS", "actorEmail": "ds@medicine-2000.ru", "shipmentId": "cmpqll5ai00bwjmgseelxwwwv"}	2026-05-29 07:57:53.426	2026-05-29 07:29:14.137	shipment_picking_complete	NORMAL	Сборка завершена успешно	ГБ 9: Саксесефул	/shipments/cmpqll5ai00bwjmgseelxwwwv/print
cmpqoni9400dgjmgs287as2vl	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "am@medicine-2000.ru", "shipmentId": "cmpqm5d2s00cjjmgsl3pw2qgh"}	\N	2026-05-29 08:51:36.616	shipment_picking_recalled	HIGH	Сборка отменена	ГБ 9 — заказ отозван с склада: 123	/shipments
login-fail-cmps8t7u200035ivg67a4zc18	cmpe6lgwq0009eityq7uocwm4	in_app	{"key": "login-fail-cmps8t7u200035ivg67a4zc18"}	\N	2026-05-30 11:04:19.109	failed_login	HIGH	Неудачный вход	operator@med.local	/users
cmpqziopg001lct531hyinthz	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "ekaterina.s@navitek.biz", "shipmentId": "cmpqzfwwy0015ct53czw1epcf"}	\N	2026-05-29 13:55:47.476	shipment_picking_paused	HIGH	Сборка приостановлена	ГБ 9: лорппо	/shipments
login-fail-cmps8gv2w000c1v10ilr4xzjp	cmpdz6zqf0002qua7og3fmd74	in_app	{"key": "login-fail-cmps8gv2w000c1v10ilr4xzjp"}	\N	2026-05-30 10:54:07.248	failed_login	HIGH	Неудачный вход	operator@med.local	/users
cmpqzheit001ict53q8fb0bh0	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "ekaterina.s@navitek.biz", "shipmentId": "cmpqzfwwy0015ct53czw1epcf"}	\N	2026-05-29 13:54:47.621	shipment_picking	HIGH	Заказ на сборку	Новая заявка на сборку: ГБ 9	/shipments
cmpqzgqjc001bct534lskworl	cmpdz6zqf0002qua7og3fmd74	in_app	{"actorEmail": "ekaterina.s@navitek.biz", "shipmentId": "cmpqzfwwy0015ct53czw1epcf"}	\N	2026-05-29 13:54:16.536	shipment_picking_paused	HIGH	Сборка приостановлена	ГБ 9: лорпорп	/shipments
cmpql616b00bkjmgsydu5jnu8	cmpfl6gyd000zjzrra4c7q7u0	in_app	{"actorEmail": "operator@med.local", "shipmentId": "cmpqkwdmv00amjmgsbbhwlo90"}	2026-05-29 13:27:11.469	2026-05-29 07:14:02.484	shipment_dispatched	NORMAL	Отгрузка списана со склада	ГКОД — товар списан, отгрузка закрыта	/shipments
login-fail-cmpqx06qu0002d0fl2ynl87cp	cmpe6lgwq0009eityq7uocwm4	in_app	{"key": "login-fail-cmpqx06qu0002d0fl2ynl87cp"}	2026-05-29 12:46:03.97	2026-05-29 12:45:29.52	failed_login	HIGH	Неудачный вход	admin@med.local	/users
login-fail-cmpqtn33f0003t2ok76xn48aj	cmpnvwk4x000m38k8kup32oc3	in_app	{"key": "login-fail-cmpqtn33f0003t2ok76xn48aj"}	\N	2026-05-29 11:11:33.243	failed_login	HIGH	Неудачный вход	admin@med.local	/users
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.password_reset_tokens (id, user_id, token_hash, expires_at, used_at, created_at) FROM stdin;
cmpe8ajnm000at700myf7ta9j	cmpe6lgwq0009eityq7uocwm4	41159e330c12ea3e392290d9d4bc9cee3da6649cdaecd5434a9dcccfc7d833da	2026-05-20 15:55:23.936	2026-05-20 15:40:50.491	2026-05-20 15:40:23.938
cmpf941q00016oxdtokw07xjf	cmpe8c28f000ft7005ljr56w2	ee0d37b9c04c7e5ab1a226e5d5f8f358a45732f4c1c11817e2b06349f5740322	2026-05-21 09:06:06.55	2026-05-21 08:51:36.317	2026-05-21 08:51:06.552
\.


--
-- Data for Name: product_name_catalog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_name_catalog (id, name, name_normalized, manufacturer, use_count, last_used_at, created_at, updated_at) FROM stdin;
676c71e6d48c13a3d1ec3ae3c61af327	SpeedBand Super 7	speedband super 7	Boston Scientific	1	2026-05-29 13:35:45.732	2026-05-29 13:35:45.732	2026-05-29 13:35:45.732
0e60bd67a307afc4d169863ef5515169	Протез клапана Epic Valve	протез клапана epic valve	St. Jude Medical	1	2026-05-29 13:35:45.732	2026-05-29 13:35:45.732	2026-05-29 13:35:45.732
53c28c33ce06e74b7c785ac366428527	Протез сердечного клапана Carbomedics Standard	протез сердечного клапана carbomedics standard	CORCYM	2	2026-05-29 13:35:45.732	2026-05-29 13:35:45.732	2026-05-29 13:35:45.732
b40e54f8c443fd55a1ab920f07f9aa0b	Стент Advanix билиарный (10Fx12cm)	стент advanix билиарный (10fx12cm)	Boston Scientific	1	2026-05-29 13:35:45.732	2026-05-29 13:35:45.732	2026-05-29 13:35:45.732
7d1aa734b80261104fbad879ad652c9b	Стент Advanix билиарный (10Fx15cm)	стент advanix билиарный (10fx15cm)	Boston Scientific	1	2026-05-29 13:35:45.732	2026-05-29 13:35:45.732	2026-05-29 13:35:45.732
eb4fc08d1c354ebd03ede49a151086a7	Стент Advanix билиарный (10Fx18cm)	стент advanix билиарный (10fx18cm)	Boston Scientific	1	2026-05-29 13:35:45.732	2026-05-29 13:35:45.732	2026-05-29 13:35:45.732
da14e59186282916c80deb9fdf68cc74	Стент Advanix билиарный (10Fx5cm)	стент advanix билиарный (10fx5cm)	Boston Scientific	1	2026-05-29 13:35:45.732	2026-05-29 13:35:45.732	2026-05-29 13:35:45.732
f1b93f0018b449f1b3f650160f8eeae4	Стент Advanix билиарный (10Fx7cm)	стент advanix билиарный (10fx7cm)	Boston Scientific	3	2026-05-29 13:35:45.732	2026-05-29 13:35:45.732	2026-05-29 13:35:45.732
22d824747fe29efda826f2f1cadb3e57	Стент Advanix билиарный (10Fx9cm)	стент advanix билиарный (10fx9cm)	Boston Scientific	1	2026-05-29 13:35:45.732	2026-05-29 13:35:45.732	2026-05-29 13:35:45.732
c67a24153c202659526668744022b65a	Экстракционная корзина SpyGlass Retrieval Basket	экстракционная корзина spyglass retrieval basket	Boston Scientific	1	2026-05-29 13:35:45.732	2026-05-29 13:35:45.732	2026-05-29 13:35:45.732
cmpqz7h9p000act53ankgsx22	тест	тест	тест	1	2026-05-29 13:47:04.618	2026-05-29 13:47:04.621	2026-05-29 13:47:04.621
\.


--
-- Data for Name: product_registration_certificates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_registration_certificates (id, product_id, file_name, original_name, mime_type, file_size, storage_path, uploaded_by, created_at) FROM stdin;
cmpmdcmy6006r1k2uu8igwwo7	cmpmd2sbq002p1k2u5ssy3lfs	cmpmdcmy6006r1k2uu8igwwo7.pdf	РУ 12601.pdf	application/pdf	4740503	/app/uploads/ru/cmpmd2sbq002p1k2u5ssy3lfs/cmpmdcmy6006r1k2uu8igwwo7.pdf	sklad@navitek.biz	2026-05-26 08:24:09.007
cmpmde14g006t1k2uty9jmyvr	cmpmcw8dk002e1k2ue32kczgy	cmpmde14g006t1k2uty9jmyvr.pdf	РУ 12601.pdf	application/pdf	4740503	/app/uploads/ru/cmpmcw8dk002e1k2ue32kczgy/cmpmde14g006t1k2uty9jmyvr.pdf	sklad@navitek.biz	2026-05-26 08:25:14.032
cmpmderej006v1k2ubxii2kjg	cmpmcu0rt00291k2ushag980x	cmpmderej006v1k2ubxii2kjg.pdf	РУ 12601.pdf	application/pdf	4740503	/app/uploads/ru/cmpmcu0rt00291k2ushag980x/cmpmderej006v1k2ubxii2kjg.pdf	sklad@navitek.biz	2026-05-26 08:25:48.092
cmpmdfdde006z1k2uoszz8v5w	cmpmcqdgs001m1k2uw2ath32f	cmpmdfdde006z1k2uoszz8v5w.pdf	РУ 12601.pdf	application/pdf	4740503	/app/uploads/ru/cmpmcqdgs001m1k2uw2ath32f/cmpmdfdde006z1k2uoszz8v5w.pdf	sklad@navitek.biz	2026-05-26 08:26:16.562
cmpmdfnuc00711k2ur76fertc	cmpmd0lfz002j1k2ubzh2f0sz	cmpmdfnuc00711k2ur76fertc.pdf	РУ 12601.pdf	application/pdf	4740503	/app/uploads/ru/cmpmd0lfz002j1k2ubzh2f0sz/cmpmdfnuc00711k2ur76fertc.pdf	sklad@navitek.biz	2026-05-26 08:26:30.132
cmpmdfxgf00731k2ub055rky3	cmpmd1n1r002m1k2upgdg0ln4	cmpmdfxgf00731k2ub055rky3.pdf	РУ 12601.pdf	application/pdf	4740503	/app/uploads/ru/cmpmd1n1r002m1k2upgdg0ln4/cmpmdfxgf00731k2ub055rky3.pdf	sklad@navitek.biz	2026-05-26 08:26:42.591
cmpmdg7vy00771k2uvr7yfezo	cmpmcljje000z1k2uewbthv27	cmpmdg7vy00771k2uvr7yfezo.pdf	РУ 12601.pdf	application/pdf	4740503	/app/uploads/ru/cmpmcljje000z1k2uewbthv27/cmpmdg7vy00771k2uvr7yfezo.pdf	sklad@navitek.biz	2026-05-26 08:26:56.11
cmpmdgl4200791k2uuwqhx16x	cmpmcfey600021k2uw7js511b	cmpmdgl4200791k2uuwqhx16x.pdf	РУ 12601.pdf	application/pdf	4740503	/app/uploads/ru/cmpmcfey600021k2uw7js511b/cmpmdgl4200791k2uuwqhx16x.pdf	sklad@navitek.biz	2026-05-26 08:27:13.25
cmpmf89wm00901k2u7vnyx59v	cmpmf58un008w1k2uwvdhf2ru	cmpmf89wm00901k2u7vnyx59v.pdf	20586.pdf	application/pdf	2251122	/app/uploads/ru/cmpmf58un008w1k2uwvdhf2ru/cmpmf89wm00901k2u7vnyx59v.pdf	sklad@navitek.biz	2026-05-26 09:16:44.71
cmpntdc0t000an76ihfyh6e3d	cmpntcke20006n76i7wjc2ff3	cmpntdc0t000an76ihfyh6e3d.pdf	1858.pdf	application/pdf	1093687	/app/uploads/ru/cmpntcke20006n76i7wjc2ff3/cmpntdc0t000an76ihfyh6e3d.pdf	sklad@navitek.biz	2026-05-27 08:40:21.533
cmpntespl000hn76ilyhrct5q	cmpntdyg3000bn76iim7di7no	cmpntespl000hn76ilyhrct5q.pdf	1858.pdf	application/pdf	1093687	/app/uploads/ru/cmpntdyg3000bn76iim7di7no/cmpntespl000hn76ilyhrct5q.pdf	sklad@navitek.biz	2026-05-27 08:41:29.817
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, sku, name, created_at, updated_at, manufacturer, min_stock, reorder_point, gtin) FROM stdin;
cmpmcfey600021k2uw7js511b	M00533010	Стент Advanix билиарный (10Fx9cm)	2026-05-26 07:58:18.99	2026-05-26 07:58:18.99	Boston Scientific	\N	\N	\N
cmpmcljje000z1k2uewbthv27	M00533000	Стент Advanix билиарный (10Fx7cm)	2026-05-26 08:03:04.874	2026-05-26 08:03:04.874	Boston Scientific	\N	\N	\N
cmpmcqdgs001m1k2uw2ath32f	M00533350	Стент Advanix билиарный (10Fx5cm)	2026-05-26 08:06:50.285	2026-05-26 08:06:50.285	Boston Scientific	\N	\N	\N
cmpmcu0rt00291k2ushag980x	M00533040	Стент Advanix билиарный (10Fx18cm)	2026-05-26 08:09:40.457	2026-05-26 08:09:40.457	Boston Scientific	\N	\N	\N
cmpmcw8dk002e1k2ue32kczgy	M00533030	Стент Advanix билиарный (10Fx15cm)	2026-05-26 08:11:23.625	2026-05-26 08:11:23.625	Boston Scientific	\N	\N	\N
cmpmd0lfz002j1k2ubzh2f0sz	M00533360	Стент Advanix билиарный (10Fx7cm)	2026-05-26 08:14:47.183	2026-05-26 08:14:47.183	Boston Scientific	\N	\N	\N
cmpmd1n1r002m1k2upgdg0ln4	M00532270	Стент Advanix билиарный (10Fx7cm)	2026-05-26 08:15:35.92	2026-05-26 08:15:35.92	Boston Scientific	\N	\N	\N
cmpmd2sbq002p1k2u5ssy3lfs	M00532300	Стент Advanix билиарный (10Fx12cm)	2026-05-26 08:16:29.415	2026-05-26 08:16:29.415	Boston Scientific	\N	\N	\N
cmpmf58un008w1k2uwvdhf2ru	M00546550	Экстракционная корзина SpyGlass Retrieval Basket	2026-05-26 09:14:23.375	2026-05-26 09:14:23.375	Boston Scientific	\N	\N	\N
cmpntcke20006n76i7wjc2ff3	M7-027	Протез сердечного клапана Carbomedics Standard	2026-05-27 08:39:45.722	2026-05-27 08:39:45.722	CORCYM	\N	\N	\N
cmpntdyg3000bn76iim7di7no	M7-025	Протез сердечного клапана Carbomedics Standard	2026-05-27 08:40:50.595	2026-05-27 08:40:50.595	CORCYM	\N	\N	\N
cmpo1pwnt0000kjhfqt16rmd7	E100-23A	Протез клапана Epic Valve	2026-05-27 12:34:05.081	2026-05-27 12:34:05.081	St. Jude Medical	\N	\N	\N
cmpp90k8x00f8lwhzc131jr4n	M00542250	SpeedBand Super 7	2026-05-28 08:46:05.698	2026-05-28 08:46:05.698	Boston Scientific	\N	\N	\N
cmpqz7h920006ct53ns5ughlq	12341234	тест	2026-05-29 13:47:04.598	2026-05-29 13:47:04.598	тест	\N	\N	14124145254325
cmpqzal6r000nct536dw7ekwc	Т	т	2026-05-29 13:49:29.667	2026-05-29 13:49:29.667	т	\N	\N	08714729296386
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.refresh_tokens (id, user_id, token_hash, expires_at, created_at) FROM stdin;
cmpqpk7v50003hav1lfg6b38j	cmpe8c28f000ft7005ljr56w2	406c359a61b6efa33adc0e83663986024bfb6fae25fdd76dcd6e4d93c5b62b21	2026-06-05 09:17:02.799	2026-05-29 09:17:02.801
cmpqqs8x3000a13pk5pbh3e2u	cmpfl6gyd000zjzrra4c7q7u0	92b23ff86296f4cf08f193481e822a5dd4cabb5b1d8e4964d2deded4e06b32b9	2026-06-05 09:51:17.03	2026-05-29 09:51:17.032
cmpo6ohei002elwhz6cmx0456	cmpf7cy2c000e9de7xtf3doa3	9fb3b937ec1aa7f3a8be8239360cf22e96c5323e2fe9a55055c35c53d2242b1f	2026-06-03 14:52:56.729	2026-05-27 14:52:56.731
cmpo6prp3002glwhz1n1ldswu	cmpf7cy2c000e9de7xtf3doa3	e808e8d806b18f16eca2d6ca93df39d3e1ab881901bdec161dd920e958700aed	2026-06-03 14:53:56.725	2026-05-27 14:53:56.727
cmpph5kfr001iccwe5i9fofzm	cmpf7cy2c000e9de7xtf3doa3	b1bc5af82333bdf6938dda1aa8c0659c06eecdc55fe07d5ad61491565ed699da	2026-06-04 12:33:56.149	2026-05-28 12:33:56.151
cmps8y6we00036sxnlbpj0n8d	cmpe6lgwq0009eityq7uocwm4	311a0ea7b999360826148889a42f3848e987f763db092f1dd57f8b98d5f7b416	2026-06-06 11:07:33.611	2026-05-30 11:07:33.614
cmps9dspu00076sxns49rkjcl	cmpdz6zqf0002qua7og3fmd74	a8308648359e28d162adc8d09cf14b4c40662567c333369d0af3eb7558f0542a	2026-06-06 11:19:41.728	2026-05-30 11:19:41.73
cmpo18u8o003138k89srpb122	cmpf7cy2c000e9de7xtf3doa3	673d0fa46b15f5172e2e78f7d6da4dae2c3af1791d77d224ebb1ae362e1e14eb	2026-06-03 12:20:48.791	2026-05-27 12:20:48.792
cmpql3j5300b0jmgs1ppwc3z6	cmpe8c28f000ft7005ljr56w2	309b2feffb8be5050eec9c0e7cce774f709f30d5b7d6b3dda7b0fd8a68a8770b	2026-06-05 07:12:05.798	2026-05-29 07:12:05.8
cmpl7jsai000au8sycp3shild	cmpf7cy2c000e9de7xtf3doa3	f2f1783a51f577d9895aba6a4b259eed5c98e6bf61d68b4ad89b0c5e6e966059	2026-06-01 12:53:58.648	2026-05-25 12:53:58.651
cmpqlms3x00c1jmgs757ucp49	cmpe8c28f000ft7005ljr56w2	0ae81dae6ee3ad06189e2fafecf2ad8a074555f42b634054dda67906b6de4bb9	2026-06-05 07:27:03.884	2026-05-29 07:27:03.885
cmpplayj6000nof8hiw714js7	cmpe8c28f000ft7005ljr56w2	118f324582688a363d827379b9096d8ea622961deddd49f4b7c0ada1777e6deb	2026-06-04 14:30:06.161	2026-05-28 14:30:06.162
cmplbdczr0003n69fg2bok6kp	cmpf7cy2c000e9de7xtf3doa3	0d2b1cb1169c6467b1969eb07aac66d7271287280ce1a73d1edfd5fcf59ba9b4	2026-06-01 14:40:57.349	2026-05-25 14:40:57.352
cmpmi8klg00077i86zmivx3ii	cmpf7cy2c000e9de7xtf3doa3	9fac4b30a4a1abca4e41fee4e257bb780a598af32e4a31472f814359a9fcf8a0	2026-06-02 10:40:57.41	2026-05-26 10:40:57.412
cmplcgz24000kn69fjydoyf2h	cmpe8c28f000ft7005ljr56w2	6e75851d5f85f7846d9db7ec8dd6f7050c956b3b3fcd8abee2d5590f634217a1	2026-06-01 15:11:45.531	2026-05-25 15:11:45.533
cmps4vl5d00075wf8ls87ui6e	cmpnvwk4x000m38k8kup32oc3	b8998c3ec25be93697a3a41b87b6b106671ec03ae59ecef420624d22b45dbea0	2026-06-06 09:13:33.645	2026-05-30 09:13:33.649
cmpmrk7uw000iwibsxmn3fhvi	cmpf7cy2c000e9de7xtf3doa3	56fd0b79899a212c82ab357c083855716e6613be61bbdc1a7c8a2fbb4be328cd	2026-06-02 15:01:57.319	2026-05-26 15:01:57.321
cmpqz9i2u000mct53486s0swv	cmpf7cy2c000e9de7xtf3doa3	11615e2eb22607006e87bb388a3fcf1f5695483f1b253227d50a0d684f4d32fa	2026-06-05 13:48:38.98	2026-05-29 13:48:38.982
cmpqzcxqg0013ct53y8cdseor	cmpfl6gyd000zjzrra4c7q7u0	35909dd13d1ddb05db53b72c7825857154ee048a427ae6cd65457ad0948de636	2026-06-05 13:51:19.239	2026-05-29 13:51:19.241
cmpmrt7xo000kwibs7h0ioljf	cmpf7cy2c000e9de7xtf3doa3	fde5ac56f7a0691a37f2bd5bb8e414d222b4b59e8b83e9caacd04f4128599e71	2026-06-02 15:08:57.322	2026-05-26 15:08:57.324
cmpqzl4bx001oct53glcv68d7	cmpe8c28f000ft7005ljr56w2	eafb1d715ca8b5a6979f503afd619232da8da3972fdcee548c583b7b71820ea9	2026-06-05 13:57:41.036	2026-05-29 13:57:41.037
\.


--
-- Data for Name: shipment_assembly_reservations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shipment_assembly_reservations (id, shipment_id, product_id, quantity, reserved_by_email, reserved_by_user_id, created_at, updated_at) FROM stdin;
cmpqtplp50001ajebbr0i4skf	cmpqll5ai00bwjmgseelxwwwv	cmpmcu0rt00291k2ushag980x	6.0000	ds@medicine-2000.ru	\N	2026-05-29 11:13:12.473	2026-05-30 11:06:55.391
\.


--
-- Data for Name: shipment_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shipment_items (id, shipment_id, name, code, unit, vat_rate, price_with_vat, quantity, sum, contract_line_no, manager_note, manager_tag, product_id) FROM stdin;
cmppqom2c000av0lu3twtvfzs	cmppn09b20005zs2f23n8cyb9	Зонд для электрогидравлической литотрипсии (объект закупки является медицинским изделием, наименование в соответствии с РУ: Зонд биполярного электрогидравлического литотриптера AUTOLITH® TOUCH 1.9 F., 375 см.; РЗН 2021/14134 23.04.2021) Товарный знак: AUTOLITH	M00533010	Штука (ШТ)	Без НДС	150000.0000	1.0000	150000.0000	2	\N	\N	cmpmcfey600021k2uw7js511b
cmppqom2c0009v0lu6l51wzdv	cmppn09b20005zs2f23n8cyb9	Холедохоскоп оптоволоконный гибкий (объект закупки является медицинским изделием, код НКМИ: 180090: Холедохоскоп оптоволоконный гибкий, наименование в соответствии с РУ: Катетер SpyScope DS II для доступа и доставки, рабочая длина 214 см, максимальная ширина рабочей части 3,6 мм; РЗН 2022/16581 20.08.2025) Товарный знак: Boston Scientific	M00542250	Штука (ШТ)	Без НДС	387500.0000	1.0000	387500.0000	1	\N	\N	cmpp90k8x00f8lwhzc131jr4n
cmpqkx5gx00asjmgsueg58q5k	cmpqkwdmv00amjmgsbbhwlo90	Набор для урологических общехирургических процедур, не содержащий лекарственные средства, одноразового использования (объект закупки является медицинским изделием, код НКМИ: 321990: Набор для урологических общехирургических процедур, не содержащий лекарственные средства, одноразового использования, наименование в соответствии с РУ: Устройство для дренирования верхних мочевых путей BIOTEQ: Ureteral Stent Set c принадлежностями; РЗН 2016/4477 08.05.2026)	M00533000	Штука (ШТ)	Без НДС	7067.0000	10.0000	70670.0000	1	123	\N	cmpmcljje000z1k2uewbthv27
cmprc7j0y005wct53m7f71oak	cmpplvrdz0008yszbyr6nvf51	Держатель/наконечник ультразвуковой хирургической системы для мягких тканей, одноразового использования(объект закупки является медицинским изделием, код НКМИ: 334020: Держатель/наконечник ультразвуковой хирургической системы для мягких тканей, одноразового использования, наименование в соответствии с РУ: Инструменты ультразвуковые для генератора электрохирургического ультразвукового GEN11 с принадлежностями, вариант исполнения: 5. Ножницы Harmonic ACE+ с технологией адаптации к тканям для открытых и эндоскопических операций, длина ствола 36 см (HAR36) РЗН 2017/5771 от 27.06.2022) Товарный знак: Инструменты ультразвуковые для генератора электрохирургического ультразвукового GEN11 с принадлежностями, вариант исполнения: 5. Ножницы Harmonic ACE+ с технологией адаптации к тканям для открытых и эндоскопических операций, длина ствола 36 см (HAR36) РЗН 2017/5771 от 27.06.2022	123	Штука (ШТ)	Без НДС	64350.0000	5.0000	321750.0000	1	тест	\N	\N
cmprc7j0y005xct53ryiieno9	cmpplvrdz0008yszbyr6nvf51	Держатель/наконечник ультразвуковой хирургической системы для мягких тканей, одноразового использования(объект закупки является медицинским изделием, код НКМИ: 334020: Держатель/наконечник ультразвуковой хирургической системы для мягких тканей, одноразового использования, наименование в соответствии с РУ: Инструменты ультразвуковые для генератора электрохирургического ультразвукового GEN11 с принадлежностями, вариант исполнения: 6. Ножницы Harmonic Focus + c технологией адаптации к тканям для открытых операций (HAR9F) РЗН 2017/5771 от 27.06.2022) Товарный знак: Инструменты ультразвуковые для генератора электрохирургического ультразвукового GEN11 с принадлежностями, вариант исполнения: 6. Ножницы Harmonic Focus + c технологией адаптации к тканям для открытых операций (HAR9F) РЗН 2017/5771 от 27.06.2022	123	Штука (ШТ)	Без НДС	64350.0000	1.0000	64350.0000	2	\N	\N	\N
cmpqkx5gx00atjmgsvo253dld	cmpqkwdmv00amjmgsbbhwlo90	Набор для урологических общехирургических процедур, не содержащий лекарственные средства, одноразового использования (объект закупки является медицинским изделием, код НКМИ: 321990: Набор для урологических общехирургических процедур, не содержащий лекарственные средства, одноразового использования, наименование в соответствии с РУ: Устройство для дренирования верхних мочевых путей BIOTEQ: Ureteral Stent Set c принадлежностями; РЗН 2016/4477 08.05.2026)	E100-23A	Штука (ШТ)	Без НДС	7067.0000	1.0000	7067.0000	2	321	\N	cmpo1pwnt0000kjhfqt16rmd7
cmpqll5ai00byjmgsc3clajyj	cmpqll5ai00bwjmgseelxwwwv	Держатель/электрод эндоскопический электрохирургический/набор игл для подслизистого лифтинга (объект закупки является медицинским изделием, код НКМИ: 253670: Держатель/электрод эндоскопический электрохирургический/набор игл для подслизистого лифтинга, наименование в соответствии с РУ: Нож эндоскопический электрохирургический ClearCut, вариант исполнения: FM-EK0003; РЗН 2014/1951 31.12.2020) Товарный знак: EndoStars	M00533040	Штука (ШТ)	Без НДС	60942.2800	6.0000	365653.6800	1	\N	\N	cmpmcu0rt00291k2ushag980x
cmprc7j0y005yct531w87qm0c	cmpplvrdz0008yszbyr6nvf51	Рукоятка ультразвуковой хирургической системы для мягких тканей с ручным управлением, многоразового использования(объект закупки является медицинским изделием, код НКМИ: 162170: Рукоятка ультразвуковой хирургической системы для мягких тканей с ручным управлением, многоразового использования, наименование в соответствии с РУ: Рукоятки лапаросонические к ультразвуковому скальпелю "Гармоник" 2. Рукоятка лапаросоническая для ручной активации (HP054) ФСЗ 2011/11397 от 05.05.2021) Товарный знак: Рукоятки лапаросонические к ультразвуковому скальпелю "Гармоник" 2. Рукоятка лапаросоническая для ручной активации (HP054) ФСЗ 2011/11397 от 05.05.2021	123	Штука (ШТ)	Без НДС	239400.0000	1.0000	239400.0000	3	\N	\N	\N
cmprc7j0y005zct53ab0g1u20	cmpplvrdz0008yszbyr6nvf51	Рукоятка ультразвуковой хирургической системы для мягких тканей с ручным управлением, многоразового использования(объект закупки является медицинским изделием, код НКМИ: 162170: Рукоятка ультразвуковой хирургической системы для мягких тканей с ручным управлением, многоразового использования, наименование в соответствии с РУ: Рукоятки лапаросонические к ультразвуковому скальпелю «Гармоник» вариант исполнения: 1. Рукоятка лапаросоническая облегченная (HPBLUE) ФСЗ 2011/11397 от 05.05.2021) Товарный знак: Рукоятки лапаросонические к ультразвуковому скальпелю «Гармоник» вариант исполнения: 1. Рукоятка лапаросоническая облегченная (HPBLUE) ФСЗ 2011/11397 от 05.05.2021	123	Штука (ШТ)	Без НДС	239400.0000	1.0000	239400.0000	4	\N	\N	\N
cmprc7j0y0060ct531lvbw4z8	cmpplvrdz0008yszbyr6nvf51	Система ретракционная хирургическая, одноразового использования (объект закупки является медицинским изделием, код НКМИ: 248290: Система ретракционная хирургическая, одноразового использования, наименование в соответствии с РУ: Устройство эндоскопическое ретракционное T’LIFT (AW16280); РЗН 2013/133 от 19.07.2022) Товарный знак: Устройство эндоскопическое ретракционное T’LIFT (AW16280); РЗН 2013/133 от 19.07.2022	123	Штука (ШТ)	Без НДС	7200.0000	1.0000	7200.0000	5	\N	\N	\N
cmprc7j0y0061ct53615v45rt	cmpplvrdz0008yszbyr6nvf51	Набор для дренирования закрытой раны(объект закупки является медицинским изделием, код НКМИ: 152630: Набор для дренирования закрытой раны, наименование в соответствии с РУ: Наборы медицинские для дренирования ран MEDEREN, в вариантах исполнения: I. Набор для дренирования ран медицинский одноразовый с катетером типа Редон, варианты исполнения: 4. Набор для дренирования ран медицинский, одноразовый REF-0615-M404-14; РЗН 2018/7894 от 09.08.2023) Товарный знак: Наборы медицинские для дренирования ран MEDEREN, в вариантах исполнения: I. Набор для дренирования ран медицинский одноразовый с катетером типа Редон, варианты исполнения: 4. Набор для дренирования ран медицинский, одноразовый REF-0615-M404-14; РЗН 2018/7894 от 09.08.2023	123	Штука (ШТ)	Без НДС	1080.0000	1.0000	1080.0000	6	\N	\N	\N
cmprc7j0y0062ct53nrbuvpjw	cmpplvrdz0008yszbyr6nvf51	Щипцы электрохирургические для гибкой эндоскопии, одноразового использования (объект закупки является медицинским изделием, код НКМИ: 179520: Щипцы электрохирургические для гибкой эндоскопии, одноразового использования, наименование в соответствии с РУ: Инструменты эндохирургические многоповерхностного действия (зажимные) 1. Щипцы биопсийные FD-411UR ФСЗ 2009/04994 от 25.02.2022) Товарный знак: Инструменты эндохирургические многоповерхностного действия (зажимные) 1. Щипцы биопсийные FD-411UR ФСЗ 2009/04994 от 25.02.2022	123	Штука (ШТ)	Без НДС	40500.0000	1.0000	40500.0000	7	\N	\N	\N
cmprc7j0y0063ct53lu3p7fug	cmpplvrdz0008yszbyr6nvf51	Держатель/электрод эндоскопический электрохирургический, монополярный, одноразового использования(объект закупки является медицинским изделием, код НКМИ: 268480: Держатель/электрод эндоскопический электрохирургический, монополярный, одноразового использования, наименование в соответствии с РУ: Электроды электрохирургические монополярные лапароскопические одноразовые стерильные "Трилокс" с принадлежностями в варианте исполнения: IV. Электроды электрохирургические монополярные лапароскопические одноразовые стерильные "Трилокс" в комплекте с держателем с ручным управлением: 1. Вариант исполнения: 1.1. Электрод формы L-Wire с неприлипающим тефлоновым покрытием длиной 330мм, PL01-LWR330G РЗН 2020/9909 от 09.04.2020) Товарный знак: Электроды электрохирургические монополярные лапароскопические одноразовые стерильные "Трилокс" с принадлежностями в варианте исполнения: IV. Электроды электрохирургические монополярные лапароскопические одноразовые стерильные "Трилокс" в комплекте с держателем с ручным управлением: 1. Вариант исполнения: 1.1. Электрод формы L-Wire с неприлипающим тефлоновым покрытием длиной 330мм, PL01-LWR330G РЗН 2020/9909 от 09.04.2020	123	Штука (ШТ)	Без НДС	5583.6000	1.0000	5583.6000	8	\N	\N	\N
cmprc7j0y0064ct53wmbkm8zb	cmpplvrdz0008yszbyr6nvf51	Электрод электрохирургический для открытых операций, монополярный, одноразового использования (объект закупки является медицинским изделием, код НКМИ: 332350: Электрод электрохирургический для открытых операций, монополярный, одноразового использования, наименование в соответствии с РУ: Электроды электрохирургические монополярные одноразовые стерильные "Трилокс" с принадлежностями в варианте исполнения: IV. Электрод-шарик, в составе: 1. Электрод-шарик, вариант исполнения: - формованный с неприлипающим тефлоновым покрытием, длина 130 мм, диаметр 5 мм, EBM02-05130GY РЗН 2019/9150 от 31.10.2019) Товарный знак: Электроды электрохирургические монополярные одноразовые стерильные "Трилокс" с принадлежностями в варианте исполнения: IV. Электрод-шарик, в составе: 1. Электрод-шарик, вариант исполнения: - формованный с неприлипающим тефлоновым покрытием, длина 130 мм, диаметр 5 мм, EBM02-05130GY РЗН 2019/9150 от 31.10.2019	123	Штука (ШТ)	Без НДС	777.6000	1.0000	777.6000	9	\N	\N	\N
\.


--
-- Data for Name: shipments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shipments (id, status, counterparty_id, contract_id, note, created_by, picking_sent_at, picked_at, created_at, updated_at, warehouse_message, picking_paused_at, picking_recalled_at, picking_outcome, picking_complete_comment, writeoff_completed_at, legal_entity_id) FROM stdin;
cmpqll5ai00bwjmgseelxwwwv	PICKED	cmpqlhzr000bsjmgsv0fuo7p1	cmpqlj3sf00bujmgsn29kezxc	\N	ds@medicine-2000.ru	2026-05-29 07:26:52.533	2026-05-29 07:29:14.132	2026-05-29 07:25:47.659	2026-05-29 07:29:14.133	Сборка завершена успешно. Саксесефул	\N	\N	SUCCESS	Саксесефул	\N	\N
cmpplvrdz0008yszbyr6nvf51	DRAFT	cmppfzvro000113rvhvslou02	cmpphl9iw0001xsssm3qrizzy	\N	am@medicine-2000.ru	\N	\N	2026-05-28 14:46:16.679	2026-05-29 19:51:01.906	123	\N	2026-05-28 17:01:11.865	\N	\N	\N	cmpqsuomd0000l9ex089r45lo
cmppn09b20005zs2f23n8cyb9	DISPATCHED	cmppmp9zf000053gxj9wlafhg	cmppmzdli0001zs2f5mq9zjuf	\N	am@medicine-2000.ru	2026-05-28 17:01:14.001	2026-05-28 17:11:04.957	2026-05-28 15:17:46.142	2026-05-28 17:12:01.635	Сборка завершена успешно. отгружен полностью	\N	\N	SUCCESS	отгружен полностью	2026-05-28 17:12:01.634	\N
cmpqkwdmv00amjmgsbbhwlo90	DISPATCHED	cmpqkr07l00aijmgsgsfcob3c	cmpqksn3200akjmgsa4bkfqur	\N	ekaterina.s@navitek.biz	2026-05-29 07:09:45.985	2026-05-29 07:12:53.623	2026-05-29 07:06:32.072	2026-05-29 07:14:02.481	Сборка завершена успешно. Все ок!	\N	\N	SUCCESS	Все ок!	2026-05-29 07:14:02.481	\N
\.


--
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_movements (id, reference, product_id, lot_id, type, quantity, actor_email, created_at, write_off_destination, write_off_comment, write_off_destination_id, operation_group_id, corrected_movement_id, correction_session_id, edit_reason, shipment_id) FROM stdin;
cmpmcin2s000v1k2u5vujc25d	ПЕР-0003	cmpmcfey600021k2uw7js511b	cmpmcin2m000p1k2u5ei1n17o	RECEIPT	10.0000	sklad@navitek.biz	2026-05-26 08:00:49.493	\N	\N	\N	\N	\N	\N	\N	\N
cmpmcnzbx001a1k2ucrvmlj3y	ПЕР-0004	cmpmcljje000z1k2uewbthv27	cmpmcnzbq00141k2uo7ty8scw	RECEIPT	15.0000	sklad@navitek.biz	2026-05-26 08:04:58.653	\N	\N	\N	\N	\N	\N	\N	\N
cmpmcnzch001k1k2ubz5goil2	ПЕР-0005	cmpmcljje000z1k2uewbthv27	cmpmcnzcc001e1k2um5miuq8n	RECEIPT	15.0000	sklad@navitek.biz	2026-05-26 08:04:58.673	\N	\N	\N	\N	\N	\N	\N	\N
cmpmcrsey001x1k2unb9tcse3	ПЕР-0006	cmpmcqdgs001m1k2uw2ath32f	cmpmcrseo001r1k2uoe2u4ha1	RECEIPT	20.0000	sklad@navitek.biz	2026-05-26 08:07:56.314	\N	\N	\N	\N	\N	\N	\N	\N
cmpmcrsfj00271k2uy3l5l00a	ПЕР-0007	cmpmcqdgs001m1k2uw2ath32f	cmpmcrsfe00211k2uz83zryw1	RECEIPT	6.0000	sklad@navitek.biz	2026-05-26 08:07:56.335	\N	\N	\N	\N	\N	\N	\N	\N
cmpmd6udz00321k2up1k9j186	ПЕР-0008	cmpmcu0rt00291k2ushag980x	cmpmd6udr002w1k2uyhba7t8q	RECEIPT	5.0000	sklad@navitek.biz	2026-05-26 08:19:38.711	\N	\N	\N	\N	\N	\N	\N	\N
cmpmd6uen003c1k2uttc5lzzg	ПЕР-0009	cmpmcu0rt00291k2ushag980x	cmpmd6uei00361k2unt434b1k	RECEIPT	1.0000	sklad@navitek.biz	2026-05-26 08:19:38.735	\N	\N	\N	\N	\N	\N	\N	\N
cmpmd6uf7003m1k2udet6hbv0	ПЕР-0010	cmpmcw8dk002e1k2ue32kczgy	cmpmd6uf1003g1k2ufzrdlgos	RECEIPT	1.0000	sklad@navitek.biz	2026-05-26 08:19:38.755	\N	\N	\N	\N	\N	\N	\N	\N
cmpmd6ufo003w1k2uzvdosgen	ПЕР-0011	cmpmcw8dk002e1k2ue32kczgy	cmpmd6ufj003q1k2udi0bji4e	RECEIPT	2.0000	sklad@navitek.biz	2026-05-26 08:19:38.772	\N	\N	\N	\N	\N	\N	\N	\N
cmpmd6ug500461k2ui12767q6	ПЕР-0012	cmpmcw8dk002e1k2ue32kczgy	cmpmd6ug000401k2utmpqvni1	RECEIPT	2.0000	sklad@navitek.biz	2026-05-26 08:19:38.789	\N	\N	\N	\N	\N	\N	\N	\N
cmpmd6ugm004g1k2upcx8bmka	ПЕР-0013	cmpmcqdgs001m1k2uw2ath32f	cmpmd6ugh004a1k2utqsil874	RECEIPT	4.0000	sklad@navitek.biz	2026-05-26 08:19:38.806	\N	\N	\N	\N	\N	\N	\N	\N
cmpmcin1g000d1k2ud938bcn6	ПЕР-0001	cmpmcfey600021k2uw7js511b	cmpmcin1100071k2usjl5qasd	RECEIPT	7.0000	sklad@navitek.biz	2026-05-26 08:00:49.444	\N	\N	\N	\N	\N	\N	\N	\N
cmpmcin26000l1k2uje9eq1di	ПЕР-0002	cmpmcfey600021k2uw7js511b	cmpmcin1100071k2usjl5qasd	RECEIPT	30.0000	sklad@navitek.biz	2026-05-26 08:00:49.47	\N	\N	\N	\N	\N	\N	\N	\N
cmpmd6uh4004q1k2u882xgcpj	ПЕР-0014	cmpmd0lfz002j1k2ubzh2f0sz	cmpmd6ugz004k1k2udfqwxrax	RECEIPT	1.0000	sklad@navitek.biz	2026-05-26 08:19:38.824	\N	\N	\N	\N	\N	\N	\N	\N
cmpmd6uhk00501k2umnfi1rsq	ПЕР-0015	cmpmd1n1r002m1k2upgdg0ln4	cmpmd6uhf004u1k2uq9iqysm0	RECEIPT	1.0000	sklad@navitek.biz	2026-05-26 08:19:38.84	\N	\N	\N	\N	\N	\N	\N	\N
cmpmd6ui4005a1k2u87h4alc9	ПЕР-0016	cmpmd2sbq002p1k2u5ssy3lfs	cmpmd6uhz00541k2ul0qq2j8b	RECEIPT	1.0000	sklad@navitek.biz	2026-05-26 08:19:38.86	\N	\N	\N	\N	\N	\N	\N	\N
cmpmd6uj0005k1k2u2omqkqr3	ПЕР-0017	cmpmd1n1r002m1k2upgdg0ln4	cmpmd6uii005e1k2ur57rwhsw	RECEIPT	2.0000	sklad@navitek.biz	2026-05-26 08:19:38.892	\N	\N	\N	\N	\N	\N	\N	\N
cmpmd6uji005u1k2uj0krw7sc	ПЕР-0018	cmpmd1n1r002m1k2upgdg0ln4	cmpmd6uje005o1k2ujo3oo8mh	RECEIPT	2.0000	sklad@navitek.biz	2026-05-26 08:19:38.911	\N	\N	\N	\N	\N	\N	\N	\N
cmpmd6uk300641k2ueacoq07m	ПЕР-0019	cmpmd1n1r002m1k2upgdg0ln4	cmpmd6ujz005y1k2uyv23qzas	RECEIPT	2.0000	sklad@navitek.biz	2026-05-26 08:19:38.932	\N	\N	\N	\N	\N	\N	\N	\N
cmpmd6ukn006e1k2u7jlxuccr	ПЕР-0020	cmpmd1n1r002m1k2upgdg0ln4	cmpmd6uki00681k2um94lvlnr	RECEIPT	3.0000	sklad@navitek.biz	2026-05-26 08:19:38.951	\N	\N	\N	\N	\N	\N	\N	\N
cmpmd6ul7006m1k2uio481zgg	ПЕР-0021	cmpmd1n1r002m1k2upgdg0ln4	cmpmd6uii005e1k2ur57rwhsw	RECEIPT	1.0000	sklad@navitek.biz	2026-05-26 08:19:38.971	\N	\N	\N	\N	\N	\N	\N	\N
cmpmf92l900991k2ueh7riye1	ПЕР-0022	cmpmf58un008w1k2uwvdhf2ru	cmpmf92l200931k2uuj7qvz1g	RECEIPT	3.0000	sklad@navitek.biz	2026-05-26 09:17:21.885	\N	\N	\N	\N	\N	\N	\N	\N
cmpmihvsd000d7i86750l3866	ПЕР-0023	cmpmf58un008w1k2uwvdhf2ru	cmpmf92l200931k2uuj7qvz1g	BLOCK	0.0000	sklad@navitek.biz	2026-05-26 10:48:11.822	\N	\N	\N	\N	\N	\N	\N	\N
cmpmihytm000h7i86rkzpttse	ПЕР-0024	cmpmcu0rt00291k2ushag980x	cmpmd6uei00361k2unt434b1k	QUARANTINE	0.0000	sklad@navitek.biz	2026-05-26 10:48:15.754	\N	\N	\N	\N	\N	\N	\N	\N
cmpmimd2k000o7i862otwzk4d	ПЕР-0025	cmpmcqdgs001m1k2uw2ath32f	cmpmd6ugh004a1k2utqsil874	ISSUE	4.0000	sklad@navitek.biz	2026-05-26 10:51:40.844	OTHER	\N	wod_other	5e5b2e8f-9c56-45a6-94bf-bfb4c9dfd3de	\N	\N	\N	\N
cmpmimd2p000q7i86zge1w7hf	ПЕР-0026	cmpmcqdgs001m1k2uw2ath32f	cmpmcrsfe00211k2uz83zryw1	ISSUE	6.0000	sklad@navitek.biz	2026-05-26 10:51:40.849	OTHER	\N	wod_other	5e5b2e8f-9c56-45a6-94bf-bfb4c9dfd3de	\N	\N	\N	\N
cmpmip0wl00107i86a5i5eenz	ПЕР-0027	cmpmcqdgs001m1k2uw2ath32f	cmpmcrsfe00211k2uz83zryw1	RECEIPT	6.0000	sklad@navitek.biz	2026-05-26 10:53:45.045	\N	\N	\N	\N	\N	\N	\N	\N
cmpmiq60x001e7i86vhe97pap	ПЕР-0029	cmpmf58un008w1k2uwvdhf2ru	cmpmf92l200931k2uuj7qvz1g	BLOCK	0.0000	sklad@navitek.biz	2026-05-26 10:54:38.338	\N	\N	\N	\N	\N	\N	\N	\N
cmpmiq7qc001i7i86p9jrwmg2	ПЕР-0030	cmpmf58un008w1k2uwvdhf2ru	cmpmf92l200931k2uuj7qvz1g	BLOCK	0.0000	sklad@navitek.biz	2026-05-26 10:54:40.548	\N	\N	\N	\N	\N	\N	\N	\N
cmpmiq9u3001m7i86slagyshm	ПЕР-0031	cmpmcu0rt00291k2ushag980x	cmpmd6uei00361k2unt434b1k	QUARANTINE	0.0000	sklad@navitek.biz	2026-05-26 10:54:43.275	\N	\N	\N	\N	\N	\N	\N	\N
cmpmiqk0w001q7i86d1jsptt1	ПЕР-0032	cmpmf58un008w1k2uwvdhf2ru	cmpmf92l200931k2uuj7qvz1g	UNBLOCK	0.0000	sklad@navitek.biz	2026-05-26 10:54:56.48	\N	\N	\N	\N	\N	\N	\N	\N
cmpmiql1z001u7i86z62aw2db	ПЕР-0033	cmpmcu0rt00291k2ushag980x	cmpmd6uei00361k2unt434b1k	UNBLOCK	0.0000	sklad@navitek.biz	2026-05-26 10:54:57.815	\N	\N	\N	\N	\N	\N	\N	\N
cmpmjryyk002c7i86s6dd475g	ПЕР-0034	cmpmf58un008w1k2uwvdhf2ru	cmpmf92l200931k2uuj7qvz1g	QUARANTINE	0.0000	am@medicine-2000.ru	2026-05-26 11:24:02.109	\N	\N	\N	\N	\N	\N	\N	\N
cmpmjs0z3002g7i8672h5hjf5	ПЕР-0035	cmpmf58un008w1k2uwvdhf2ru	cmpmf92l200931k2uuj7qvz1g	UNBLOCK	0.0000	am@medicine-2000.ru	2026-05-26 11:24:04.719	\N	\N	\N	\N	\N	\N	\N	\N
cmpmjs1mo002k7i86d7j5g7ib	ПЕР-0036	cmpmf58un008w1k2uwvdhf2ru	cmpmf92l200931k2uuj7qvz1g	BLOCK	0.0000	am@medicine-2000.ru	2026-05-26 11:24:05.568	\N	\N	\N	\N	\N	\N	\N	\N
cmpmjs2zv002o7i864ztwlywb	ПЕР-0037	cmpmf58un008w1k2uwvdhf2ru	cmpmf92l200931k2uuj7qvz1g	UNBLOCK	0.0000	am@medicine-2000.ru	2026-05-26 11:24:07.34	\N	\N	\N	\N	\N	\N	\N	\N
cmpmnijiz000amtazgyhecahf	ПЕР-0041	cmpmcqdgs001m1k2uw2ath32f	cmpmd6ugh004a1k2utqsil874	RECEIPT	4.0000	sklad@navitek.biz	2026-05-26 13:08:40.667	\N	\N	\N	void-cmpmip0x600147i86762woq9c-1779800920661	\N	\N	Перенос при удалении ошибочной партии: мой косяк	\N
cmpmip0xb001a7i86nubpnqdf	ПЕР-0028	cmpmcqdgs001m1k2uw2ath32f	\N	RECEIPT	4.0000	sklad@navitek.biz	2026-05-26 10:53:45.072	\N	\N	\N	\N	\N	\N	\N	\N
cmpmm3r2e000m7eul8w29cfys	ПЕР-0038	cmpmcqdgs001m1k2uw2ath32f	\N	RECALL	0.0000	sklad@navitek.biz	2026-05-26 12:29:10.982	\N	\N	\N	\N	\N	\N	\N	\N
cmpmm5jtc000q7eulj59ks8ft	ПЕР-0039	cmpmcqdgs001m1k2uw2ath32f	\N	UNBLOCK	0.0000	sklad@navitek.biz	2026-05-26 12:30:34.897	\N	\N	\N	\N	\N	\N	\N	\N
cmpmnijiv0008mtazcpnb59ls	ПЕР-0040	cmpmcqdgs001m1k2uw2ath32f	\N	ISSUE	4.0000	sklad@navitek.biz	2026-05-26 13:08:40.663	\N	\N	\N	void-cmpmip0x600147i86762woq9c-1779800920661	\N	\N	Перенос при удалении ошибочной партии: мой косяк	\N
cmpmnijj6000emtazmimfcj0a	ПЕР-0042	cmpmcqdgs001m1k2uw2ath32f	\N	ADJUSTMENT	0.0000	sklad@navitek.biz	2026-05-26 13:08:40.675	\N	\N	\N	\N	\N	\N	мой косяк	\N
cmpmou6c2002vmtaze3ahrvu4	ПЕР-0051	cmpmf58un008w1k2uwvdhf2ru	cmpmf92l200931k2uuj7qvz1g	BLOCK	0.0000	sklad@navitek.biz	2026-05-26 13:45:43.058	\N	\N	\N	\N	\N	\N	\N	\N
cmpmoum54002zmtazb23n1dkh	ПЕР-0052	cmpmf58un008w1k2uwvdhf2ru	cmpmf92l200931k2uuj7qvz1g	UNBLOCK	0.0000	sklad@navitek.biz	2026-05-26 13:46:03.544	\N	\N	\N	\N	\N	\N	\N	\N
cmpntht9n000vn76is34kwa4o	ПЕР-0045	cmpntcke20006n76i7wjc2ff3	cmpntht99000pn76ip54lj79l	RECEIPT	1.0000	sklad@navitek.biz	2026-05-27 08:43:50.508	\N	\N	\N	\N	\N	\N	\N	\N
cmpnthtab0015n76i79u5jek5	ПЕР-0046	cmpntdyg3000bn76iim7di7no	cmpnthta5000zn76in32ckzay	RECEIPT	1.0000	sklad@navitek.biz	2026-05-27 08:43:50.532	\N	\N	\N	\N	\N	\N	\N	\N
cmpo1pwor000bkjhfphiuc79e	ПЕР-0047	cmpo1pwnt0000kjhfqt16rmd7	cmpo1pwoj0005kjhfxw8259b8	RECEIPT	1.0000	sklad@navitek.biz	2026-05-27 12:34:05.116	\N	\N	\N	\N	\N	\N	\N	\N
cmpo23lsf000vkjhfuhkjrq47	ПЕР-0048	cmpmcw8dk002e1k2ue32kczgy	cmpmd6ug000401k2utmpqvni1	ISSUE	1.0000	juliko1402@yandex.ru	2026-05-27 12:44:44.175	\N	\N	cmpfii3yx000lstrvkacz7ks2	45e016ef-a872-485c-a3b0-fd448208a3ab	\N	\N	\N	\N
cmpo23lsl000xkjhfu2nl8ku4	ПЕР-0049	cmpntcke20006n76i7wjc2ff3	cmpntht99000pn76ip54lj79l	ISSUE	1.0000	juliko1402@yandex.ru	2026-05-27 12:44:44.181	\N	\N	cmpfikajy000xstrvk9e0lrz6	45e016ef-a872-485c-a3b0-fd448208a3ab	\N	\N	\N	\N
cmpo269zm0015kjhfkdgpdrmb	ПЕР-0050	cmpntcke20006n76i7wjc2ff3	cmpntht99000pn76ip54lj79l	ADJUSTMENT	1.0000	juliko1402@yandex.ru	2026-05-27 12:46:48.851	\N	\N	cmpfikajy000xstrvk9e0lrz6	45e016ef-a872-485c-a3b0-fd448208a3ab	cmpo23lsl000xkjhfu2nl8ku4	7ccef2f3-0a3d-42dd-9ea7-a19104a9905c	Клиент отказался от части товара	\N
cmpo555ko0018lwhz1smytunx	ПЕР-MPO555KN-A116B9C7	cmpntdyg3000bn76iim7di7no	cmpnthta5000zn76in32ckzay	ISSUE	1.0000	am@medicine-2000.ru	2026-05-27 14:09:55.32	\N	test	cmpfii3yx000lstrvkacz7ks2	\N	\N	\N	\N	\N
cmpp6g49d00dvlwhz9nmycen5	ПЕР-MPP6G49C-B2D957BF	cmpmcw8dk002e1k2ue32kczgy	cmpmd6ug000401k2utmpqvni1	ISSUE	1.0000	am@medicine-2000.ru	2026-05-28 07:34:12.625	\N	\N	cmpfii3yx000lstrvkacz7ks2	45e016ef-a872-485c-a3b0-fd448208a3ab	cmpo23lsf000vkjhfuhkjrq47	14a7cc0f-749d-4d18-b621-5034e95f4d13	Менеджер ошибся	\N
cmpp6hn1x00e3lwhzvu3mite6	ПЕР-MPP6HN1W-E5F66AF7	cmpmcw8dk002e1k2ue32kczgy	cmpmd6ug000401k2utmpqvni1	ADJUSTMENT	1.0000	am@medicine-2000.ru	2026-05-28 07:35:23.637	\N	\N	cmpfii3yx000lstrvkacz7ks2	45e016ef-a872-485c-a3b0-fd448208a3ab	cmpo23lsf000vkjhfuhkjrq47	4af62a13-12d2-4644-81f1-fcd4dab782a1	Коррекция после проверки	\N
cmpp90k9l00fklwhz0u30p1mc	ПЕР-MPP90K9K-CB4C89F4	cmpp90k8x00f8lwhzc131jr4n	cmpp90k9g00felwhzcknrtgyp	RECEIPT	1.0000	sklad@navitek.biz	2026-05-28 08:46:05.721	\N	\N	\N	\N	\N	\N	\N	\N
cmppr3711000ajmgslfhd3xxj	ПЕР-MPPR3711-E3D3A6B4	cmpp90k8x00f8lwhzc131jr4n	cmpp90k9g00felwhzcknrtgyp	ISSUE	1.0000	am@medicine-2000.ru	2026-05-28 17:12:01.621	\N	Отгрузка #cmppn09b · контракт 0372200277526000172 · Елизавет · поз. 1	cmppr2maq0006jmgswvucq5ie	b087203d-99b9-4c8b-beb1-603167bf99de	\N	\N	\N	cmppn09b20005zs2f23n8cyb9
cmppr371a000cjmgs9jfh3qhh	ПЕР-MPPR371A-5B5527A4	cmpmcfey600021k2uw7js511b	cmpmcin2m000p1k2u5ei1n17o	ISSUE	1.0000	am@medicine-2000.ru	2026-05-28 17:12:01.631	\N	Отгрузка #cmppn09b · контракт 0372200277526000172 · Елизавет · поз. 2	cmppr2maq0006jmgswvucq5ie	b087203d-99b9-4c8b-beb1-603167bf99de	\N	\N	\N	cmppn09b20005zs2f23n8cyb9
cmpql616000bdjmgsf7nwkfdb	ПЕР-MPQL615Z-4D4AB730	cmpmcljje000z1k2uewbthv27	cmpmcnzbq00141k2uo7ty8scw	ISSUE	10.0000	operator@med.local	2026-05-29 07:14:02.472	\N	Отгрузка #cmpqkwdm · контракт 0372100037126000302 · ГКОД · поз. 1	cmpql4x7p00b7jmgsqnauerpa	4730c0c1-2966-4d0f-90e3-42a62839166e	\N	\N	\N	cmpqkwdmv00amjmgsbbhwlo90
cmpql616400bfjmgstjowofug	ПЕР-MPQL6164-57EB4BB0	cmpo1pwnt0000kjhfqt16rmd7	cmpo1pwoj0005kjhfxw8259b8	ISSUE	1.0000	operator@med.local	2026-05-29 07:14:02.477	\N	Отгрузка #cmpqkwdm · контракт 0372100037126000302 · ГКОД · поз. 2	cmpql4x7p00b7jmgsqnauerpa	4730c0c1-2966-4d0f-90e3-42a62839166e	\N	\N	\N	cmpqkwdmv00amjmgsbbhwlo90
cmpqz7haz000jct53fu1b16mi	ПЕР-MPQZ7HAY-C99FDC8D	cmpqz7h920006ct53ns5ughlq	cmpqz7hag000dct53orf8wb6n	RECEIPT	5.0000	am@medicine-2000.ru	2026-05-29 13:47:04.667	\N	\N	\N	\N	\N	\N	\N	\N
cmpqzal7m0010ct53ies28n72	ПЕР-MPQZAL7M-061089FC	cmpqzal6r000nct536dw7ekwc	cmpqzal7g000uct53h62s8sui	RECEIPT	1.0000	sklad@navitek.biz	2026-05-29 13:49:29.699	\N	\N	\N	\N	\N	\N	\N	\N
cmpqzr6wy0025ct53d12yu8an	ПЕР-MPQZR6WY-B6D1377A	cmpqzal6r000nct536dw7ekwc	cmpqzr6ws001zct531qe1ktgx	RECEIPT	1.0000	sklad@navitek.biz	2026-05-29 14:02:24.322	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_settings (id, payload, updated_at, updated_by) FROM stdin;
default	{"mail": {"smtp": {"from": "noreply@medicine-2000.ru", "host": "smtp.yandex.ru", "port": 465, "user": "noreply@medicine-2000.ru", "secure": true, "passwordEnc": "v1:lgMxLQuyUheR1Bzz:DQHPHboIQxfpH8umoYDXeA==:N60fUHzkxyixPT7PsghqiQ=="}, "notifications": {"system": false, "lowStock": false, "lotRecall": false, "authFailed": false, "lotBlocked": false, "passwordReset": true, "expiryCritical": false}}, "fefoStrict": true, "fefoEnabled": true, "uiAnimations": true, "uiCompactMode": false, "warehouseCode": "WH-01", "warehouseName": "МЕД-ЛОГИСТИКА — Склад №1", "uiShowFefoHints": true, "scannerAutoFocus": true, "expiryWarningDays": 180, "scannerDebounceMs": 300, "expiryCriticalDays": 90, "notificationEnabled": true, "scannerSoundEnabled": true, "uiAutoRefreshDashboard": false, "rolePermissionTemplates": {"OPERATOR": {"route.counterparties": true}}, "activityHistoryRetentionDays": 90}	2026-05-30 10:56:40.859	cmpe6lgwq0009eityq7uocwm4
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, role, is_active, created_at, updated_at, display_name, last_login_at, deleted_at, permissions) FROM stdin;
cmpdz6zqf0002qua7og3fmd74	operator@med.local	$2b$10$jDN9ibx1S9tqaMg75bIbmu9yD9.vVbC.e0jFmKjFWUaHFv3OjFC8W	OPERATOR	t	2026-05-20 11:25:41.607	2026-05-30 10:57:00.223	\N	2026-05-30 10:57:00.223	\N	\N
cmpe6lgwq0009eityq7uocwm4	am@medicine-2000.ru	$2b$10$IHTL/UOVPy/MczWOX1bGT.1L4YTipxucNkTVc6BU6eF3idg6dG8.2	ADMIN	t	2026-05-20 14:52:54.362	2026-05-30 11:07:33.622	lexmol	2026-05-30 11:07:33.621	\N	\N
cmpe8c28f000ft7005ljr56w2	ds@medicine-2000.ru	$2b$10$8SYkBq5kCbqwWXgv/z7tvORReHS/wW9oJbzlkN4.dGw239LmHhlSm	ADMIN	t	2026-05-20 15:41:34.671	2026-05-29 09:31:59.796	ds	2026-05-29 09:31:59.795	\N	\N
cmpfl6gyd000zjzrra4c7q7u0	ekaterina.s@navitek.biz	$2b$10$M1enD/BNarlyddfU04i4OeLcm6E5MtJrtLI3U.pSDY8u8HxUK6ZMu	MANAGER	t	2026-05-21 14:28:54.997	2026-05-29 10:06:29.214	Катя	2026-05-29 10:06:29.213	\N	\N
cmpe5ba810000m16kgcrcln4m	am@medicine-2000.ru	$2b$10$gRXDl3atCajFoSfs9KahfuCMUujJcH9tu3Faw2PUWEBhhHZBkRsfS	MANAGER	f	2026-05-20 14:16:59.522	2026-05-20 14:36:25.27	Илья	2026-05-20 14:17:54.591	2026-05-20 14:36:25.267	\N
cmpe6fxb20005zatu3t20boo1	api-e2e-reuse-1779288515@test.local	$2b$10$4tsJ7oga5rljBVqelcCjPuogQYnfJBz529tcok4nMNbHSa9BudCVq	OPERATOR	f	2026-05-20 14:48:35.678	2026-05-20 14:48:35.74	\N	\N	2026-05-20 14:48:35.738	\N
cmpe6fxf60008zatuonkit2z0	api-e2e-reuse-1779288515@test.local	$2b$10$0hE5gbDMxUszJ4x42a/WcO.AAI/Krsbo/RUMuPsF.v/8J1fRPWAPK	OPERATOR	f	2026-05-20 14:48:35.826	2026-05-20 14:48:35.873	\N	\N	2026-05-20 14:48:35.872	\N
cmpe6jdw20003eity5j2hxnmp	prod-verify-reuse@test.local	$2b$10$xDyOFlZuEZ9ED8GpDVpJlOfHLYER6mP7BjzRuXY12vP0qQkAPMQjW	OPERATOR	f	2026-05-20 14:51:17.138	2026-05-20 14:51:17.207	\N	\N	2026-05-20 14:51:17.204	\N
cmpe6je0n0006eity4vane1iz	prod-verify-reuse@test.local	$2b$10$ed9Vn6GTaKsciatJGxuq6u10Wm0IU2QKuH1cPDfSOJX/V61hbvDA2	OPERATOR	f	2026-05-20 14:51:17.303	2026-05-20 14:51:17.357	\N	\N	2026-05-20 14:51:17.355	\N
cmpdz6zq70000qua72g7ns5dg	admin@med.local	$2b$10$xy.uqxRKwWu9BjHr45Da5.fsiVxK2faMP6X7PcLLShXIF0guGmT0a	ADMIN	f	2026-05-20 11:25:41.599	2026-05-21 18:47:52.596	\N	2026-05-21 09:32:19.835	\N	\N
cmpf7bnav00039de7k0xutha0	pilot-pwd-1779350461@med.local	$2b$10$OmW5nc//S/GxLBhErAcqJ.DW9yWMy58Py66QF5D/4jowKBwchsDIe	VIEWER	f	2026-05-21 08:01:01.879	2026-05-21 08:01:26.605	\N	2026-05-21 08:01:02.198	2026-05-21 08:01:26.604	\N
cmpf7abnv0003oo6wrotcesbq	pilot-pwd-1779350399@med.local	$2b$10$Z48P2CzgttfMMwgUvaaLTeQA6eUAKELUsJ6drGRRDsV65boqnpdFi	VIEWER	f	2026-05-21 08:00:00.14	2026-05-21 08:01:28.884	\N	2026-05-21 08:00:00.452	2026-05-21 08:01:28.883	\N
cmpnvwk4x000m38k8kup32oc3	juliko1402@yandex.ru	$2b$10$vDyo124Ua1N6NM/hf0Cw9.OGwtvIbTs50yd4BwFNvpcpiOFmaW4X.	ACCOUNTANT	t	2026-05-27 09:51:17.745	2026-05-30 10:49:26.576	Juliya	2026-05-27 12:40:46.727	\N	\N
cmpdz6zqd0001qua7wn0v1ths	manager@med.local	$2b$10$DwSHkAehTnWDcWBb7PkA2Obe0RpXO8XagsetWCLiNMPie9rBvsDcS	MANAGER	f	2026-05-20 11:25:41.605	2026-05-27 08:34:11.113	\N	2026-05-27 08:24:07.913	\N	\N
cmpf7cy2c000e9de7xtf3doa3	sklad@navitek.biz	$2b$10$LrnsaZanb2Jxn.a.3l2z2eMf4kn22766iIFJ2vNS3sGqtQlkRHVOa	OPERATOR	t	2026-05-21 08:02:02.484	2026-05-30 10:52:10.156	Naumov	2026-05-29 12:46:49.947	\N	{"products.edit": true, "settings.fefo": true, "route.products": true, "products.create": true, "products.export": true, "route.product_names": true, "product_names.manage": true, "products.delete_debug": false, "products.quick_create": true, "settings.shift_report": true}
\.


--
-- Data for Name: write_off_destinations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.write_off_destinations (id, name, type, is_active, legacy_code, created_at, updated_at) FROM stdin;
wod_disposal	Утилизация	DISPOSAL	t	DISPOSAL	2026-05-21 12:32:22.937	2026-05-21 12:32:22.937
wod_defect	Брак	DAMAGE	t	DEFECT	2026-05-21 12:32:22.937	2026-05-21 12:32:22.937
wod_internal	Внутреннее потребление	INTERNAL	t	INTERNAL	2026-05-21 12:32:22.937	2026-05-21 12:32:22.937
wod_other	Другое	OTHER	t	OTHER	2026-05-21 12:32:22.937	2026-05-21 12:32:22.937
wod_samples	Тест / образцы	SAMPLES	t	SAMPLES	2026-05-21 12:32:22.937	2026-05-21 12:32:22.937
wod_damage	Повреждение	DAMAGE	t	DAMAGE	2026-05-21 12:32:22.937	2026-05-21 12:32:22.937
wod_expired	Истёк срок годности	OTHER	t	EXPIRED	2026-05-21 12:32:22.937	2026-05-21 12:32:22.937
cmpfii3yx000lstrvkacz7ks2	ДГБ 2	\N	t	\N	2026-05-21 13:13:59.194	2026-05-21 13:13:59.194
cmpfikajy000xstrvk9e0lrz6	ЛОКБ	\N	t	\N	2026-05-21 13:15:41.039	2026-05-21 13:15:41.039
cmppr2maq0006jmgswvucq5ie	Елизаветинская	\N	t	\N	2026-05-28 17:11:34.755	2026-05-28 17:11:34.755
cmpql4x7p00b7jmgsqnauerpa	ГКОД	\N	t	\N	2026-05-29 07:13:10.693	2026-05-29 07:13:10.693
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: barcode_records barcode_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.barcode_records
    ADD CONSTRAINT barcode_records_pkey PRIMARY KEY (id);


--
-- Name: contracts contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_pkey PRIMARY KEY (id);


--
-- Name: counterparties counterparties_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.counterparties
    ADD CONSTRAINT counterparties_pkey PRIMARY KEY (id);


--
-- Name: expected_receipt_events expected_receipt_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expected_receipt_events
    ADD CONSTRAINT expected_receipt_events_pkey PRIMARY KEY (id);


--
-- Name: expected_receipts expected_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expected_receipts
    ADD CONSTRAINT expected_receipts_pkey PRIMARY KEY (id);


--
-- Name: inventory_items inventory_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_pkey PRIMARY KEY (id);


--
-- Name: lots lots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lots
    ADD CONSTRAINT lots_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: product_name_catalog product_name_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_name_catalog
    ADD CONSTRAINT product_name_catalog_pkey PRIMARY KEY (id);


--
-- Name: product_registration_certificates product_registration_certificates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_registration_certificates
    ADD CONSTRAINT product_registration_certificates_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: shipment_assembly_reservations shipment_assembly_reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipment_assembly_reservations
    ADD CONSTRAINT shipment_assembly_reservations_pkey PRIMARY KEY (id);


--
-- Name: shipment_items shipment_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipment_items
    ADD CONSTRAINT shipment_items_pkey PRIMARY KEY (id);


--
-- Name: shipments shipments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_pkey PRIMARY KEY (id);


--
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: write_off_destinations write_off_destinations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.write_off_destinations
    ADD CONSTRAINT write_off_destinations_pkey PRIMARY KEY (id);


--
-- Name: audit_logs_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_created_at_idx ON public.audit_logs USING btree (created_at);


--
-- Name: audit_logs_entity_type_entity_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_entity_type_entity_id_idx ON public.audit_logs USING btree (entity_type, entity_id);


--
-- Name: barcode_records_barcode_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX barcode_records_barcode_key ON public.barcode_records USING btree (barcode);


--
-- Name: barcode_records_lot_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX barcode_records_lot_id_idx ON public.barcode_records USING btree (lot_id);


--
-- Name: barcode_records_product_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX barcode_records_product_id_idx ON public.barcode_records USING btree (product_id);


--
-- Name: contracts_counterparty_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX contracts_counterparty_id_created_at_idx ON public.contracts USING btree (counterparty_id, created_at);


--
-- Name: contracts_counterparty_id_number_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX contracts_counterparty_id_number_key ON public.contracts USING btree (counterparty_id, number);


--
-- Name: contracts_number_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX contracts_number_idx ON public.contracts USING btree (number);


--
-- Name: counterparties_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX counterparties_name_idx ON public.counterparties USING btree (name);


--
-- Name: counterparties_type_is_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX counterparties_type_is_active_idx ON public.counterparties USING btree (type, is_active);


--
-- Name: expected_receipt_events_expected_receipt_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX expected_receipt_events_expected_receipt_id_created_at_idx ON public.expected_receipt_events USING btree (expected_receipt_id, created_at);


--
-- Name: expected_receipts_product_id_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX expected_receipts_product_id_status_idx ON public.expected_receipts USING btree (product_id, status);


--
-- Name: expected_receipts_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX expected_receipts_status_idx ON public.expected_receipts USING btree (status);


--
-- Name: inventory_items_product_id_lot_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_items_product_id_lot_id_idx ON public.inventory_items USING btree (product_id, lot_id);


--
-- Name: lots_product_id_expiry_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lots_product_id_expiry_date_idx ON public.lots USING btree (product_id, expiry_date);


--
-- Name: lots_product_id_lot_number_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX lots_product_id_lot_number_key ON public.lots USING btree (product_id, lot_number);


--
-- Name: notifications_type_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_type_created_at_idx ON public.notifications USING btree (type, created_at);


--
-- Name: notifications_user_id_read_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_user_id_read_at_idx ON public.notifications USING btree (user_id, read_at);


--
-- Name: password_reset_tokens_token_hash_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX password_reset_tokens_token_hash_key ON public.password_reset_tokens USING btree (token_hash);


--
-- Name: password_reset_tokens_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX password_reset_tokens_user_id_idx ON public.password_reset_tokens USING btree (user_id);


--
-- Name: product_name_catalog_last_used_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_name_catalog_last_used_at_idx ON public.product_name_catalog USING btree (last_used_at);


--
-- Name: product_name_catalog_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_name_catalog_name_idx ON public.product_name_catalog USING btree (name);


--
-- Name: product_name_catalog_name_normalized_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX product_name_catalog_name_normalized_key ON public.product_name_catalog USING btree (name_normalized);


--
-- Name: product_registration_certificates_product_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_registration_certificates_product_id_created_at_idx ON public.product_registration_certificates USING btree (product_id, created_at);


--
-- Name: products_gtin_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX products_gtin_key ON public.products USING btree (gtin);


--
-- Name: products_sku_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX products_sku_key ON public.products USING btree (sku);


--
-- Name: refresh_tokens_token_hash_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX refresh_tokens_token_hash_key ON public.refresh_tokens USING btree (token_hash);


--
-- Name: refresh_tokens_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX refresh_tokens_user_id_idx ON public.refresh_tokens USING btree (user_id);


--
-- Name: shipment_assembly_reservations_product_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shipment_assembly_reservations_product_id_idx ON public.shipment_assembly_reservations USING btree (product_id);


--
-- Name: shipment_assembly_reservations_shipment_id_product_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX shipment_assembly_reservations_shipment_id_product_id_key ON public.shipment_assembly_reservations USING btree (shipment_id, product_id);


--
-- Name: shipment_items_product_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shipment_items_product_id_idx ON public.shipment_items USING btree (product_id);


--
-- Name: shipment_items_shipment_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shipment_items_shipment_id_idx ON public.shipment_items USING btree (shipment_id);


--
-- Name: shipments_contract_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shipments_contract_id_idx ON public.shipments USING btree (contract_id);


--
-- Name: shipments_counterparty_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shipments_counterparty_id_idx ON public.shipments USING btree (counterparty_id);


--
-- Name: shipments_legal_entity_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shipments_legal_entity_id_idx ON public.shipments USING btree (legal_entity_id);


--
-- Name: shipments_status_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shipments_status_created_at_idx ON public.shipments USING btree (status, created_at);


--
-- Name: stock_movements_corrected_movement_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_corrected_movement_id_idx ON public.stock_movements USING btree (corrected_movement_id);


--
-- Name: stock_movements_correction_session_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_correction_session_id_idx ON public.stock_movements USING btree (correction_session_id);


--
-- Name: stock_movements_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_created_at_idx ON public.stock_movements USING btree (created_at);


--
-- Name: stock_movements_operation_group_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_operation_group_id_idx ON public.stock_movements USING btree (operation_group_id);


--
-- Name: stock_movements_product_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_product_id_created_at_idx ON public.stock_movements USING btree (product_id, created_at);


--
-- Name: stock_movements_reference_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX stock_movements_reference_key ON public.stock_movements USING btree (reference);


--
-- Name: stock_movements_shipment_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_shipment_id_idx ON public.stock_movements USING btree (shipment_id);


--
-- Name: stock_movements_write_off_destination_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_write_off_destination_id_idx ON public.stock_movements USING btree (write_off_destination_id);


--
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_email_idx ON public.users USING btree (email);


--
-- Name: users_email_unique_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_email_unique_active ON public.users USING btree (email) WHERE (deleted_at IS NULL);


--
-- Name: write_off_destinations_legacy_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX write_off_destinations_legacy_code_key ON public.write_off_destinations USING btree (legacy_code);


--
-- Name: barcode_records barcode_records_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.barcode_records
    ADD CONSTRAINT barcode_records_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.lots(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: barcode_records barcode_records_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.barcode_records
    ADD CONSTRAINT barcode_records_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: contracts contracts_counterparty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_counterparty_id_fkey FOREIGN KEY (counterparty_id) REFERENCES public.counterparties(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: expected_receipt_events expected_receipt_events_expected_receipt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expected_receipt_events
    ADD CONSTRAINT expected_receipt_events_expected_receipt_id_fkey FOREIGN KEY (expected_receipt_id) REFERENCES public.expected_receipts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: expected_receipts expected_receipts_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expected_receipts
    ADD CONSTRAINT expected_receipts_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: inventory_items inventory_items_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.lots(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: inventory_items inventory_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lots lots_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lots
    ADD CONSTRAINT lots_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: password_reset_tokens password_reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: product_registration_certificates product_registration_certificates_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_registration_certificates
    ADD CONSTRAINT product_registration_certificates_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: shipment_assembly_reservations shipment_assembly_reservations_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipment_assembly_reservations
    ADD CONSTRAINT shipment_assembly_reservations_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: shipment_assembly_reservations shipment_assembly_reservations_shipment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipment_assembly_reservations
    ADD CONSTRAINT shipment_assembly_reservations_shipment_id_fkey FOREIGN KEY (shipment_id) REFERENCES public.shipments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: shipment_items shipment_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipment_items
    ADD CONSTRAINT shipment_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: shipment_items shipment_items_shipment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipment_items
    ADD CONSTRAINT shipment_items_shipment_id_fkey FOREIGN KEY (shipment_id) REFERENCES public.shipments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: shipments shipments_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_contract_id_fkey FOREIGN KEY (contract_id) REFERENCES public.contracts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: shipments shipments_counterparty_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_counterparty_id_fkey FOREIGN KEY (counterparty_id) REFERENCES public.counterparties(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: shipments shipments_legal_entity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_legal_entity_id_fkey FOREIGN KEY (legal_entity_id) REFERENCES public.counterparties(id) ON DELETE SET NULL;


--
-- Name: stock_movements stock_movements_corrected_movement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_corrected_movement_id_fkey FOREIGN KEY (corrected_movement_id) REFERENCES public.stock_movements(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: stock_movements stock_movements_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.lots(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: stock_movements stock_movements_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_shipment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_shipment_id_fkey FOREIGN KEY (shipment_id) REFERENCES public.shipments(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: stock_movements stock_movements_write_off_destination_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_write_off_destination_id_fkey FOREIGN KEY (write_off_destination_id) REFERENCES public.write_off_destinations(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict 5NaLgnZuLOB5trKmbazLoc2QmpvxrMaeLaHmkHRNKkHFxf2XtEZvqfuOoSOwvbQ

